import * as ort from './vendor/ort.wasm.min.mjs';
ort.env.wasm.wasmPaths = './vendor/';
ort.env.wasm.numThreads = 1;
const input = document.querySelector('#image');
const preview = document.querySelector('#preview');
const button = document.querySelector('#run');
const status = document.querySelector('#status');
const result = document.querySelector('#result');
let metadata, file, previewURL, session, loading, busy = false;
const message = text => { status.textContent = text; };
async function getSession() {
  if (session) return session;
  if (!loading) loading = (async () => {
    const response = await fetch('model/efficientnet-b0.onnx');
    if (!response.ok) throw new Error('Chưa có tệp mô hình. Cần hoàn tất xuất ONNX.');
    const bytes = await response.arrayBuffer();
    const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(b => b.toString(16).padStart(2,'0')).join('');
    if (hash !== metadata.onnx_sha256) throw new Error('Tệp mô hình không đúng checksum.');
    session = await ort.InferenceSession.create(bytes, {executionProviders:['wasm']});
    return session;
  })().catch(error => { loading = null; throw error; });
  return loading;
}
input.addEventListener('change', () => {
  result.hidden = true; file = null; button.disabled = true; preview.hidden = true;
  if (previewURL) URL.revokeObjectURL(previewURL);
  const selected = input.files?.[0];
  if (!selected) return;
  if (!['image/jpeg','image/png','image/webp'].includes(selected.type) || selected.size > 10*1024*1024) {
    input.value = ''; message('Chọn ảnh JPEG, PNG hoặc WebP không quá 10 MB.'); return;
  }
  file = selected; previewURL = URL.createObjectURL(file); preview.src = previewURL; preview.hidden = false;
  button.disabled = !metadata; message(metadata ? 'Đã chọn ảnh. Bấm Phân tích ảnh.' : 'Mô hình chưa sẵn sàng.');
});
button.addEventListener('click', async () => {
  if (busy || !file || !metadata) return;
  busy = true; button.disabled = true; input.disabled = true; result.hidden = true;
  let bitmap;
  try {
    const totalStart = performance.now(); message('Đang tải mô hình và xử lý ảnh…');
    bitmap = await createImageBitmap(file, {imageOrientation:'from-image'});
    if (!bitmap.width || !bitmap.height || bitmap.width*bitmap.height > 20000000) throw new Error('Ảnh quá lớn: tối đa 20 triệu điểm ảnh.');
    // Canvas resampling is an explicit prototype; Pillow bicubic parity is NOT claimed.
    const scale = 256 / Math.min(bitmap.width, bitmap.height);
    const width = Math.floor(bitmap.width*scale), height = Math.floor(bitmap.height*scale);
    const canvas = document.createElement('canvas'); canvas.width = 224; canvas.height = 224;
    const context = canvas.getContext('2d', {willReadFrequently:true});
    context.fillStyle = '#000'; context.fillRect(0,0,224,224);
    context.imageSmoothingEnabled = true; context.imageSmoothingQuality = 'high';
    context.drawImage(bitmap, -Math.round((width-224)/2), -Math.round((height-224)/2), width, height);
    const pixels = context.getImageData(0,0,224,224).data, tensor = new Float32Array(3*224*224);
    for (let i=0;i<224*224;i++) for (let c=0;c<3;c++) tensor[c*224*224+i] = pixels[i*4+c]/255;
    const model = await getSession(); const inferStart = performance.now();
    const output = await model.run({rgb:new ort.Tensor('float32',tensor,[1,3,224,224])});
    const logits = Array.from(output.logits.data, Number);
    if (logits.length !== metadata.class_names.length || logits.some(x=>!Number.isFinite(x))) throw new Error('Đầu ra mô hình không hợp lệ.');
    const max = Math.max(...logits), exp = logits.map(x=>Math.exp(x-max)), sum = exp.reduce((a,b)=>a+b,0);
    const rows = exp.map((value,index)=>({index,score:value/sum})).sort((a,b)=>b.score-a.score);
    const list = document.querySelector('#scores'); list.replaceChildren();
    for (const row of rows.slice(0,3)) {const item = document.createElement('li'); item.textContent = `${metadata.display_names_vi[metadata.class_names[row.index]]}: ${(row.score*100).toFixed(1)}%`; list.append(item);}
    document.querySelector('#timing').textContent = `Suy luận: ${Math.round(performance.now()-inferStart)} ms. Tổng lượt này: ${Math.round(performance.now()-totalStart)} ms.`;
    result.hidden = false; message('Đã nhận kết quả thử nghiệm từ EfficientNet-B0.');
  } catch(error) {message(`Chưa phân tích được: ${error.message}`);}
  finally {bitmap?.close();busy=false;button.disabled=!file||!metadata;input.disabled=false;}
});
try {
  const response = await fetch('model/model.json'); if(!response.ok) throw new Error('Chưa có gói ONNX đã kiểm tra.');
  const value = await response.json();
  if(value.architecture!=='efficientnet_b0'||!value.tensor_parity?.length) throw new Error('Gói mô hình không đúng yêu cầu.');
  metadata = value; button.disabled = !file; message('Sẵn sàng chọn ảnh. Mô hình sẽ được tải khi phân tích.');
} catch(error) {message(`Chưa sẵn sàng: ${error.message}`);}
