# EfficientNet-B0 trên trình duyệt: bước kiểm chứng đầu tiên

Yêu cầu: website public, miễn phí trong hạn mức, không cần máy chủ cá nhân luôn bật; giữ EfficientNet-B0 đã huấn luyện. Không triển khai backend Python lên Pages như một website tĩnh.

## Phần đã chuẩn bị

- `scripts/export_browser_model.py`: kiểm tra hash checkpoint, nạp đúng EfficientNet-B0 và thứ tự 6 nhãn. Không train, không thay model, không lượng tử hóa. Chuẩn hóa RGB nằm trong graph ONNX.
- Xuất ONNX opset 17, kiểm tra graph và so sánh logit/top-1 với PyTorch trên 8 tensor xác định. Sai lệch vượt ngưỡng làm build thất bại; chỉ ghi manifest sau khi đạt. Tensor parity không chứng minh độ chính xác thực địa.
- `browser-pilot/`: trang thử nghiệm tách biệt, xử lý ảnh tại trình duyệt, WASM một luồng, kiểm tra SHA-256 mô hình, không gửi ảnh lên API, không đăng nhập hay lưu dữ liệu.
- GitHub workflow `browser-pilot.yml`: chạy thủ công trên cloud, xuất mô hình và tạo artifact. Không tự triển khai hoặc kích hoạt dịch vụ trả phí. Việc sử dụng runner chịu hạn mức của tài khoản GitHub.

## Điều kiện để chạy workflow

Kho GitHub phải có mã nguồn và đúng `model_assets/efficientnet_b0/weights.pt`, `metadata.json` (Git LFS nếu đang sử dụng LFS). Không đưa dữ liệu ảnh riêng tư, secrets, .env hoặc toàn bộ dữ liệu huấn luyện lên kho. Hiện chưa xác nhận kho GitHub/tài khoản được kết nối; workflow chưa chạy.

Chọn Actions > EfficientNet-B0 browser pilot (build only) > Run workflow. Nếu thành công, tải artifact `efficientnet-b0-browser-pilot`; nội dung đó là thư mục website tĩnh dự kiến cho Cloudflare Pages thử nghiệm. Chưa được ghi nhận là bản sản phẩm hoàn chỉnh.

## Cổng nghiệm thu còn thiếu

1. Xuất model và tensor parity chạy thật trên runner (máy hiện tại thiếu onnx/onnxruntime).
2. Đối chiếu ảnh thật: EXIF, RGB, resize cạnh ngắn 256, center crop 224 và nội suy bicubic. Canvas chất lượng cao hiện chỉ là prototype, không đảm bảo giống Pillow bicubic/antialias. Cần thay hoặc kiểm chứng tiền xử lý trước nghiệm thu.
3. Chạy thật trong trình duyệt và đo cold load, inference, RAM trên điện thoại/máy tính. Chặn ảnh quá nhiều pixel sau decode chưa ngăn hết nguy cơ cạn bộ nhớ khi giải mã.
4. Mô hình được tải xuống thiết bị người dùng: đây là đặc tính của suy luận browser. Kết quả gửi từ browser không được coi là xác thực bởi server trong thiết kế lịch sử sau này.
5. Chỉ sau bước 1–3 mới quyết định chuyển backend sang Workers/D1. Chưa đổi dữ liệu, chưa xóa FastAPI/PostgreSQL. OCR/RAG/push và lưu ảnh cần phương án miễn phí riêng, không mặc định đã đáp ứng.

Nguồn: https://onnxruntime.ai/docs/tutorials/web/ ; https://developers.cloudflare.com/pages/platform/limits/

Trạng thái: chuẩn bị mã nguồn, chưa có file ONNX thành công, chưa có URL public, chưa có kiểm thử browser.
