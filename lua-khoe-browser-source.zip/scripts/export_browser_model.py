"""Export the existing EfficientNet-B0, then gate the artifact on CPU parity."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from project_storage import configure


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    configure()
    import numpy as np
    import torch
    import onnx
    import onnxruntime as ort
    from torchvision.models import efficientnet_b0

    source = ROOT / 'model_assets/efficientnet_b0'
    metadata = json.loads((source / 'metadata.json').read_text(encoding='utf-8'))
    if metadata['architecture'] != 'efficientnet_b0' or sha(source / 'weights.pt') != metadata['weights_sha256']:
        raise ValueError('Wrong architecture or weights checksum; refusing export.')
    prep = metadata['preprocessing']
    if prep['input_size'] != 224 or prep['eval_resize'] != 256 or prep['interpolation'] != 'bicubic':
        raise ValueError('Browser preprocessing contract does not match source.')
    model = efficientnet_b0(weights=None)
    model.classifier[-1] = torch.nn.Linear(model.classifier[-1].in_features, len(metadata['class_names']))
    model.load_state_dict(torch.load(source / 'weights.pt', map_location='cpu', weights_only=True), strict=True)
    model.eval()
    torch.set_num_threads(2)

    class BrowserModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.network = model
            self.register_buffer('mean', torch.tensor(prep['mean']).reshape(1, 3, 1, 1))
            self.register_buffer('std', torch.tensor(prep['std']).reshape(1, 3, 1, 1))

        def forward(self, rgb):
            return self.network((rgb - self.mean) / self.std)

    wrapped = BrowserModel().eval()
    args.output.mkdir(parents=True, exist_ok=False)
    path = args.output / 'efficientnet-b0.onnx'
    torch.onnx.export(wrapped, torch.zeros(1, 3, 224, 224), str(path),
                      input_names=['rgb'], output_names=['logits'], opset_version=17, dynamo=False)
    onnx.checker.check_model(onnx.load(str(path)))
    session = ort.InferenceSession(str(path), providers=['CPUExecutionProvider'])
    rng = np.random.default_rng(20261118)
    inputs = [np.zeros((1, 3, 224, 224), dtype=np.float32), np.ones((1, 3, 224, 224), dtype=np.float32)]
    inputs += [rng.random((1, 3, 224, 224), dtype=np.float32) for _ in range(6)]
    checks = []
    with torch.inference_mode():
        for index, value in enumerate(inputs):
            expected = wrapped(torch.from_numpy(value)).numpy()
            actual = session.run(['logits'], {'rgb': value})[0]
            if not np.isfinite(actual).all() or not np.allclose(actual, expected, rtol=1e-4, atol=1e-4):
                raise ValueError(f'ONNX logit parity failed on tensor {index}.')
            if int(actual.argmax()) != int(expected.argmax()):
                raise ValueError(f'ONNX class parity failed on tensor {index}.')
            checks.append({'tensor': index, 'max_logit_delta': float(np.max(np.abs(expected-actual)))})
    if path.stat().st_size > 25 * 1024 * 1024:
        raise ValueError('Model exceeds the targeted Pages single-file budget.')
    result = {'architecture': 'efficientnet_b0', 'class_names': metadata['class_names'],
              'display_names_vi': metadata['display_names_vi'], 'preprocessing': prep,
              'input': 'RGB float32 [1,3,224,224] in [0,1]; normalization inside ONNX',
              'source_weights_sha256': metadata['weights_sha256'], 'onnx_sha256': sha(path),
              'tensor_parity': checks, 'browser_image_parity': 'NOT_RUN',
              'field_accuracy': 'NOT_EVALUATED', 'torch': torch.__version__, 'onnxruntime': ort.__version__}
    # This manifest is written only after all model checks pass.
    (args.output / 'model.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
