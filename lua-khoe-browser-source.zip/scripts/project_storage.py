"""Keep project-controlled temporary files/caches beside the project on D:."""
import os
import tempfile
from pathlib import Path

def configure():
    root=Path(__file__).resolve().parents[1]/'.local'
    folders={'TEMP':'temp','TMP':'temp','TMPDIR':'temp','PIP_CACHE_DIR':'cache/pip',
             'npm_config_cache':'cache/npm','TORCH_HOME':'cache/torch','HF_HOME':'cache/huggingface',
             'XDG_CACHE_HOME':'cache','PLAYWRIGHT_BROWSERS_PATH':'cache/playwright'}
    for name,relative in folders.items():
        path=root/relative;path.mkdir(parents=True,exist_ok=True);os.environ[name]=str(path)
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    tempfile.tempdir=os.environ['TEMP']
    return {name:os.environ[name] for name in folders}
