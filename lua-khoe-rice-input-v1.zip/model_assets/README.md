# Tài sản mô hình

Ảnh tải lên được kiểm tra bằng `efficientnet_b0/rice_input.pt` và `efficientnet_b0/rice_input.json` trước khi vào bộ phân loại bệnh. Khi triển khai, đặt hai tệp này cùng thư mục `MODEL_DIR` với `weights.pt` và `metadata.json`. Máy chủ kiểm tra mã băm khi nạp bộ lọc và báo chưa sẵn sàng nếu thiếu tệp. Công cụ tái tạo bộ lọc từ manifest ảnh đã sàng lọc là `scripts/build_rice_input_guard.py`.

Không commit trọng số/dataset. Chạy `scripts/audit_model.py --source <thư mục dự án training>` bằng Python có PyTorch 2.6/torchvision 0.21; script chỉ đọc bản gốc và tạo `efficientnet_b0/weights.pt` cùng metadata. So sánh 12 ảnh với pipeline gốc, ghi docs/model_audit_evidence.json.

Không coi validation accuracy hoặc parity là độ chính xác ngoài đồng. Dữ liệu gốc có ghi nhận gần trùng và xung đột nhãn. Bản dịch nhãn lấy từ metadata cũ và chờ rà soát chuyên môn.
