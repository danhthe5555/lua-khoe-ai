import io
import hashlib
import os
import secrets
import smtplib
import logging
import uuid
from collections import Counter, defaultdict, deque
from copy import deepcopy
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, BackgroundTasks, Depends, HTTPException, Request, Response, UploadFile, File, Form, Query
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, ImageOps
from pydantic import BaseModel, ConfigDict, Field, EmailStr, AwareDatetime, HttpUrl, field_validator
from sqlalchemy import select, delete, text, func, update
from sqlalchemy.exc import IntegrityError
from .db import Base, engine, get_db, SessionLocal, User, Session, Reset, Plot, Season, Diagnosis, Activity, Feedback, Knowledge, Audit, now, serialize
from .security import current, farmer, admin, profile, digest, hasher, verify, dummy_hash
from .ml import photo_quality, predictor
from .body_limit import BodyLimitMiddleware
from .rate_limit import RateLimiter
from .knowledge_search import search_articles
from .knowledge_drafts import REFERENCE_DRAFTS
from .stage_guidance import STAGES, guidance
from .result_assessment import SPREAD, alignment, lines, snapshot, validate_fields
from .calendar_export import calendar_event
from . import ocr
from . import rag
from . import weather
from .push_routes import router as push_router
from .db import PushSubscription
from .db import ProductLabel
from .label_catalogue import validate_review,public_label

storage = Path(os.getenv('STORAGE_LOCAL_DIR', './storage'))
origin = os.getenv('FRONTEND_ORIGIN', 'http://localhost:5173')

@asynccontextmanager
async def lifespan(app):
    storage.mkdir(parents=True, exist_ok=True)
    predictor.load_model()
    try:
        predictor.load_input_guard()
    except (OSError, ValueError, RuntimeError):
        logging.getLogger('lua-khoe').exception('Rice input guard could not be loaded')
    yield

app = FastAPI(title='Lúa Khỏe AI', version='1.6.0', lifespan=lifespan)
app.include_router(push_router)
app.add_middleware(CORSMiddleware, allow_origins=[origin], allow_credentials=True,
                   allow_methods=['GET','POST','PATCH','DELETE'], allow_headers=['Content-Type','X-CSRF-Token','Idempotency-Key'])
app.add_middleware(BodyLimitMiddleware,max_bytes=11*1024*1024)
rate_buckets = RateLimiter()
limited_paths={f'/api/v1/auth/{name}' for name in ('register','login','forgot-password','reset-password')} | {'/api/v1/diagnoses/predict','/api/v1/ocr/label','/api/v1/assistant/ask','/api/v1/weather/current','/api/v1/push/subscriptions'}

@app.middleware('http')
async def protections(request, call_next):
    request_id = str(uuid.uuid4())
    if request.method not in ('GET','HEAD','OPTIONS'):
        if request.headers.get('origin') and request.headers['origin'] != origin:
            return JSONResponse({'error': {'code':'403','message':'Nguồn yêu cầu không được phép.'}}, 403)
        try: content_length=int(request.headers.get('content-length', '0'))
        except ValueError: return JSONResponse({'error':{'code':'400','message':'Yêu cầu không hợp lệ.'}},400)
        if content_length > 11 * 1024 * 1024:
            return JSONResponse({'error': {'code':'413','message':'Ảnh vượt quá 10 MB.'}}, 413)
        if request.url.path in limited_paths:
            key = (request.client.host if request.client else 'unknown', request.url.path)
            if not rate_buckets.allow(key):
                return JSONResponse({'error':{'code':'429','message':'Bạn thao tác quá nhanh. Hãy thử lại sau một phút.'}},429,
                                    headers={'Retry-After':'60','Cache-Control':'no-store, private'})
    response = await call_next(request)
    response.headers['Cache-Control'] = 'no-store, private'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Request-ID'] = request_id
    return response

@app.exception_handler(HTTPException)
async def http_error(_, error):
    return JSONResponse({'error':{'code':str(error.status_code),'message':error.detail}},error.status_code)

@app.exception_handler(RequestValidationError)
async def validation_error(_, error):
    return JSONResponse({'error':{'code':'VALIDATION','message':'Thông tin chưa hợp lệ. Kiểm tra các trường và thử lại.'}},422)

@app.exception_handler(Exception)
async def unexpected(_, error):
    logging.getLogger('lua-khoe').error('request_failed type=%s',type(error).__name__)
    return JSONResponse({'error':{'code':'SERVER_ERROR','message':'Hệ thống đang gặp sự cố. Vui lòng thử lại sau.'}},500)

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')

    @field_validator('*', mode='before')
    @classmethod
    def trim_text(cls, value, info):
        # Password whitespace is part of the secret and must survive register/reset/login.
        if isinstance(value, str) and info.field_name not in ('password', 'token'):
            return value.strip()
        return value

class Register(Strict):
    email: EmailStr
    password: str = Field(min_length=12, max_length=128)
    name: str = Field(min_length=1, max_length=120)

class Login(Strict):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)

class Name(Strict):
    name: str = Field(min_length=1, max_length=120)

class Forgot(Strict):
    email: EmailStr

class ResetInput(Strict):
    token: str = Field(min_length=20, max_length=150)
    password: str = Field(min_length=12, max_length=128)

class PlotInput(Strict):
    name: str = Field(min_length=1, max_length=120)
    area_m2: float = Field(gt=0, le=1e9, allow_inf_nan=False)
    notes: str = Field(default='', max_length=2000)
    archived: bool = False

class SeasonInput(Strict):
    rice_variety: str = Field(min_length=1,max_length=120)
    sowing_date: date
    growing_stage: str = Field(min_length=1,max_length=80)
    status: Literal['active','ended'] = 'active'

class ActivityInput(Strict):
    season_id: str | None = None
    diagnosis_id: str | None = None
    kind: Literal['observation','intervention','reminder']
    title: str = Field(min_length=1,max_length=200)
    notes: str = Field(default='',max_length=4000)
    due_at: AwareDatetime
    completed: bool = False

class FeedbackInput(Strict):
    notes: str = Field(min_length=1,max_length=2000)
    consented_to_review: bool = False

class Source(Strict):
    title: str = Field(min_length=1,max_length=200)
    url: HttpUrl
    publisher: str = Field(min_length=1,max_length=200)
    checked_at: date
    reuse_permission: str = Field(min_length=1,max_length=1000)

class KnowledgeInput(Strict):
    code: str = Field(pattern=r'^[A-Za-z0-9_-]{1,100}$')
    title: str = Field(min_length=1,max_length=200)
    content: dict[str,str]
    sources: list[Source] = Field(max_length=30)

    @field_validator('content')
    @classmethod
    def bounded_content(cls,value):
        if len(value)>20 or any(len(k)>80 or len(v)>15000 for k,v in value.items()):
            raise ValueError('Nội dung quá dài.')
        validate_fields(value)
        return value

class Confirm(Strict):
    confirmed: Literal[True]

class AssistantQuestion(Strict):
    question:str=Field(min_length=3,max_length=1000)

class ProductLabelInput(Strict):
    registration:str=Field(min_length=1,max_length=120)
    name:str=Field(min_length=1,max_length=200)
    crop:str=Field(min_length=1,max_length=100)
    target:str=Field(min_length=1,max_length=500)
    ingredients:str=Field(min_length=1,max_length=1000)
    label_text:str=Field(min_length=1,max_length=15000)
    precautions:str=Field(min_length=1,max_length=8000)
    valid_until:date
    source:Source

@app.get('/api/v1/labels')
def label_search(search:str=Query(...,min_length=2,max_length=120),offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100),db=Depends(get_db)):
    term=search.strip().replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
    if len(term)<2:raise HTTPException(422,'Nhập ít nhất hai ký tự để tra cứu.')
    q=select(ProductLabel).where(ProductLabel.status=='published',ProductLabel.reviewed_at.is_not(None),ProductLabel.valid_until>=now().date().isoformat())
    q=q.where(ProductLabel.registration.ilike('%'+term+'%',escape='\\') | ProductLabel.name.ilike('%'+term+'%',escape='\\'))
    return [public_label(serialize(row)) for row in db.scalars(q.order_by(ProductLabel.name,ProductLabel.id).offset(offset).limit(limit))]

@app.get('/api/v1/admin/labels')
def admin_labels(user=Depends(admin),db=Depends(get_db),offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100)):
    return [serialize(row) for row in db.scalars(select(ProductLabel).order_by(ProductLabel.created_at.desc(),ProductLabel.id).offset(offset).limit(limit))]

@app.post('/api/v1/admin/labels',status_code=201)
def create_label(data:ProductLabelInput,user=Depends(admin),db=Depends(get_db)):
    row=ProductLabel(**data.model_dump(mode='json'),created_by=user.id)
    db.add(row);db.flush();audit(db,user,'label_draft',row.id);db.commit();return serialize(row)

@app.post('/api/v1/admin/labels/{id}/{action}')
def label_workflow(id:str,action:Literal['publish','archive'],data:Confirm,user=Depends(admin),db=Depends(get_db)):
    row=db.get(ProductLabel,id)
    if not row:raise HTTPException(404,'Không tìm thấy bản ghi nhãn.')
    list(db.scalars(select(ProductLabel).where(ProductLabel.registration==row.registration).order_by(ProductLabel.id).with_for_update().execution_options(populate_existing=True)))
    if action=='publish':
        if row.status!='draft':raise HTTPException(422,'Chỉ xuất bản bản nháp mới được rà soát.')
        try:validate_review(serialize(row),now().date())
        except ValueError as error:raise HTTPException(422,str(error))
        for previous in db.scalars(select(ProductLabel).where(ProductLabel.registration==row.registration,ProductLabel.status=='published')):previous.status='archived'
        db.flush()
        row.status='published';row.reviewed_by=user.id;row.reviewed_at=now()
    else:row.status='archived'
    audit(db,user,'label_'+action,row.id)
    try:db.commit()
    except IntegrityError:db.rollback();raise HTTPException(409,'Bản nhãn vừa thay đổi. Hãy tải lại danh sách.')
    return serialize(row)

class WeatherLocation(Strict):
    latitude:float=Field(ge=-90,le=90,allow_inf_nan=False)
    longitude:float=Field(ge=-180,le=180,allow_inf_nan=False)
    consent_to_share_location:Literal[True]

@app.post('/api/v1/weather/current')
def current_weather(data:WeatherLocation,user=Depends(farmer)):
    try:return weather.fetch(data.latitude,data.longitude)
    except weather.WeatherUnavailable as error:raise HTTPException(503,str(error))

def owned(db, cls, id, user):
    record = db.get(cls,id)
    if record is None: raise HTTPException(404,'Không tìm thấy dữ liệu.')
    if cls is Season:
        owned(db,Plot,record.plot_id,user)
    elif record.user_id != user.id:
        raise HTTPException(404,'Không tìm thấy dữ liệu.')
    return record

def links(db,user,season_id=None,diagnosis_id=None):
    if season_id: owned(db,Season,season_id,user)
    if diagnosis_id:
        diagnosis = owned(db,Diagnosis,diagnosis_id,user)
        if season_id and diagnosis.season_id != season_id:
            raise HTTPException(422,'Kết quả không thuộc vụ đã chọn.')

def audit(db,user,action,id):
    db.add(Audit(admin_id=user.id,action=action,target_id=id))

def page_query(db,cls,user,offset=0,limit=100):
    return db.scalars(select(cls).where(cls.user_id==user.id).order_by(cls.created_at.desc()).offset(offset).limit(limit)).all()

@app.get('/health/live')
def live(): return {'status':'alive'}

@app.get('/api/v1/model/labels')
def model_labels():
    if predictor.model is None: raise HTTPException(503,'Danh sách bệnh chưa sẵn sàng. Vui lòng thử lại sau.')
    return [{'code':code,'name':predictor.metadata['display_names_vi'][code]} for code in predictor.labels]

@app.get('/health/ready')
def ready(db=Depends(get_db)):
    try: db.execute(text('SELECT 1'))
    except Exception: return JSONResponse({'database':False,'model':predictor.health_status()},503)
    payload={'database':True,'model':predictor.health_status(),'rice_input_ready':predictor.input_guard is not None}
    return JSONResponse(payload,200 if predictor.model is not None and predictor.input_guard is not None else 503)

@app.post('/api/v1/auth/register',status_code=201)
def register(data:Register,db=Depends(get_db)):
    user=User(email=str(data.email).lower(),name=data.name,password_hash=hasher.hash(data.password))
    db.add(user)
    try: db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409,'Không thể đăng ký email này. Hãy đăng nhập hoặc khôi phục mật khẩu.')
    return profile(user)

@app.post('/api/v1/auth/login')
def login(data:Login,request:Request,response:Response,db=Depends(get_db)):
    user=db.scalar(select(User).where(User.email==str(data.email).lower()))
    valid=verify(data.password,user.password_hash if user else dummy_hash)
    if not user or not valid or not user.active: raise HTTPException(401,'Email hoặc mật khẩu không đúng.')
    # Replace only this browser's session after successful authentication.
    # FK cascade also revokes subscriptions attached to the replaced session.
    previous=request.cookies.get('session')
    if previous:
        db.execute(delete(Session).where(Session.token_hash==digest(previous)))
    db.execute(delete(Session).where(Session.user_id==user.id,Session.expires_at<=now()))
    token=secrets.token_urlsafe(40); csrf=secrets.token_urlsafe(32)
    db.add(Session(user_id=user.id,token_hash=digest(token),csrf=csrf,expires_at=now()+timedelta(hours=12)))
    db.commit()
    response.set_cookie('session',token,httponly=True,secure=os.getenv('APP_ENV')=='production',samesite='lax',max_age=43200)
    return {'user':profile(user),'csrf':csrf}

@app.get('/api/v1/auth/me')
def me(request:Request,user=Depends(current)):
    return {'user':profile(user),'csrf':request.state.session.csrf}

@app.patch('/api/v1/auth/me')
def update_me(data:Name,user=Depends(current),db=Depends(get_db)):
    user.name=data.name; db.commit(); return profile(user)

@app.post('/api/v1/auth/logout')
def logout(request:Request,response:Response,user=Depends(current),db=Depends(get_db)):
    db.delete(request.state.session); db.commit(); response.delete_cookie('session')
    return {'message':'Đã đăng xuất.'}

@app.get('/api/v1/auth/sessions')
def active_sessions(request:Request,offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100),
                    user=Depends(current),db=Depends(get_db)):
    rows=db.scalars(select(Session).where(Session.user_id==user.id,Session.expires_at>now())
                    .order_by(Session.created_at.desc(),Session.id.desc()).offset(offset).limit(limit)).all()
    return [{'id':row.id,'created_at':row.created_at,'expires_at':row.expires_at,
             'current':row.id==request.state.session.id} for row in rows]

@app.delete('/api/v1/auth/sessions/{session_id}')
def revoke_session(session_id:str,request:Request,user=Depends(current),db=Depends(get_db)):
    row=db.scalar(select(Session).where(Session.id==session_id,Session.user_id==user.id).with_for_update())
    if not row:raise HTTPException(404,'Không tìm thấy phiên đăng nhập.')
    if row.id==request.state.session.id:
        raise HTTPException(409,'Dùng nút Đăng xuất để kết thúc phiên hiện tại.')
    db.delete(row);db.commit()
    return {'message':'Đã thu hồi phiên đăng nhập và đăng ký thông báo của phiên đó.'}

def deliver_reset(email):
    host=os.getenv('SMTP_HOST')
    with SessionLocal() as db:
        user=db.scalar(select(User).where(User.email==email,User.active==True))
        if user:
            token=secrets.token_urlsafe(40)
            db.execute(delete(Reset).where(Reset.user_id==user.id))
            db.add(Reset(user_id=user.id,token_hash=digest(token),expires_at=now()+timedelta(minutes=20)))
            message=EmailMessage(); message['From']=os.getenv('SMTP_FROM','no-reply@localhost'); message['To']=user.email
            message['Subject']='Khôi phục mật khẩu Lúa Khỏe AI'
            message.set_content(f'Mở liên kết trong 20 phút: {origin}/dat-lai-mat-khau#token={token}\nNếu không yêu cầu, hãy bỏ qua email.')
            try:
                with smtplib.SMTP(host,int(os.getenv('SMTP_PORT','1025')),timeout=10) as smtp:
                    if os.getenv('SMTP_TLS')=='true': smtp.starttls()
                    if os.getenv('SMTP_USER'): smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
                    smtp.send_message(message)
                db.commit()
            except Exception:
                db.rollback()
                logging.getLogger('lua-khoe').error('password_reset_delivery_failed')
                # Same generic response for known and unknown addresses; operational alert is separate.

@app.post('/api/v1/auth/forgot-password')
def forgot(data:Forgot,background_tasks:BackgroundTasks):
    if not os.getenv('SMTP_HOST'): raise HTTPException(503,'Chức năng gửi email chưa được cấu hình.')
    # Queue the same operation for every address and return before SMTP I/O.
    background_tasks.add_task(deliver_reset,str(data.email).lower())
    return {'message':'Nếu email hợp lệ, bạn sẽ nhận được liên kết khôi phục.'}

@app.post('/api/v1/auth/reset-password')
def reset(data:ResetInput,db=Depends(get_db)):
    record=db.scalar(select(Reset).where(Reset.token_hash==digest(data.token)).with_for_update())
    if not record or record.expires_at.replace(tzinfo=timezone.utc)<=now(): raise HTTPException(400,'Liên kết đã dùng hoặc hết hạn.')
    user=db.get(User,record.user_id); user.password_hash=hasher.hash(data.password)
    db.execute(delete(Session).where(Session.user_id==user.id)); db.execute(delete(Reset).where(Reset.user_id==user.id))
    db.commit(); return {'message':'Đã đổi mật khẩu. Vui lòng đăng nhập lại.'}

@app.get('/api/v1/plots')
def plots(user=Depends(farmer),db=Depends(get_db),offset:int=0,limit:int=100):
    return [serialize(p) for p in page_query(db,Plot,user,max(offset,0),min(max(limit,1),100))]

@app.post('/api/v1/plots',status_code=201)
def create_plot(data:PlotInput,user=Depends(farmer),db=Depends(get_db)):
    p=Plot(user_id=user.id,**data.model_dump()); db.add(p); db.commit(); return serialize(p)

@app.get('/api/v1/plots/{id}')
def plot_detail(id:str,user=Depends(farmer),db=Depends(get_db)): return serialize(owned(db,Plot,id,user))

@app.patch('/api/v1/plots/{id}')
def edit_plot(id:str,data:PlotInput,user=Depends(farmer),db=Depends(get_db)):
    p=owned(db,Plot,id,user)
    for k,v in data.model_dump().items(): setattr(p,k,v)
    db.commit(); return serialize(p)

@app.delete('/api/v1/plots/{id}')
def archive_plot(id:str,user=Depends(farmer),db=Depends(get_db)):
    p=owned(db,Plot,id,user); p.archived=True; db.commit(); return {'message':'Đã ẩn ruộng. Lịch sử vẫn được giữ.'}

@app.get('/api/v1/plots/{id}/seasons')
def seasons(id:str,user=Depends(farmer),db=Depends(get_db)):
    owned(db,Plot,id,user)
    return [serialize(s) for s in db.scalars(select(Season).where(Season.plot_id==id).order_by(Season.created_at.desc()))]

@app.post('/api/v1/plots/{id}/seasons',status_code=201)
def create_season(id:str,data:SeasonInput,user=Depends(farmer),db=Depends(get_db)):
    plot=owned(db,Plot,id,user)
    if plot.archived: raise HTTPException(422,'Hãy mở lại ruộng trước khi tạo vụ.')
    s=Season(plot_id=id,user_id=user.id,**data.model_dump(mode='json')); db.add(s); db.commit(); return serialize(s)

@app.patch('/api/v1/seasons/{id}')
def edit_season(id:str,data:SeasonInput,user=Depends(farmer),db=Depends(get_db)):
    s=owned(db,Season,id,user)
    for k,v in data.model_dump(mode='json').items(): setattr(s,k,v)
    db.commit(); return serialize(s)

@app.get('/api/v1/seasons')
def all_seasons(user=Depends(farmer),db=Depends(get_db),include_archived:bool=False):
    q=select(Season).join(Plot,Season.plot_id==Plot.id).where(Plot.user_id==user.id)
    if not include_archived:q=q.where(Plot.archived==False)
    return [{**serialize(s),'plot_name':db.get(Plot,s.plot_id).name} for s in db.scalars(q)]

@app.get('/api/v1/plots/{id}/timeline')
def timeline(id:str,user=Depends(farmer),db=Depends(get_db)):
    owned(db,Plot,id,user)
    season_ids=select(Season.id).where(Season.plot_id==id,Season.user_id==user.id)
    results=[{**serialize(d),'event_kind':'ai_prediction','event_at':d.created_at} for d in db.scalars(select(Diagnosis).where(Diagnosis.user_id==user.id,Diagnosis.season_id.in_(season_ids)))]
    results.extend({**serialize(a),'event_kind':a.kind,'event_at':a.due_at} for a in db.scalars(select(Activity).where(Activity.user_id==user.id,Activity.season_id.in_(season_ids))))
    return sorted(results,key=lambda r:r['event_at'].replace(tzinfo=timezone.utc),reverse=True)

@app.get('/api/v1/ocr/status')
def ocr_status(user=Depends(farmer)):
    return ocr.health()

@app.post('/api/v1/ocr/label')
def ocr_label(image:UploadFile=File(...),user=Depends(farmer)):
    if image.content_type not in ('image/jpeg','image/png','image/webp'):
        raise HTTPException(422,'Chỉ nhận ảnh JPEG, PNG hoặc WebP.')
    data=image.file.read(10*1024*1024+1)
    if not data or len(data)>10*1024*1024:raise HTTPException(422,'Ảnh phải từ 1 byte đến 10 MB.')
    try:return ocr.recognize(data)
    except ocr.OCRUnavailable as error:raise HTTPException(503,str(error))
    except ocr.OCRBusy as error:raise HTTPException(429,str(error))
    except ValueError as error:raise HTTPException(422,str(error))

@app.post('/api/v1/diagnoses/predict')
def predict(request:Request,image:UploadFile=File(...),save:bool=Form(False),save_image:bool=Form(False),season_id:str|None=Form(None),followup_id:str|None=Form(None,max_length=36),db=Depends(get_db)):
    user=None
    if followup_id and not save:
        raise HTTPException(422,'Cần lưu kết quả khi kiểm tra lại trong cùng đợt.')
    if save:
        user=current(request,db)
        if user.role!='farmer': raise HTTPException(403,'Chỉ tài khoản nông dân được lưu.')
        links(db,user,season_id)
    elif os.getenv('ENABLE_GUEST_PREDICTION','true')!='true': current(request,db)
    key=request.headers.get('Idempotency-Key','')
    if save:
        try: uuid.UUID(key)
        except ValueError: raise HTTPException(422,'Cần mã yêu cầu hợp lệ để tránh lưu trùng.')
        key=user.id+':'+key
        old=db.scalar(select(Diagnosis).where(Diagnosis.request_key==key))
        if old: return {**old.result,'diagnosis_id':old.id}
        if followup_id:
            owned(db,Diagnosis,followup_id,user)
    if image.content_type not in ('image/jpeg','image/png','image/webp'):
        raise HTTPException(422,'Chỉ nhận ảnh JPEG, PNG hoặc WebP.')
    data=image.file.read(10*1024*1024+1)
    try:
        decoded=predictor.validate_image(data)
        quality_notice=photo_quality(decoded)
    except ValueError as exc: raise HTTPException(422,str(exc))
    if decoded.info.get('upload_mime',image.content_type)!=image.content_type:
        raise HTTPException(422,'Định dạng thực của ảnh không khớp với tệp tải lên.')
    if predictor.model is None: raise HTTPException(503,'Mô hình chưa sẵn sàng. Bạn có thể thử lại sau.')
    if predictor.input_guard is None:
        raise HTTPException(503,'Bộ kiểm tra ảnh chưa sẵn sàng. Bạn có thể thử lại sau.')
    from .rice_input import RetakePhoto
    try:
        result=predictor.predict_upload(decoded)
    except RetakePhoto as exc:
        return JSONResponse({'error':{'code':'RETAKE_PHOTO','message':str(exc)}},status_code=422)
    result['photo_notice']=quality_notice
    if save:
        image_sha=hashlib.sha256(data).hexdigest()
        result['image_sha256']=image_sha
        result['duplicate_photo']=bool(db.scalar(select(Diagnosis.id).where(
            Diagnosis.user_id==user.id,Diagnosis.result['image_sha256'].as_string()==image_sha).limit(1)))
    knowledge=db.scalar(select(Knowledge).where(Knowledge.code==result['predicted_class'],Knowledge.status=='published'))
    result['knowledge_version']=knowledge.id if knowledge else None
    result['knowledge_available']=knowledge is not None
    result['knowledge_sources']=public_knowledge(knowledge)['sources'] if knowledge else []
    result['knowledge_reviewed_at']=knowledge.reviewed_at.isoformat() if knowledge and knowledge.reviewed_at else None
    diagnosis_id=None
    if save:
        tracking_id=None
        if followup_id:
            lock_tracking_write(db,user)
            old=db.scalar(select(Diagnosis).where(Diagnosis.request_key==key))
            if old: return {**old.result,'diagnosis_id':old.id}
            previous=owned(db,Diagnosis,followup_id,user)
            db.refresh(previous)
            if previous.tracking_closed_at:
                raise HTTPException(409,'Đợt theo dõi đã kết thúc. Hãy mở lại trước khi kiểm tra tiếp.')
            if season_id and season_id!=previous.season_id:
                raise HTTPException(422,'Ảnh kiểm tra lại phải thuộc cùng ruộng và mùa vụ.')
            season_id=previous.season_id
            tracking_id=previous.tracking_id or previous.id
            previous.tracking_id=tracking_id
        extension={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[image.content_type]
        image_key=f'{uuid.uuid4()}.{extension}' if save_image else None
        if image_key: (storage/image_key).write_bytes(data)
        d=Diagnosis(user_id=user.id,season_id=season_id,image_key=image_key,result=result,request_key=key,tracking_id=tracking_id)
        db.add(d)
        try: db.commit(); diagnosis_id=d.id
        except IntegrityError:
            db.rollback()
            if image_key: (storage/image_key).unlink(missing_ok=True)
            old=db.scalar(select(Diagnosis).where(Diagnosis.request_key==key))
            if old: return {**old.result,'diagnosis_id':old.id}
            raise HTTPException(409,'Không thể lưu. Hãy thử lại.')
        except Exception:
            db.rollback()
            if image_key: (storage/image_key).unlink(missing_ok=True)
            raise
    return {**result,'diagnosis_id':diagnosis_id}

@app.get('/api/v1/diagnoses')
def history(user=Depends(farmer),db=Depends(get_db),season_id:str|None=None,from_date:date|None=None,to_date:date|None=None,label:str|None=None,offset:int=0,limit:int=100,plot_id:str|None=None):
    q=diagnosis_query(db,user,plot_id,season_id,from_date,to_date,label)
    return [serialize(d) for d in db.scalars(q.order_by(Diagnosis.created_at.desc(),Diagnosis.id).offset(max(offset,0)).limit(min(max(limit,1),100)))]

def diagnosis_query(db,user,plot_id=None,season_id=None,from_date=None,to_date=None,label=None):
    if plot_id:owned(db,Plot,plot_id,user)
    if season_id:
        season=owned(db,Season,season_id,user)
        if plot_id and season.plot_id!=plot_id:raise HTTPException(422,'Mùa vụ không thuộc ruộng đã chọn.')
    if from_date and to_date and from_date>to_date: raise HTTPException(422,'Ngày bắt đầu phải trước ngày kết thúc.')
    q=select(Diagnosis).where(Diagnosis.user_id==user.id)
    if plot_id:q=q.where(Diagnosis.season_id.in_(select(Season.id).where(Season.plot_id==plot_id,Season.user_id==user.id)))
    if season_id: q=q.where(Diagnosis.season_id==season_id)
    if from_date: q=q.where(Diagnosis.created_at>=datetime.combine(from_date,datetime.min.time(),tzinfo=timezone.utc))
    if to_date: q=q.where(Diagnosis.created_at<=datetime.combine(to_date,datetime.max.time(),tzinfo=timezone.utc))
    if label: q=q.where(Diagnosis.result['predicted_class'].as_string()==label)
    return q

@app.get('/api/v1/diagnoses/{id}')
def diagnosis(id:str,user=Depends(farmer),db=Depends(get_db)): return serialize(owned(db,Diagnosis,id,user))

class AssessmentEdit(Strict):
    version: str = Field(max_length=50)
    question: int | None = Field(default=None,ge=0,le=3)
    answer: Literal['yes','no','unknown'] | None = None
    stage: str | None = Field(default=None,max_length=20)
    spread: str | None = Field(default=None,max_length=20)
    task: int | None = Field(default=None,ge=0,le=4)
    done: bool | None = None


def assessment_for(db, record):
    if record.assessment:
        return deepcopy(record.assessment)
    guide=db.scalar(select(Knowledge).where(Knowledge.code==record.result.get('predicted_class'),
                                           Knowledge.status=='published'))
    alternatives=[]
    if guide and guide.reviewed_at and guide.sources:
        for line in lines(guide.content.get('similar_diseases','')):
            code, _, detail=line.partition('|')
            if code.strip()==guide.code: continue
            other=db.scalar(select(Knowledge).where(Knowledge.code==code.strip(),Knowledge.status=='published'))
            if other and other.reviewed_at and other.sources:
                alternatives.append({'code':other.code,'title':other.title,'detail':detail.strip()})
    else:
        guide=None
    content=snapshot(public_knowledge(guide) if guide else None,alternatives)
    if guide:
        content['guide']['reviewed_at']=guide.reviewed_at.isoformat()
    return content | {'answers':{},'completed':{},'stage':'unknown','spread':'unknown','updated_at':None}


def assessment_response(data):
    return data | {'alignment':alignment(data['answers']),'stages':STAGES,'spread_options':SPREAD}


@app.get('/api/v1/diagnoses/{id}/assessment')
def diagnosis_assessment(id:str,user=Depends(farmer),db=Depends(get_db)):
    return assessment_response(assessment_for(db,owned(db,Diagnosis,id,user)))


@app.patch('/api/v1/diagnoses/{id}/assessment')
def edit_assessment(id:str,data:AssessmentEdit,user=Depends(farmer),db=Depends(get_db)):
    record=db.scalar(select(Diagnosis).where(Diagnosis.id==id,Diagnosis.user_id==user.id).with_for_update())
    if record is None: raise HTTPException(404,'Không tìm thấy dữ liệu.')
    saved=assessment_for(db,record)
    if data.version!=saved['version']:
        raise HTTPException(409,'Phiên bản hướng dẫn đã thay đổi. Tải lại bản ghi trước khi lưu.')
    if data.question is not None:
        if data.answer is None or data.question>=len(saved['questions']):
            raise HTTPException(422,'Câu hỏi hoặc câu trả lời không hợp lệ.')
        saved['answers'][str(data.question)] = data.answer
    if data.task is not None:
        if data.done is None or data.task>=len(saved['tasks']):
            raise HTTPException(422,'Mục việc cần làm không hợp lệ.')
        key=str(data.task)
        if data.done: saved['completed'].setdefault(key,now().isoformat())
        else: saved['completed'].pop(key,None)
    if data.stage is not None:
        if data.stage not in {*STAGES,'unknown'}: raise HTTPException(422,'Giai đoạn không hợp lệ.')
        saved['stage']=data.stage
    if data.spread is not None:
        if data.spread not in SPREAD: raise HTTPException(422,'Mức độ lan không hợp lệ.')
        saved['spread']=data.spread
    saved['updated_at']=now().isoformat()
    record.assessment=dict(saved)
    db.commit()
    return assessment_response(saved)

class TrackingStatus(Strict):
    closed: bool


def lock_tracking_write(db,user):
    db.execute(select(User.id).where(User.id==user.id).with_for_update())


def tracking_members(diagnosis):
    group = Diagnosis.tracking_id==diagnosis.tracking_id if diagnosis.tracking_id else Diagnosis.id==diagnosis.id
    return select(Diagnosis).where(Diagnosis.user_id==diagnosis.user_id,group)

@app.get('/api/v1/tracking')
def tracking_overview(user=Depends(farmer),db=Depends(get_db),offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100)):
    group=func.coalesce(Diagnosis.tracking_id,Diagnosis.id)
    ranked=select(Diagnosis.id.label('id'),
                  func.row_number().over(partition_by=group,order_by=(Diagnosis.created_at.desc(),Diagnosis.id.desc())).label('position'),
                  func.count().over(partition_by=group).label('check_count')).where(Diagnosis.user_id==user.id).subquery()
    query=select(Diagnosis,ranked.c.check_count).join(ranked,ranked.c.id==Diagnosis.id).where(ranked.c.position==1)
    rows=db.execute(query.order_by(Diagnosis.created_at.desc(),Diagnosis.id.desc()).offset(offset).limit(limit))
    return [{'id':row.id,'tracking_id':row.tracking_id or row.id,'season_id':row.season_id,
             'checked_at':row.created_at,'closed_at':row.tracking_closed_at,'check_count':count,
             'label':row.result['display_label_vi']} for row,count in rows]


@app.get('/api/v1/diagnoses/{id}/tracking')
def diagnosis_tracking(id:str,user=Depends(farmer),db=Depends(get_db),checks_offset:int=Query(0,ge=0)):
    diagnosis=owned(db,Diagnosis,id,user)
    members=tracking_members(diagnosis)
    member_ids=members.with_only_columns(Diagnosis.id)
    ordered=members.order_by(Diagnosis.created_at.desc(),Diagnosis.id.desc())
    checks=db.scalars(ordered.offset(checks_offset).limit(30)).all()
    latest=checks[0] if checks and checks_offset==0 else db.scalar(ordered.limit(1))
    if latest is None:
        raise HTTPException(404,'Không tìm thấy dữ liệu.')
    checks_total=db.scalar(select(func.count()).select_from(member_ids.subquery()))
    journal=db.scalars(select(Activity).where(Activity.user_id==user.id,Activity.diagnosis_id.in_(member_ids))
                       .order_by(Activity.created_at.desc(),Activity.id.desc()).limit(30)).all()
    latest_observed=bool(db.scalar(select(Activity.id).where(Activity.user_id==user.id,
                         Activity.diagnosis_id==latest.id,Activity.kind=='observation').limit(1)))
    return {
        'closed_at':diagnosis.tracking_closed_at,
        'latest_observed':latest_observed,
        'checks_total':checks_total,
        'checks':[{'id':item.id,'created_at':item.created_at,'label':item.result['display_label_vi'],
                   'has_image':bool(item.image_key),'raw_score':item.result.get('raw_score')} for item in checks],
        'journal':[serialize(item) for item in journal],
    }


@app.patch('/api/v1/diagnoses/{id}/tracking')
def edit_diagnosis_tracking(id:str,data:TrackingStatus,user=Depends(farmer),db=Depends(get_db)):
    lock_tracking_write(db,user)
    diagnosis=owned(db,Diagnosis,id,user)
    if bool(diagnosis.tracking_closed_at)==data.closed:
        return {'closed_at':diagnosis.tracking_closed_at}
    members=tracking_members(diagnosis)
    member_ids=members.with_only_columns(Diagnosis.id)
    closed_at=now() if data.closed else None
    if data.closed:
        recent=db.scalars(members.order_by(Diagnosis.created_at.desc(),Diagnosis.id.desc()).limit(2)).all()
        if len(recent)<2 or not db.scalar(select(Activity.id).where(Activity.user_id==user.id,
                Activity.diagnosis_id==recent[0].id,Activity.kind=='observation').limit(1)):
            raise HTTPException(409,'Hãy kiểm tra lại và ghi tình trạng của lần gần nhất trước khi kết thúc.')
        db.execute(update(Activity).where(Activity.user_id==user.id,Activity.diagnosis_id.in_(member_ids),
                   Activity.kind=='reminder',Activity.completed==False).values(completed=True))
    db.execute(update(Diagnosis).where(Diagnosis.id.in_(member_ids)).values(tracking_closed_at=closed_at))
    db.commit()
    return {'closed_at':closed_at}


@app.get('/api/v1/diagnoses/{id}/image')
def private_image(id:str,user=Depends(farmer),db=Depends(get_db)):
    d=owned(db,Diagnosis,id,user)
    if not d.image_key or not (storage/d.image_key).is_file(): raise HTTPException(404,'Không có ảnh đã lưu.')
    mime={'.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp'}.get(Path(d.image_key).suffix,'image/jpeg')
    return FileResponse(storage/d.image_key,media_type=mime,headers={'Cache-Control':'private, no-store'})

@app.get('/api/v1/diagnoses/{id}/thumbnail')
def private_thumbnail(id:str,user=Depends(farmer),db=Depends(get_db)):
    record=owned(db,Diagnosis,id,user)
    if not record.image_key:
        raise HTTPException(404,'Không có ảnh đã lưu.')
    try:
        with Image.open(storage/record.image_key) as source:
            image=ImageOps.exif_transpose(source).convert('RGB')
            image.thumbnail((144,144),Image.Resampling.LANCZOS)
            output=io.BytesIO()
            image.save(output,'JPEG',quality=80)
    except (OSError,Image.DecompressionBombError):
        raise HTTPException(404,'Không có ảnh đã lưu.')
    return Response(output.getvalue(),media_type='image/jpeg',headers={'Cache-Control':'private, no-store'})

@app.delete('/api/v1/diagnoses/{id}')
def delete_diagnosis(id:str,user=Depends(farmer),db=Depends(get_db)):
    lock_tracking_write(db,user)
    d=owned(db,Diagnosis,id,user)
    for a in db.scalars(select(Activity).where(Activity.diagnosis_id==id)): a.diagnosis_id=None
    db.execute(delete(Feedback).where(Feedback.diagnosis_id==id))
    key=d.image_key; db.delete(d); db.commit()
    if key: (storage/key).unlink(missing_ok=True)
    return {'message':'Đã xóa kết quả và ảnh đang lưu.'}

@app.post('/api/v1/diagnoses/{id}/feedback',status_code=201)
def feedback(id:str,data:FeedbackInput,user=Depends(farmer),db=Depends(get_db)):
    owned(db,Diagnosis,id,user); item=Feedback(user_id=user.id,diagnosis_id=id,**data.model_dump())
    db.add(item); db.commit(); return {'message':'Đã ghi nhận ý kiến chưa xác minh. Không tự thay đổi nhãn hoặc đưa vào huấn luyện.'}

@app.get('/api/v1/me/feedback')
def my_feedback(user=Depends(farmer),db=Depends(get_db)):
    return [serialize(f) for f in db.scalars(select(Feedback).where(Feedback.user_id==user.id).order_by(Feedback.created_at.desc()))]

@app.patch('/api/v1/feedback/{id}')
def update_feedback(id:str,data:FeedbackInput,user=Depends(farmer),db=Depends(get_db)):
    item=owned(db,Feedback,id,user)
    item.notes=data.notes;item.consented_to_review=data.consented_to_review
    db.commit();return serialize(item)

@app.delete('/api/v1/feedback/{id}')
def remove_feedback(id:str,user=Depends(farmer),db=Depends(get_db)):
    db.delete(owned(db,Feedback,id,user));db.commit();return {'message':'Đã xóa phản hồi.'}

@app.get('/api/v1/admin/feedback')
def consented_feedback(user=Depends(admin),db=Depends(get_db),offset:int=0,limit:int=50):
    rows=db.scalars(select(Feedback).where(Feedback.consented_to_review==True).order_by(Feedback.created_at.desc(),Feedback.id).offset(max(offset,0)).limit(min(max(limit,1),100)))
    # Consent permits reading the note, not the farmer's identity, image or plot.
    return [{'id':item.id,'notes':item.notes,'created_at':item.created_at,'status':'unverified'} for item in rows]

@app.get('/api/v1/activities')
def activities(user=Depends(farmer),db=Depends(get_db),season_id:str|None=None,due_only:bool=False,
               status:Literal['all','pending','due','done','intervention','observation']='all',
               offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100)):
    if season_id: owned(db,Season,season_id,user)
    q=select(Activity).where(Activity.user_id==user.id)
    if season_id: q=q.where(Activity.season_id==season_id)
    if due_only or status=='due':
        q=q.where(Activity.kind=='reminder',Activity.completed==False,Activity.due_at<=now())
    elif status in ('pending','done'):
        q=q.where(Activity.kind=='reminder',Activity.completed==(status=='done'))
    elif status in ('intervention','observation'):
        q=q.where(Activity.kind==status)
    order=Activity.due_at.asc() if due_only or status in ('pending','due') else Activity.due_at.desc()
    return [serialize(a) for a in db.scalars(q.order_by(order,Activity.id).offset(offset).limit(limit))]

@app.get('/api/v1/activities/{id}/calendar.ics')
def export_reminder(id:str,user=Depends(farmer),db=Depends(get_db)):
    item=owned(db,Activity,id,user)
    if item.kind!='reminder' or item.completed:
        raise HTTPException(422,'Chỉ xuất lịch cho nhắc việc chưa hoàn thành.')
    return Response(calendar_event(serialize(item) | {'due_at':item.due_at}),media_type='text/calendar',
                    headers={'Content-Disposition':'attachment; filename="lua-khoe-reminder.ics"','Cache-Control':'no-store'})

@app.post('/api/v1/activities',status_code=201)
def create_activity(data:ActivityInput,user=Depends(farmer),db=Depends(get_db)):
    if data.diagnosis_id and data.kind=='reminder' and not data.completed:
        lock_tracking_write(db,user)
        if owned(db,Diagnosis,data.diagnosis_id,user).tracking_closed_at:
            raise HTTPException(409,'Hãy mở lại đợt theo dõi trước khi đặt lịch.')
    links(db,user,data.season_id,data.diagnosis_id)
    a=Activity(user_id=user.id,**data.model_dump()); db.add(a); db.commit(); return serialize(a)

@app.patch('/api/v1/activities/{id}')
def edit_activity(id:str,data:ActivityInput,user=Depends(farmer),db=Depends(get_db)):
    if data.diagnosis_id and data.kind=='reminder' and not data.completed:
        lock_tracking_write(db,user)
        if owned(db,Diagnosis,data.diagnosis_id,user).tracking_closed_at:
            raise HTTPException(409,'Hãy mở lại đợt theo dõi trước khi đặt lịch.')
    a=owned(db,Activity,id,user); links(db,user,data.season_id,data.diagnosis_id)
    for k,v in data.model_dump().items(): setattr(a,k,v)
    db.commit(); return serialize(a)

@app.delete('/api/v1/activities/{id}')
def delete_activity(id:str,user=Depends(farmer),db=Depends(get_db)):
    db.delete(owned(db,Activity,id,user)); db.commit(); return {'message':'Đã xóa ghi chép.'}

@app.get('/api/v1/stats/overview')
def stats(user=Depends(farmer),db=Depends(get_db),season_id:str|None=None,from_date:date|None=None,to_date:date|None=None,label:str|None=None,plot_id:str|None=None):
    q=diagnosis_query(db,user,plot_id,season_id,from_date,to_date,label)
    rows=db.scalars(q).all()
    return {'total':len(rows),'labels':dict(Counter(d.result['predicted_class'] for d in rows)),
            'label_names':{d.result['predicted_class']:d.result.get('display_label_vi',d.result['predicted_class']) for d in rows},
            'daily':dict(sorted(Counter(d.created_at.date().isoformat() for d in rows).items())),
            'notice':'Thống kê lượt ảnh đã ghi nhận, không phải tỷ lệ bệnh của khu vực.'}

@app.get('/api/v1/reports/overview.pdf')
def stats_report(user=Depends(farmer),db=Depends(get_db),season_id:str|None=None,from_date:date|None=None,to_date:date|None=None,label:str|None=None,plot_id:str|None=None):
    from .report import create_pdf
    q=diagnosis_query(db,user,plot_id,season_id,from_date,to_date,label)
    rows=db.scalars(q.order_by(Diagnosis.created_at,Diagnosis.id)).all()
    sq=select(Season).where(Season.user_id==user.id)
    if plot_id:sq=sq.where(Season.plot_id==plot_id)
    if season_id:sq=sq.where(Season.id==season_id)
    seasons=db.scalars(sq).all()
    plot_ids={s.plot_id for s in seasons}
    plots=db.scalars(select(Plot).where(Plot.user_id==user.id,Plot.id.in_(plot_ids))).all()
    title=db.get(Plot,plot_id).name if plot_id else 'Các ruộng trong bộ lọc'
    summary={'name':title,'area_m2':db.get(Plot,plot_id).area_m2 if plot_id else sum(p.area_m2 for p in plots)}
    filters={'from_date':str(from_date) if from_date else 'Không giới hạn','to_date':str(to_date) if to_date else 'Không giới hạn',
             'label':label or 'Tất cả','season':db.get(Season,season_id).rice_variety if season_id else 'Tất cả'}
    content=create_pdf(summary,[serialize(s) for s in seasons],[serialize(d) for d in rows],[],filters=filters)
    return Response(content,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="bao-cao-thong-ke.pdf"'})

@app.get('/api/v1/reports/plots/{id}.pdf')
def plot_report(id:str,user=Depends(farmer),db=Depends(get_db)):
    from .report import create_pdf
    plot=owned(db,Plot,id,user)
    seasons=db.scalars(select(Season).where(Season.plot_id==id)).all()
    rows=db.scalars(select(Diagnosis).where(Diagnosis.user_id==user.id,Diagnosis.season_id.in_([s.id for s in seasons])).order_by(Diagnosis.created_at)).all()
    activities=db.scalars(select(Activity).where(Activity.user_id==user.id,Activity.season_id.in_([s.id for s in seasons])).order_by(Activity.due_at)).all()
    content=create_pdf(serialize(plot),[serialize(s) for s in seasons],[serialize(d) for d in rows],[serialize(a) for a in activities])
    return Response(content,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="bao-cao-ruong.pdf"'})

@app.get('/api/v1/me/data')
def export_data(user=Depends(farmer),db=Depends(get_db)):
    data={cls.__tablename__:[serialize(v) for v in db.scalars(select(cls).where(cls.user_id==user.id))] for cls in (Plot,Diagnosis,Activity,Feedback)}
    ids=[p['id'] for p in data['plots']]
    data['crop_seasons']=[serialize(v) for v in db.scalars(select(Season).where(Season.plot_id.in_(ids)))]
    data['push_subscriptions']=[{'id':v.id,'created_at':v.created_at.isoformat()} for v in db.scalars(select(PushSubscription).where(PushSubscription.user_id==user.id))]
    return data

class DeleteData(Strict):
    password:str
    confirmed:Literal[True]

@app.delete('/api/v1/me/data')
def erase(data:DeleteData,user=Depends(farmer),db=Depends(get_db)):
    if not verify(data.password,user.password_hash): raise HTTPException(401,'Mật khẩu không đúng.')
    lock_tracking_write(db,user)
    keys=[d.image_key for d in db.scalars(select(Diagnosis).where(Diagnosis.user_id==user.id)) if d.image_key]
    for cls in (PushSubscription,Feedback,Activity,Diagnosis): db.execute(delete(cls).where(cls.user_id==user.id))
    ids=select(Plot.id).where(Plot.user_id==user.id)
    db.execute(delete(Season).where(Season.plot_id.in_(ids))); db.execute(delete(Plot).where(Plot.user_id==user.id)); db.commit()
    for key in keys: (storage/key).unlink(missing_ok=True)
    return {'message':'Đã xóa dữ liệu ruộng và ảnh đang lưu. Bản sao lưu có thời hạn riêng theo chính sách vận hành.'}

@app.get('/api/v1/diseases')
def diseases(db=Depends(get_db)):
    return [public_knowledge(k) for k in db.scalars(select(Knowledge).where(Knowledge.status=='published'))]

def public_knowledge(record):
    """Public articles exclude internal reviewer identities and reuse notes."""
    return {key:getattr(record,key) for key in ('id','code','title','content','reviewed_at')} | {
        'sources':[{key:source.get(key) for key in ('title','url','publisher','checked_at')}
                   for source in record.sources]
    }

@app.get('/api/v1/knowledge/search')
def knowledge_search(q:str=Query(...,min_length=2,max_length=300),db=Depends(get_db)):
    articles=[public_knowledge(k) for k in db.scalars(select(Knowledge).where(Knowledge.status=='published'))]
    return {'mode':'local_extracts','results':search_articles(q,articles),
            'message':'Trích nguyên văn tài liệu đã xuất bản; không phải câu trả lời chẩn đoán hoặc tư vấn riêng.'}

@app.post('/api/v1/assistant/ask')
def ask_assistant(data:AssistantQuestion,user=Depends(farmer),db=Depends(get_db)):
    articles=[public_knowledge(k) for k in db.scalars(select(Knowledge).where(Knowledge.status=='published'))]
    try:return rag.answer(data.question,articles)
    except rag.RAGUnavailable as error:raise HTTPException(503,str(error))
    except rag.RAGBusy as error:raise HTTPException(429,str(error))

@app.get('/api/v1/growth-stages')
def growth_stages():
    return [{'code':code,'name':name} for code,name in STAGES.items()]

@app.get('/api/v1/diseases/{code}/guidance')
def stage_advice(code:str,stage:str=Query(...,max_length=40),db=Depends(get_db)):
    if stage not in STAGES:raise HTTPException(422,'Chọn giai đoạn sinh trưởng trong danh sách.')
    record=db.scalar(select(Knowledge).where(Knowledge.code==code,Knowledge.status=='published'))
    return guidance(public_knowledge(record) if record else None,stage)

@app.get('/api/v1/diseases/{code}')
def disease(code:str,db=Depends(get_db)):
    k=db.scalar(select(Knowledge).where(Knowledge.code==code,Knowledge.status=='published'))
    if not k: raise HTTPException(404,'Chưa có nội dung đã được kiểm duyệt.')
    return public_knowledge(k)

@app.get('/api/v1/admin/knowledge')
def admin_knowledge(user=Depends(admin),db=Depends(get_db),search:str=Query('',max_length=120),status:Literal['all','draft','reviewed','published','archived']='all',offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100)):
    q=select(Knowledge)
    if search.strip():
        term=search.strip().replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
        q=q.where(Knowledge.title.ilike('%'+term+'%',escape='\\') | Knowledge.code.ilike('%'+term+'%',escape='\\'))
    if status!='all':q=q.where(Knowledge.status==status)
    return [serialize(k) for k in db.scalars(q.order_by(Knowledge.created_at.desc(),Knowledge.id).offset(offset).limit(limit))]

@app.post('/api/v1/admin/knowledge',status_code=201)
def create_knowledge(data:KnowledgeInput,user=Depends(admin),db=Depends(get_db)):
    if predictor.model is None or data.code not in predictor.labels: raise HTTPException(422,'Mã bệnh phải thuộc nhãn mô hình đã xác minh.')
    k=Knowledge(created_by=user.id,**data.model_dump(mode='json')); db.add(k); db.flush(); audit(db,user,'create_draft',k.id); db.commit(); return serialize(k)

@app.post('/api/v1/admin/knowledge/import-reference-drafts')
def import_reference_drafts(data:Confirm,include_updates:bool=False,user=Depends(admin),db=Depends(get_db)):
    if predictor.model is None:
        raise HTTPException(503,'Chưa thể đối chiếu danh sách nhãn của mô hình.')
    proposals = [KnowledgeInput.model_validate(draft) for draft in REFERENCE_DRAFTS]
    # Serialize bulk imports with other knowledge writes in PostgreSQL.
    if db.get_bind().dialect.name == 'postgresql':
        db.execute(text('LOCK TABLE knowledge_revisions IN SHARE ROW EXCLUSIVE MODE'))
    supported = set(predictor.labels)
    existing = {}
    for revision in db.scalars(select(Knowledge).where(Knowledge.code.in_(supported))):
        existing.setdefault(revision.code, []).append(revision)
    created, skipped, unsupported = [], [], []
    for proposal in proposals:
        if proposal.code not in supported:
            unsupported.append(proposal.code)
            continue
        payload = proposal.model_dump(mode='json')
        revisions = existing.get(proposal.code, [])
        if revisions and (not include_updates or any(
            revision.title == payload['title'] and revision.content == payload['content']
            and revision.sources == payload['sources'] for revision in revisions
        )):
            skipped.append(proposal.code)
        else:
            revision = Knowledge(created_by=user.id,status='draft',**payload)
            db.add(revision)
            db.flush()
            audit(db,user,'create_draft',revision.id)
            created.append(proposal.code)
    db.commit()
    return {'created':created,'skipped':skipped,'unsupported':unsupported}

@app.post('/api/v1/admin/knowledge/{id}/{action}')
def workflow(id:str,action:Literal['review','publish','archive','rollback'],data:Confirm,user=Depends(admin),db=Depends(get_db)):
    # Serialize all transitions for a disease to avoid two published revisions.
    k=db.get(Knowledge,id)
    if not k: raise HTTPException(404,'Không tìm thấy bản nội dung.')
    list(db.scalars(select(Knowledge).where(Knowledge.code==k.code).order_by(Knowledge.id).with_for_update().execution_options(populate_existing=True)))
    if action=='review':
        if k.status!='draft' or not k.sources or not all(k.content.get(x) for x in ('symptoms','field_check','prevention')):
            raise HTTPException(422,'Cần nguồn, triệu chứng, bước đối chiếu và phòng ngừa trước khi duyệt.')
        k.status='reviewed'; k.reviewed_by=user.id; k.reviewed_at=now()
    elif action in ('publish','rollback'):
        if not k.reviewed_by or not k.sources or k.status not in ('reviewed','archived'):
            raise HTTPException(422,'Chỉ xuất bản hoặc phục hồi phiên bản đã duyệt.')
        for old in db.scalars(select(Knowledge).where(Knowledge.code==k.code,Knowledge.status=='published')): old.status='archived'
        db.flush()
        k.status='published'
    else: k.status='archived'
    audit(db,user,action,k.id)
    try: db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409,'Nội dung vừa được cập nhật. Hãy tải lại danh sách.')
    return serialize(k)

@app.get('/api/v1/admin/users')
def users(user=Depends(admin),db=Depends(get_db),search:str=Query('',max_length=120),status:Literal['all','active','inactive']='all',offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100)):
    q=select(User)
    if search.strip():
        term=search.strip().replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
        q=q.where(User.name.ilike('%'+term+'%',escape='\\') | User.email.ilike('%'+term+'%',escape='\\'))
    if status!='all':q=q.where(User.active==(status=='active'))
    rows=db.scalars(q.order_by(User.created_at.desc(),User.id).offset(offset).limit(limit))
    return [{**profile(u),'email':u.email[:1]+'***@'+u.email.rsplit('@',1)[-1]} for u in rows]

class UserStatus(Confirm):
    active:bool

@app.patch('/api/v1/admin/users/{id}/status')
def user_status(id:str,data:UserStatus,user=Depends(admin),db=Depends(get_db)):
    target=db.get(User,id)
    if not target or target.role!='farmer': raise HTTPException(403,'Chỉ được khóa hoặc mở tài khoản nông dân.')
    target.active=data.active
    db.execute(delete(Session).where(Session.user_id==id)); audit(db,user,'activate' if data.active else 'deactivate',id); db.commit()
    return {**profile(target),'email':target.email[:1]+'***@'+target.email.rsplit('@',1)[-1]}

@app.get('/api/v1/admin/audit')
def audits(user=Depends(admin),db=Depends(get_db),action:str=Query('',max_length=80),offset:int=Query(0,ge=0),limit:int=Query(20,ge=1,le=100)):
    q=select(Audit)
    if action:q=q.where(Audit.action==action)
    return [serialize(a) for a in db.scalars(q.order_by(Audit.created_at.desc(),Audit.id).offset(offset).limit(limit))]

@app.get('/api/v1/admin/overview')
def overview(user=Depends(admin),db=Depends(get_db)):
    statuses=Counter(db.scalars(select(Knowledge.status)).all())
    return {'knowledge':dict(statuses),'model':predictor.health_status(),
            'predictions':{'saved':db.scalar(select(func.count()).select_from(Diagnosis)),
                           'requires_review':db.scalar(select(func.count()).select_from(Diagnosis).where(Diagnosis.result['quality_status'].as_string()=='uncertain'))},
            'feedback':{'received':db.scalar(select(func.count()).select_from(Feedback)),
                        'consented':db.scalar(select(func.count()).select_from(Feedback).where(Feedback.consented_to_review==True))}}
