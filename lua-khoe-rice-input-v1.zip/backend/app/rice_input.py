"""Compare uploaded photos with rice references before classifying disease."""
import hashlib
import json
import math

import torch
from torchvision.models import MobileNet_V3_Large_Weights, mobilenet_v3_large


class RetakePhoto(ValueError):
    """A different photo is needed before giving any disease guidance."""


OUTSIDE_RICE = (
    'Chưa nhận thấy lá lúa trong ảnh. Hãy chụp lại một lá lúa rõ nét, '
    'để lá chiếm phần lớn khung hình.'
)
AMBIGUOUS_PAIR = (
    'Chưa đủ căn cứ phân biệt Tungro và đốm nâu. Hãy chụp rõ vết trên lá '
    'và chụp thêm toàn khóm để đối chiếu.'
)
RICE_NEIGHBORS = 5
PET_THRESHOLD = 0.80
DISEASE_PAIR_MAXIMUM_GAP = 0.15


def image_scores(model, images, reference):
    features = model.avgpool(model.features(images)).flatten(1)
    embeddings = torch.nn.functional.normalize(features, dim=1)
    similarities = (embeddings @ reference.T).topk(RICE_NEIGHBORS, dim=1).values.mean(dim=1)
    # ImageNet-1K indices 151–268 are dogs and 281–285 are domestic cats.
    scores = model.classifier(features).softmax(dim=1)
    pet_scores = scores[:, 151:269].sum(dim=1) + scores[:, 281:286].sum(dim=1)
    return similarities, pet_scores


class RiceInputGuard:
    def __init__(self, root):
        weights = root / 'rice_input.pt'
        metadata = json.loads((root / 'rice_input.json').read_text(encoding='utf-8'))
        if hashlib.sha256(weights.read_bytes()).hexdigest() != metadata['sha256']:
            raise ValueError('Rice input weights checksum mismatch')
        bundle = torch.load(weights, map_location='cpu', weights_only=True)
        self.model = mobilenet_v3_large(weights=None)
        self.model.load_state_dict(bundle['model_state_dict'])
        self.model.eval()
        self.reference = bundle['reference']
        self.minimum = float(metadata['minimum_similarity'])
        if (self.reference.ndim != 2 or self.reference.shape[0] < RICE_NEIGHBORS
                or self.reference.shape[1] != self.model.classifier[0].in_features
                or not torch.isfinite(self.reference).all() or not 0 < self.minimum < 1):
            raise ValueError('Invalid rice input reference set')
        self.transform = MobileNet_V3_Large_Weights.IMAGENET1K_V1.transforms()

    def check(self, image):
        with torch.inference_mode():
            similarity, pet = image_scores(self.model, self.transform(image).unsqueeze(0), self.reference)
        if not math.isfinite(float(similarity[0])) or similarity[0] < self.minimum or pet[0] >= PET_THRESHOLD:
            raise RetakePhoto(OUTSIDE_RICE)


def check_disease_pair(top):
    if len(top) < 2:
        return
    first, second = top[:2]
    if ({first['label'], second['label']} == {'Rice_Tungro', 'Brown_Spot'}
            and first['score'] - second['score'] <= DISEASE_PAIR_MAXIMUM_GAP):
        raise RetakePhoto(AMBIGUOUS_PAIR)
