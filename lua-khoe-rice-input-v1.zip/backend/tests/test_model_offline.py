import io
import os
import sys
import unittest
import json
import tempfile
from unittest.mock import patch
from pathlib import Path
from PIL import Image
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.ml import PredictionService
from app.rice_input import AMBIGUOUS_PAIR, OUTSIDE_RICE, RetakePhoto, RiceInputGuard, check_disease_pair

class ModelInputTests(unittest.TestCase):
    def setUp(self): self.service=PredictionService()
    def test_invalid_bytes(self):
        with self.assertRaises(ValueError): self.service.validate_image(b'fake jpg')
    def test_large_bytes(self):
        with self.assertRaises(ValueError): self.service.validate_image(b'x'*(10*1024*1024+1))
    def test_too_small(self):
        b=io.BytesIO();Image.new('RGB',(20,20)).save(b,'PNG')
        with self.assertRaises(ValueError):self.service.validate_image(b.getvalue())
    def test_gif_disallowed(self):
        b=io.BytesIO();Image.new('RGB',(100,100)).save(b,'GIF')
        with self.assertRaises(ValueError):self.service.validate_image(b.getvalue())
    def test_valid_png(self):
        b=io.BytesIO();Image.new('RGB',(100,100)).save(b,'PNG')
        self.assertEqual(self.service.validate_image(b.getvalue()).mode,'RGB')
    def test_missing_model_fails_closed(self):
        old=os.environ.get('MODEL_DIR');os.environ['MODEL_DIR']='nonexistent-model'
        try:
            self.service.load_model();self.assertFalse(self.service.health_status()['ready'])
            with self.assertRaises(RuntimeError):self.service.predict(Image.new('RGB',(100,100)))
        finally:
            if old is not None:os.environ['MODEL_DIR']=old
            else:os.environ.pop('MODEL_DIR',None)

    def test_corrupted_weights_rejected_before_deserialization(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'weights.pt').write_bytes(b'CORRUPTED TEST FIXTURE')
            (root/'metadata.json').write_text(json.dumps({'weights_sha256':'0'*64,'architecture':'efficientnet_b0','class_names':['fixture_a','fixture_b'],'display_names_vi':{'fixture_a':'A','fixture_b':'B'}}))
            with patch.dict(os.environ,{'MODEL_DIR':directory}),patch('torch.load') as loader:
                self.service.load_model()
                loader.assert_not_called()
                self.assertFalse(self.service.health_status()['ready'])

    def test_outside_photo_stops_before_disease_model(self):
        photo = Image.new('RGB', (100, 100))
        with patch.object(self.service, 'input_guard') as guard, patch.object(self.service, 'predict') as predict:
            guard.check.side_effect = RetakePhoto(OUTSIDE_RICE)
            with self.assertRaisesRegex(RetakePhoto, 'Chưa nhận thấy lá lúa'):
                self.service.predict_upload(photo)
            predict.assert_not_called()

    def test_pet_match_requires_retake_even_with_high_rice_similarity(self):
        guard = RiceInputGuard.__new__(RiceInputGuard)
        guard.minimum = 0.72
        guard.model = guard.reference = None
        guard.transform = lambda _: torch.zeros(3, 224, 224)
        with patch('app.rice_input.image_scores', return_value=(torch.tensor([0.90]), torch.tensor([0.99]))):
            with self.assertRaises(RetakePhoto):
                guard.check(Image.new('RGB', (224, 224)))

    def test_close_tungro_and_brown_spot_require_another_photo(self):
        for first, second in (('Rice_Tungro', 'Brown_Spot'), ('Brown_Spot', 'Rice_Tungro')):
            with self.subTest(first=first):
                with self.assertRaises(RetakePhoto) as error:
                    check_disease_pair([{'label': first, 'score': 0.50}, {'label': second, 'score': 0.40}])
                self.assertEqual(str(error.exception), AMBIGUOUS_PAIR)
                check_disease_pair([{'label': first, 'score': 0.80}, {'label': second, 'score': 0.15}])
        check_disease_pair([{'label': 'Blast', 'score': 0.50}, {'label': 'Brown_Spot', 'score': 0.40}])

if __name__=='__main__':unittest.main()
