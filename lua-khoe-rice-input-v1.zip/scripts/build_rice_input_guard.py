"""Build the offline rice-photo guard from screened rice reference images."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
import sys

from PIL import Image, ImageOps
import torch
from torch.nn.functional import normalize
from torchvision.models import MobileNet_V3_Large_Weights, mobilenet_v3_large

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
from app.rice_input import PET_THRESHOLD, image_scores


def load_rows(manifests, name):
    with (manifests / f'{name}.csv').open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', type=Path)
    parser.add_argument('manifests', type=Path)
    parser.add_argument('imagenet_weights', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    torch.set_num_threads(4)
    model = mobilenet_v3_large(weights=None).to(device).eval()
    model.load_state_dict(torch.load(args.imagenet_weights, map_location='cpu', weights_only=True))
    transform = MobileNet_V3_Large_Weights.IMAGENET1K_V1.transforms()

    def batches(rows):
        for start in range(0, len(rows), 32):
            images = []
            for row in rows[start:start + 32]:
                with Image.open(args.dataset / row['path']) as image:
                    images.append(transform(ImageOps.exif_transpose(image).convert('RGB')))
            yield torch.stack(images).to(device)

    rng = random.Random(4216)
    train = load_rows(args.manifests, 'train')
    labels = sorted({row['label'] for row in train})
    reference_rows = [row for label in labels
                      for row in rng.sample([item for item in train if item['label'] == label], 80)]
    with torch.inference_mode():
        reference = torch.cat([normalize(model.avgpool(model.features(batch)).flatten(1), dim=1)
                               for batch in batches(reference_rows)])

        def scores(rows):
            return torch.cat([torch.stack(image_scores(model, batch, reference), dim=1)
                              for batch in batches(rows)]).cpu()

        calibration = scores(load_rows(args.manifests, 'validation'))
        minimum = float(torch.quantile(calibration[:, 0], 0.01))
        held_out = scores(load_rows(args.manifests, 'test_unlinked'))
        accepted = (held_out[:, 0] >= minimum) & (held_out[:, 1] < PET_THRESHOLD)

    args.output.mkdir(parents=True, exist_ok=True)
    weights = args.output / 'rice_input.pt'
    with weights.open('xb') as stream:
        torch.save({'model_state_dict': {key: value.cpu() for key, value in model.state_dict().items()},
                    'reference': reference.cpu()}, stream)
    metadata = {
        'sha256': hashlib.sha256(weights.read_bytes()).hexdigest(),
        'encoder': 'torchvision mobilenet_v3_large IMAGENET1K_V1',
        'reference_dataset': 'riceleaf_v1 (screened splits)',
        'reference_count': len(reference_rows),
        'calibration_count': len(calibration),
        'calibration_quantile': 0.01,
        'minimum_similarity': minimum,
        'pet_score_threshold': PET_THRESHOLD,
        'holdout_positive_count': len(held_out),
        'holdout_positive_accepted': int(accepted.sum()),
    }
    (args.output / 'rice_input.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(metadata, indent=2), flush=True)


if __name__ == '__main__':
    main()
