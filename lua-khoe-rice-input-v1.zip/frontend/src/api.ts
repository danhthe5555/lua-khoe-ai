export type Row=Record<string,any>;
export class ApiError extends Error {
  constructor(message:string, readonly status:number, readonly code?:string){super(message)}
}
let csrf='';
let sessionGeneration=0;
export function setCsrf(value:string){if(csrf!==value)sessionGeneration++;csrf=value}
export async function api(path:string,method='GET',data?:unknown,headers:Record<string,string>={}){
  const generation=sessionGeneration;
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),60000);
  try{
    const form=data instanceof FormData;
    const response=await fetch(`/api/v1${path}`,{method,credentials:'include',cache:'no-store',signal:controller.signal,headers:{...(form?{}:{'Content-Type':'application/json'}),...(csrf?{'X-CSRF-Token':csrf}:{}),...headers},body:data===undefined?undefined:form?data:JSON.stringify(data)});
    if(generation!==sessionGeneration)throw new Error('Phiên đăng nhập đã thay đổi. Vui lòng tải lại dữ liệu.');
    const result=await response.json().catch(()=>null);
    if(generation!==sessionGeneration)throw new Error('Phiên đăng nhập đã thay đổi. Vui lòng tải lại dữ liệu.');
    if(response.status===401&&path!=='/auth/login')window.dispatchEvent(new Event('session-expired'));
    if(!result)throw new Error('Máy chủ chưa phản hồi đúng. Vui lòng thử lại sau.');
    if(!response.ok){throw new ApiError(result.error?.message||'Không thể thực hiện. Hãy thử lại.',response.status,result.error?.code)}
    return result;
  }catch(error){if(error instanceof TypeError||error instanceof DOMException)throw new Error('Kết nối gián đoạn hoặc quá thời gian. Hãy kiểm tra mạng và thử lại.');throw error}
  finally{clearTimeout(timer)}
}
