import {useEffect,useRef,useState} from 'react';
import {Link} from 'react-router-dom';
import {api,ApiError,type Row} from './api';
import {Alert,Button,Card,Empty,Heading} from './ui';

type Item={
  file:File;key:string;status:'pending'|'running'|'done'|'error'|'retake';result?:Row;error?:string;
};

const statusLabels={
  pending:'Chờ phân tích',running:'Đang phân tích…',done:'Đã lưu vào lịch sử',error:'Chưa phân tích được',retake:'Cần ảnh mới',
};

export function BatchPredict(){
  const [items,setItems]=useState<Item[]>([]);
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('');
  const [error,setError]=useState('');
  const stop=useRef(false);
  const running=useRef(false);

  useEffect(()=>()=>{stop.current=true},[]);

  function choose(files:File[]){
    setMessage('');
    setError('');
    if(files.length>5||files.some(file=>!file.size||file.size>10*1024*1024)){
      setItems([]);
      setError('Chọn tối đa 5 ảnh, mỗi ảnh có dung lượng từ 1 byte đến 10 MB.');
      return;
    }
    setItems(files.map(file=>({file,key:crypto.randomUUID(),status:'pending'})));
  }

  async function run(){
    if(running.current)return;
    running.current=true;
    stop.current=false;
    setMessage('');
    setBusy(true);
    try{
      for(const item of items){
        if(stop.current)break;
        if(item.status==='done'||item.status==='retake')continue;
        function update(changes:Partial<Item>){
          setItems(rows=>rows.map(row=>row.key===item.key?{...row,...changes}:row));
        }
        update({status:'running',error:undefined});
        try{
          const data=new FormData();
          data.set('image',item.file);
          data.set('save','true');
          data.set('save_image','true');
          const result=await api('/diagnoses/predict','POST',data,{'Idempotency-Key':item.key});
          if(!result.diagnosis_id)throw new Error('Chưa xác nhận được kết quả đã lưu. Hãy thử lại.');
          update({status:'done',result});
        }catch(error){
          update({status:error instanceof ApiError&&error.code==='RETAKE_PHOTO'?'retake':'error',error:(error as Error).message});
        }
      }
    }finally{
      running.current=false;
      setBusy(false);
    }
  }

  return <>
    <Heading title="Kiểm tra nhiều ảnh">Ảnh và kết quả của từng lần phân tích sẽ tự lưu vào lịch sử riêng của bạn.</Heading>
    <Card>
      <label className="field">Chọn tối đa 5 ảnh lá lúa
        <input type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={busy}
          onChange={event=>{choose(Array.from(event.currentTarget.files||[]));event.currentTarget.value=''}}/>
      </label>
      {error&&<Alert error>{error}</Alert>}
      {message&&<p role="status">{message}</p>}
      <div className="row">
        <Button disabled={busy||!items.some(item=>item.status==='pending'||item.status==='error')} onClick={run}>
          {busy?'Đang phân tích từng ảnh…':'Phân tích / thử lại ảnh lỗi'}
        </Button>
        {busy&&<Button className="secondary" onClick={()=>{stop.current=true;setMessage('Sẽ dừng sau ảnh đang xử lý.')}}>Dừng sau ảnh hiện tại</Button>}
      </div>
      {items.length?<p>Đã xử lý {items.filter(item=>item.status==='done').length}/{items.length} ảnh.</p>:<Empty title="Chưa chọn ảnh"/>}
      {items.map((item,index)=><section className="item" key={item.key}>
        <h3>Ảnh {index+1} · {item.file.name}</h3>
        <p role="status">{statusLabels[item.status]}</p>
        {item.error&&<Alert error>{item.error}</Alert>}
        {item.result&&<>
          <p>AI dự đoán {item.result.display_label_vi} với điểm {(item.result.raw_score*100).toFixed(1)}%.</p>
          <Link to={'/results/'+item.result.diagnosis_id}>Xem kết quả và hướng xử lý</Link>
        </>}
      </section>)}
    </Card>
  </>;
}
