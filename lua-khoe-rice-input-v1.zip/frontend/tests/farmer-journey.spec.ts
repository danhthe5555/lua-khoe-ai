import {test,expect,type BrowserContext} from '@playwright/test';
import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {basename,extname} from 'node:path';

const password='E2E-isolated-fixture-12345';
async function account(context:BrowserContext){
 const email=`e2e-${randomUUID()}@example.com`;
 const registered=await context.request.post('/api/v1/auth/register',{data:{email,name:'E2E TEST FIXTURE',password}});
 expect(registered.status()).toBe(201);
 const logged=await context.request.post('/api/v1/auth/login',{data:{email,password}});
 expect(logged.status()).toBe(200);return (await logged.json()).csrf as string;
}
test.describe('real API and browser on isolated test deployment',()=>{
 test.skip(process.env.TEST_ALLOW_WRITES!=='true','Set TEST_ALLOW_WRITES=true only for an isolated test database.');
 test('retired pages redirect to tracking on desktop and mobile',async({page,context})=>{
  await account(context);
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:900});
   for(const path of ['/cong-viec','/ruong-lua','/ruong-lua/legacy-record']){
    await page.goto(path);
    await expect(page).toHaveURL(/\/theo-doi$/);
    await expect(page.getByRole('heading',{name:'Theo dõi lá lúa'})).toBeVisible();
    await expect(page.getByRole('link',{name:/Quản lý ruộng|Việc cần làm/})).toHaveCount(0);
   }
   await page.goto('/lich-su');
   await expect(page.getByRole('heading',{name:'Lịch sử nhận diện'})).toBeVisible();
   await expect(page.getByRole('link',{name:'Việc cần làm',exact:true})).toHaveCount(0);
   await page.getByText('Lọc theo bệnh và ngày',{exact:true}).click();
   await expect(page.getByLabel('Bệnh hoặc trạng thái dự đoán')).toBeVisible();
   await expect(page.getByLabel('Ruộng và mùa vụ')).toHaveCount(0);
  }
 });
 test('core scope: account, statistics and retired tools',async({page,context})=>{
  await account(context);
  await page.goto('/tai-khoan');
  await expect(page.getByRole('heading',{name:'Tài khoản của tôi'})).toBeVisible();
  await page.getByText('Công cụ bổ sung',{exact:true}).click();
  await expect(page.getByRole('link',{name:'Hướng dẫn theo giai đoạn'})).toBeVisible();
  await expect(page.getByRole('link',{name:/Thời tiết|Đối chiếu nhãn|Đọc chữ trên nhãn|Hỏi đáp tài liệu/})).toHaveCount(0);
  await expect(page.getByRole('button',{name:/Bật thông báo/})).toHaveCount(0);
  await page.getByRole('link',{name:'Thống kê',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Thống kê của tôi'})).toBeVisible();
  await expect(page.getByRole('button',{name:'Tính chi phí',exact:true})).toHaveCount(0);
  for(const route of ['/thoi-tiet','/tra-cuu-nhan','/doc-nhan','/tro-ly']){
   await page.goto(route);
   await expect(page.getByRole('heading',{name:'Không tìm thấy trang'})).toBeVisible();
  }
 });
 test('E2E-06/19/20: inference retry, private image and delete isolation',async({browser})=>{
  test.skip(!process.env.TEST_IMAGE,'A test image is required. Use an authorized real leaf image for field acceptance.');
  const a=await browser.newContext({baseURL:process.env.TEST_BASE_URL||'http://localhost:8080'}),b=await browser.newContext({baseURL:process.env.TEST_BASE_URL||'http://localhost:8080'});
  try{
   const csrfA=await account(a),csrfB=await account(b);const key=randomUUID();
   const imagePath=process.env.TEST_IMAGE!;
   const ext=extname(imagePath).toLowerCase();
   const mimeType=ext==='.png'?'image/png':ext==='.webp'?'image/webp':'image/jpeg';
   const multipart={save:'true',save_image:'true',image:{name:basename(imagePath),mimeType,buffer:readFileSync(imagePath)}};
   const first=await a.request.post('/api/v1/diagnoses/predict',{headers:{'X-CSRF-Token':csrfA,'Idempotency-Key':key},multipart});
   expect(first.status()).toBe(200);const result=await first.json();
   for(const version of [result.model_version,result.label_mapping_version,result.preprocessing_version])expect(version).toMatch(/^[a-f0-9]{64}$/);
   expect(result.diagnosis_id).toBeTruthy();
   expect(result.top_k[0]).toMatchObject({label:result.predicted_class,label_vi:result.display_label_vi,score:result.raw_score});
   expect(result.raw_score).toBeGreaterThan(0);expect(result.raw_score).toBeLessThanOrEqual(1);
   const retry=await a.request.post('/api/v1/diagnoses/predict',{headers:{'X-CSRF-Token':csrfA,'Idempotency-Key':key},multipart});expect((await retry.json()).diagnosis_id).toBe(result.diagnosis_id);
   const path=`/api/v1/diagnoses/${result.diagnosis_id}`;
   expect((await a.request.get(path+'/image')).status()).toBe(200);
   expect((await a.request.get(path+'/thumbnail')).status()).toBe(200);
   expect((await b.request.get(path)).status()).toBe(404);expect((await b.request.get(path+'/image')).status()).toBe(404);
   expect((await b.request.get(path+'/thumbnail')).status()).toBe(404);
   const otherHistory=await b.request.get('/api/v1/diagnoses');
   expect(otherHistory.ok()).toBeTruthy();expect(await otherHistory.json()).toEqual([]);
   const otherPage=await b.newPage();
   await otherPage.goto('/results/'+result.diagnosis_id+'/report');
   await expect(otherPage.getByRole('alert')).toHaveText('Không tìm thấy dữ liệu.');
   await expect(otherPage.getByRole('button',{name:'In / Lưu PDF'})).toHaveCount(0);
   await expect(otherPage.getByAltText('Ảnh lá của bản ghi')).toHaveCount(0);
   expect((await b.request.get(path+'/tracking')).status()).toBe(404);
   expect((await b.request.get(path+'/assessment')).status()).toBe(404);
   expect((await b.request.patch(path+'/assessment',{headers:{'X-CSRF-Token':csrfB},data:{version:'result-workflow-v2',task:0,done:true}})).status()).toBe(404);
   expect((await b.request.patch(path+'/tracking',{headers:{'X-CSRF-Token':csrfB},data:{closed:true}})).status()).toBe(404);
   expect((await b.request.delete(path,{headers:{'X-CSRF-Token':csrfB}})).status()).toBe(404);
   const page=await a.newPage();
   let diagnosisId=result.diagnosis_id;
   for(const width of [1440,320]){
    await page.setViewportSize({width,height:800});
    await page.goto('/lich-su');
    const layout=page.locator(width===320?'.history-mobile':'.history-desktop');
    const remove=layout.getByRole('button',{name:'Xóa',exact:true});
    const dialog=page.getByRole('dialog',{name:'Xác nhận thao tác'});
    await remove.click();
    const cancel=dialog.getByRole('button',{name:'Hủy',exact:true});
    await expect(cancel).toBeFocused();
    const box=(await dialog.boundingBox())!;
    expect(box.x).toBeGreaterThanOrEqual(15);
    expect(box.x+box.width).toBeLessThanOrEqual(width-15);
    expect(Math.abs(box.x+box.width/2-width/2)).toBeLessThan(2);
    expect(Math.abs(box.y+box.height/2-400)).toBeLessThan(2);
    await cancel.click();
    await expect(dialog).toBeHidden();
    expect((await a.request.get('/api/v1/diagnoses/'+diagnosisId+'/image')).status()).toBe(200);
    await remove.click();
    await dialog.getByRole('button',{name:'Xác nhận',exact:true}).click();
    await expect(page.getByRole('status').filter({hasText:'Đã xóa kết quả và ảnh đang lưu.'})).toBeVisible();
    await expect(remove).toHaveCount(0);
    expect((await a.request.get('/api/v1/diagnoses/'+diagnosisId+'/image')).status()).toBe(404);
    if(width===1440){
     const next=await a.request.post('/api/v1/diagnoses/predict',{
      headers:{'X-CSRF-Token':csrfA,'Idempotency-Key':randomUUID()},multipart,
     });
     expect(next.ok()).toBeTruthy();
     diagnosisId=(await next.json()).diagnosis_id;
    }
   }
  }finally{await a.close();await b.close()}
 });
 test('E2E-01/02/11: upload, reopen history, recheck, then process a batch',async({page,context,playwright})=>{
  const imagePath=process.env.TEST_IMAGE;
  test.skip(!imagePath,'A test image is required.');
  test.slow();
  const csrf=await account(context);
  await page.setViewportSize({width:390,height:900});
  await page.goto('/nhan-dien');
  const graphic=await page.evaluate(()=>{
   const canvas=document.createElement('canvas');
   canvas.width=canvas.height=224;
   const ctx=canvas.getContext('2d')!;
   ctx.fillStyle='#efcfac';
   ctx.fillRect(0,0,224,224);
   ctx.fillStyle='#4d324d';
   ctx.fillRect(40,35,110,145);
   return canvas.toDataURL('image/png').split(',')[1];
  });
  await page.getByLabel('Chọn ảnh',{exact:true}).setInputFiles({
   name:'outside-rice.png',mimeType:'image/png',buffer:Buffer.from(graphic,'base64'),
  });
  await page.getByRole('button',{name:'Phân tích ảnh',exact:true}).click();
  await expect(page.getByRole('alert')).toContainText('Chưa nhận thấy lá lúa trong ảnh');
  await expect(page.getByAltText('Ảnh lá đã chọn')).toHaveCount(0);
  expect(await (await context.request.get('/api/v1/diagnoses')).json()).toEqual([]);
  await page.getByLabel('Chọn ảnh',{exact:true}).setInputFiles(imagePath!);
  await expect(page.getByAltText('Ảnh lá đã chọn')).toBeVisible();
  await expect(page.getByLabel('Ruộng và mùa vụ')).toHaveCount(0);
  let failedRequestKey:string|undefined;
  await page.route('**/api/v1/diagnoses/predict',async route=>{
   failedRequestKey=route.request().headers()['idempotency-key'];
   await route.abort('internetdisconnected');
  },{times:1});
  await page.getByRole('button',{name:'Phân tích ảnh',exact:true}).click();
  await expect(page.getByRole('alert')).toContainText('Kết nối gián đoạn');
  const retryRequest=page.waitForRequest(request=>request.url().endsWith('/api/v1/diagnoses/predict')&&request.method()==='POST');
  await page.getByRole('button',{name:'Thử lại',exact:true}).click();
  expect(failedRequestKey).toBeTruthy();
  expect((await retryRequest).headers()['idempotency-key']).toBe(failedRequestKey);
  const saved=page.getByRole('link',{name:'Đã lưu · Xem lịch sử'});
  await expect(saved).toBeVisible({timeout:30_000});
  const path=await saved.getAttribute('href');
  const history=await context.request.get('/api/v1/diagnoses');
  expect(history.ok()).toBeTruthy();
  const rows=await history.json();
  expect(rows).toHaveLength(1);
  expect(rows[0].season_id).toBeNull();
  expect(path).toBe(`/results/${rows[0].id}`);
  const original=await context.request.get(`/api/v1/diagnoses/${rows[0].id}/image`);
  expect(original.ok()).toBeTruthy();
  expect((await original.body()).equals(readFileSync(imagePath!))).toBeTruthy();
  const detailResponse=await context.request.get('/api/v1/diagnoses/'+rows[0].id);
  expect(detailResponse.ok()).toBeTruthy();
  const {result:detail}=await detailResponse.json();
  const expectedScore=(detail.raw_score*100).toFixed(1)+'%';
  const summary=page.locator('.check-result-header');
  await expect(summary.getByRole('heading',{name:detail.display_label_vi,exact:true})).toBeVisible();
  await expect(summary.getByText('Điểm tin cậy của mô hình',{exact:true})).toBeVisible();
  await expect(summary.getByText(expectedScore,{exact:true})).toBeVisible();
  const code=encodeURIComponent(detail.predicted_class);
  const guidePath='/api/v1/diseases/'+code;
  let published=await context.request.get(guidePath);
  const guidance=page.getByRole('link',{name:'Mở hướng dẫn đã kiểm duyệt'});
  if(published.status()===404&&process.env.TEST_ADMIN_EMAIL&&process.env.TEST_ADMIN_PASSWORD){
   const admin=await playwright.request.newContext({baseURL:process.env.TEST_BASE_URL||'http://localhost:8080'});
   try{
    const login=await admin.post('/api/v1/auth/login',{data:{email:process.env.TEST_ADMIN_EMAIL,password:process.env.TEST_ADMIN_PASSWORD}});
    expect(login.ok()).toBeTruthy();
    const headers={'X-CSRF-Token':(await login.json()).csrf};
    const draft=await admin.post('/api/v1/admin/knowledge',{headers,data:{
     code:detail.predicted_class,title:'Hướng dẫn kiểm thử liên kết kết quả',
     content:{symptoms:'TEST ONLY',field_check:'TEST ONLY',prevention:'TEST ONLY prevention',treatment:'TEST ONLY treatment',medicine:'TEST ONLY label\nTEST ONLY method'},
     sources:[{title:'TEST ONLY',url:'https://example.com/guide',publisher:'TEST ONLY',checked_at:'2026-11-01',reuse_permission:'Isolated test fixture'}],
    }});
    expect(draft.status()).toBe(201);
    const revision='/api/v1/admin/knowledge/'+(await draft.json()).id;
    expect((await admin.post(revision+'/review',{headers,data:{confirmed:true}})).ok()).toBeTruthy();
    expect((await admin.post(revision+'/publish',{headers,data:{confirmed:true}})).ok()).toBeTruthy();
    published=await context.request.get(guidePath);
    expect(published.ok()).toBeTruthy();
    await page.goto(path!);
   }finally{await admin.dispose()}
  }
  if(published.ok()){
   const article=await published.json();
   const next=page.getByRole('region',{name:'Nên làm gì tiếp?'});
   await expect(next.getByRole('heading',{name:'Biện pháp xử lý'})).toBeVisible();
   await expect(next.getByRole('heading',{name:'Thuốc bảo vệ thực vật và cách dùng',exact:true})).toBeVisible();
   if(article.content.treatment)await expect(next.getByText(article.content.treatment)).toBeVisible();
   if(article.content.prevention&&article.content.prevention!==article.content.treatment)await expect(next).toContainText(article.content.prevention);
   if(article.content.medicine)await expect(next.getByText(article.content.medicine)).toBeVisible();
   else if(detail.predicted_class==='Healthy')await expect(next).toContainText('chưa đủ căn cứ để phun thuốc');
   else await expect(next).toContainText('Hướng dẫn thuốc và liều dùng cho bệnh này chưa được duyệt.');
   await expect(guidance).toHaveAttribute('href','/cam-nang/'+code);
   await guidance.click();
   await expect(page.getByRole('heading',{name:article.title,exact:true})).toBeVisible();
   await page.goBack();
  }else{
   expect(published.status()).toBe(404);
   await expect(page.getByText('Chưa có hướng dẫn đã duyệt cho kết quả này.')).toBeVisible();
  }
  const reportLink=page.getByRole('link',{name:'Xuất phiếu gửi chuyên gia'});
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:900});
   await expect(reportLink).toBeVisible();
   await expect(summary.getByText(expectedScore,{exact:true})).toBeVisible();
   expect(await summary.evaluate(element=>element.scrollWidth<=element.clientWidth)).toBeTruthy();
   await expect(page.getByRole('heading',{name:'Nên làm gì tiếp?'})).toBeVisible();
   for(const heading of ['Đối chiếu triệu chứng','Hướng dẫn theo tình trạng','Bệnh dễ nhầm','Các bước đối chiếu']){
    await expect(page.getByRole('heading',{name:heading,exact:true})).toHaveCount(0);
   }
  }
  await reportLink.click();
  await expect(page.getByRole('button',{name:'In / Lưu PDF'})).toBeVisible();
  await expect(page.getByAltText('Ảnh lá của bản ghi')).toBeVisible();
  await expect(page.getByRole('heading',{name:'Bối cảnh và câu trả lời'})).toHaveCount(0);
  await expect(page.getByRole('heading',{name:'Các bước đã thực hiện'})).toHaveCount(0);
  await expect(page.getByRole('heading',{name:detail.display_label_vi,exact:true})).toBeVisible();
  await expect(page.getByText(expectedScore,{exact:true})).toBeVisible();
  await expect(page.getByText('Phiên bản mô hình',{exact:false})).toHaveCount(0);
  await expect(page.getByText(rows[0].id,{exact:false})).toHaveCount(0);
  await expect(page.getByRole('heading',{name:'Cẩm nang được sử dụng'})).toHaveCount(0);
  await page.emulateMedia({media:'print'});
  await expect(page.getByRole('button',{name:'In / Lưu PDF'})).toBeHidden();
  await expect(page.getByAltText('Ảnh lá của bản ghi')).toBeVisible();
  await expect(page.getByText(expectedScore,{exact:true})).toBeVisible();
  await page.emulateMedia({media:null});
  const assessmentPath='/api/v1/diagnoses/'+rows[0].id+'/assessment';
  const assessment=await context.request.get(assessmentPath);
  expect(assessment.ok()).toBeTruthy();
  const {version}=await assessment.json();
  const legacy=await context.request.patch(assessmentPath,{headers:{'X-CSRF-Token':csrf},data:{version,stage:'tillering',task:0,done:true}});
  expect(legacy.ok()).toBeTruthy();
  await page.reload();
  await expect(page.getByText('Đối chiếu lại lá ngoài ruộng',{exact:true})).toBeVisible();
  await expect(page.getByRole('heading',{name:'Bối cảnh và câu trả lời'})).toBeVisible();
  await page.goto(path!);
  await expect(page.getByRole('heading',{name:'Chi tiết lần nhận diện',exact:true})).toBeVisible();
  await page.getByText('Ghi biện pháp đã thực hiện',{exact:true}).click();
  await page.getByLabel('Biện pháp đã thực hiện',{exact:true}).fill('Đã ghi nhận vị trí lá có vết');
  await page.getByRole('button',{name:'Lưu biện pháp',exact:true}).click();
  await expect(page.getByText('Đã lưu biện pháp.',{exact:true})).toBeVisible();
  await expect(page.getByText('Đặt lịch kiểm tra lại',{exact:true})).toHaveCount(0);
  await page.getByRole('link',{name:'Kiểm tra lá lần nữa'}).click();
  await expect(page.getByLabel('Ruộng và mùa vụ')).toHaveCount(0);
  await expect(page.getByAltText('Ảnh lá đã chọn')).toHaveCount(0);
  await expect(page.getByRole('heading',{name:'Chụp ảnh kiểm tra lại'})).toBeVisible();
  await page.getByLabel('Chọn ảnh',{exact:true}).setInputFiles(imagePath!);
  await page.getByRole('button',{name:'Phân tích ảnh',exact:true}).click();
  await expect(page.getByLabel('Tình trạng quan sát')).toBeVisible({timeout:30_000});
  const repeatPath=(await page.getByRole('link',{name:'Đã lưu · Xem lịch sử'}).getAttribute('href'))!;
  expect(repeatPath).not.toBe(path);
  await page.goto(repeatPath);
  await page.getByRole('link',{name:'Kiểm tra lá lần nữa'}).click();
  const previous=page.getByRole('region',{name:'Các lần kiểm tra trước',exact:true});
  const first=previous.getByRole('link',{name:'Mở ảnh và kết quả lần kiểm tra 1',exact:true});
  const second=previous.getByRole('link',{name:'Mở ảnh và kết quả lần kiểm tra 2',exact:true});
  await expect(first).toHaveAttribute('href',path!);
  await expect(second).toHaveAttribute('href',repeatPath);
  await expect(first.locator('img')).toHaveAttribute('src','/api/v1/diagnoses/'+rows[0].id+'/thumbnail');
  await expect(second.locator('img')).toHaveAttribute('src','/api/v1/diagnoses/'+repeatPath.split('/').pop()+'/thumbnail');
  await expect(previous.locator('strong')).toHaveCount(2);
  await page.goto(repeatPath);
  await expect(page.getByText('Các lần kiểm tra trong đợt',{exact:true})).toBeVisible();
  await expect(page.getByRole('button',{name:'Kết thúc đợt theo dõi'})).toHaveCount(0);
  await page.getByLabel('Tình trạng quan sát').selectOption('Đỡ hơn');
  await page.getByLabel('Ghi chú quan sát').fill('Vết mới ít hơn trên khóm đã theo dõi');
  await page.getByRole('button',{name:'Lưu tình trạng',exact:true}).click();
  await page.getByRole('button',{name:'Kết thúc đợt theo dõi'}).click();
  await expect(page.getByText('Đã kết thúc',{exact:true})).toBeVisible();
  await page.goto(repeatPath);await page.reload();
  await expect(page.getByRole('button',{name:'Mở lại đợt theo dõi'})).toBeVisible();
  const tracking=await (await page.request.get('/api/v1/diagnoses/'+rows[0].id+'/tracking')).json();
  expect(tracking.checks.map((check:{id:string})=>check.id)).toEqual([repeatPath.split('/').pop(),rows[0].id]);
  expect(tracking.journal).toEqual(expect.arrayContaining([
   expect.objectContaining({kind:'observation',title:'Đỡ hơn'}),
   expect.objectContaining({kind:'intervention',notes:'Đã ghi nhận vị trí lá có vết'})
  ]));
  await page.goto('/lich-su');
  await page.reload();
  await expect(page.locator('.history-mobile').getByRole('link',{name:'Xem chi tiết'}).first()).toHaveAttribute('href',repeatPath);

  await page.goto('/nhan-dien/nhieu-anh');
  const ext=extname(imagePath!).toLowerCase();
  const mimeType=ext==='.png'?'image/png':ext==='.webp'?'image/webp':'image/jpeg';
  const buffer=readFileSync(imagePath!);
  await page.getByLabel('Chọn tối đa 5 ảnh lá lúa').setInputFiles([
   {name:`first${ext}`,mimeType,buffer},{name:`second${ext}`,mimeType,buffer},
  ]);
  await page.getByRole('button',{name:'Phân tích / thử lại ảnh lỗi'}).click();
  await expect(page.getByText('Đã xử lý 2/2 ảnh.',{exact:true})).toBeVisible({timeout:30_000});
  const afterBatch=await context.request.get('/api/v1/diagnoses');
  expect(afterBatch.ok()).toBeTruthy();
  const batchRows=await afterBatch.json();
  expect(batchRows.slice(2).map((row:{id:string})=>row.id)).toEqual([repeatPath.split('/').pop(),rows[0].id]);
  expect(batchRows).toHaveLength(4);
  for(const row of batchRows.slice(0,2)){
   const original=await context.request.get('/api/v1/diagnoses/'+row.id+'/image');
   expect(original.ok()).toBeTruthy();
   expect((await original.body()).equals(buffer)).toBeTruthy();
  }
 });
});
