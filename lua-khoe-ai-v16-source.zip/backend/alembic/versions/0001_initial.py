"""Initial versioned schema; schema snapshot is frozen in schema_v1.py."""
from alembic import op
from app.schema_v1 import Base
revision='0001'
down_revision=None

def upgrade():
    Base.metadata.create_all(op.get_bind())

def downgrade():
    Base.metadata.drop_all(op.get_bind())
