"""Persist user assessment alongside the immutable inference result."""
from alembic import op
import sqlalchemy as sa

revision = '0005'
down_revision = '0004'


def upgrade():
    op.add_column('diagnoses', sa.Column('assessment', sa.JSON(), nullable=True))


def downgrade():
    op.drop_column('diagnoses', 'assessment')
