"""Session-bound notification subscriptions, no changes to frozen v1 schema."""
from alembic import op
import sqlalchemy as sa
revision='0002'
down_revision='0001'

def upgrade():
    op.create_index('uq_sessions_id_user_id','sessions',['id','user_id'],unique=True)
    op.create_table('push_subscriptions',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('user_id',sa.String(36),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('session_id',sa.String(36),nullable=False),
        sa.Column('endpoint_hash',sa.String(64),unique=True,nullable=False),
        sa.Column('endpoint',sa.String(2048),nullable=False),sa.Column('keys',sa.JSON(),nullable=False),
        sa.Column('last_digest',sa.String(64)),sa.Column('last_attempt',sa.DateTime(timezone=True)),
        sa.ForeignKeyConstraint(['session_id','user_id'],['sessions.id','sessions.user_id'],ondelete='CASCADE'))
    op.create_index('ix_push_subscriptions_user_id','push_subscriptions',['user_id'])
    op.create_index('ix_push_subscriptions_session_id','push_subscriptions',['session_id'])

def downgrade():
    op.drop_table('push_subscriptions')
    op.drop_index('uq_sessions_id_user_id',table_name='sessions')
