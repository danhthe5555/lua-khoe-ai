"""Link repeat diagnoses and persist the end of a tracking episode."""
from alembic import op
import sqlalchemy as sa

revision = '0004'
down_revision = '0003'


def upgrade():
    op.add_column('diagnoses', sa.Column('tracking_id', sa.String(36), nullable=True))
    op.add_column('diagnoses', sa.Column('tracking_closed_at', sa.DateTime(timezone=True), nullable=True))
    op.create_index('ix_diagnoses_tracking_id', 'diagnoses', ['tracking_id'])


def downgrade():
    op.drop_index('ix_diagnoses_tracking_id', table_name='diagnoses')
    op.drop_column('diagnoses', 'tracking_closed_at')
    op.drop_column('diagnoses', 'tracking_id')
