"""Versioned, source-backed label catalogue. No initial product data."""
from alembic import op
import sqlalchemy as sa
revision='0003'
down_revision='0002'

def upgrade():
    op.create_table('product_labels',
        sa.Column('id',sa.String(36),primary_key=True),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        sa.Column('registration',sa.String(120),nullable=False),sa.Column('name',sa.String(200),nullable=False),
        sa.Column('crop',sa.String(100),nullable=False),sa.Column('target',sa.String(500),nullable=False),
        sa.Column('ingredients',sa.String(1000),nullable=False),sa.Column('label_text',sa.String(15000),nullable=False),
        sa.Column('precautions',sa.String(8000),nullable=False),sa.Column('valid_until',sa.String(10),nullable=False),
        sa.Column('source',sa.JSON(),nullable=False),sa.Column('status',sa.String(20),nullable=False),
        sa.Column('created_by',sa.String(36),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('reviewed_by',sa.String(36),sa.ForeignKey('users.id')),sa.Column('reviewed_at',sa.DateTime(timezone=True)),
        sa.CheckConstraint("status in ('draft','published','archived')"))
    op.create_index('ix_product_labels_registration','product_labels',['registration'])
    op.create_index('uq_product_label_published','product_labels',['registration'],unique=True,postgresql_where=sa.text("status='published'"),sqlite_where=sa.text("status='published'"))

def downgrade():op.drop_table('product_labels')
