"""Adapter fixtures, not evidence of real OCR accuracy."""
import io
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
from project_storage import configure
configure()
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import ocr
from PIL import Image


class OCRTests(unittest.TestCase):
    def image(self):
        stream=io.BytesIO();Image.new('RGB',(100,100),'white').save(stream,format='PNG');return stream.getvalue()

    def test_missing_engine(self):
        with patch.object(ocr,'executable',return_value=None):
            self.assertFalse(ocr.health()['ready'])
            with self.assertRaises(ocr.OCRUnavailable):ocr.recognize(self.image())

    def test_missing_vietnamese(self):
        with patch.object(ocr,'executable',return_value='fixture'),patch.object(ocr.subprocess,'run',return_value=subprocess.CompletedProcess([],0,'eng\n','')):
            self.assertFalse(ocr.health()['ready'])

    def run_fixture(self,result_text=None,failure=None):
        folders=[]
        def run(args,**kwargs):
            self.assertNotIn('shell',kwargs)
            folders.append(Path(args[1]).parent)
            if failure:raise failure
            Path(args[2]+'.txt').write_text(result_text,encoding='utf-8')
            return subprocess.CompletedProcess(args,0)
        with patch.object(ocr,'health',return_value={'ready':True}),patch.object(ocr,'executable',return_value='fixture'),patch.object(ocr.subprocess,'run',side_effect=run):
            try:return ocr.recognize(self.image())
            finally:
                self.assertTrue(folders)
                self.assertTrue(all(not folder.exists() for folder in folders))

    def test_text_unverified_and_temp_removed(self):
        result=self.run_fixture('Văn bản thử nghiệm OCR')
        self.assertEqual(result['status'],'needs_review')
        self.assertEqual(result['drug_verification'],'unavailable')

    def test_blank_does_not_invent_text(self):
        result=self.run_fixture('  ')
        self.assertEqual(result['status'],'no_text')
        self.assertEqual(result['text'],'')

    def test_timeout_cleanup_and_slot_release(self):
        with self.assertRaises(ValueError):self.run_fixture(failure=subprocess.TimeoutExpired('fixture',30))
        self.assertEqual(self.run_fixture('next')['text'],'next')

    def test_excessive_output_rejected(self):
        with self.assertRaises(ValueError):self.run_fixture('x'*65537)

    def test_busy_rejected(self):
        ocr._slot.acquire()
        try:
            with self.assertRaises(ocr.OCRBusy):ocr.recognize(b'')
        finally:ocr._slot.release()

    def test_invalid_image_not_sent_to_engine(self):
        with patch.object(ocr,'health',return_value={'ready':True}),patch.object(ocr.subprocess,'run') as run:
            with self.assertRaises(ValueError):ocr.recognize(b'not an image')
            run.assert_not_called()


if __name__=='__main__':unittest.main()
