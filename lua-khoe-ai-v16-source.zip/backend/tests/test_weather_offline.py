import copy
from datetime import datetime,timezone
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import weather


class WeatherTests(unittest.TestCase):
    def setUp(self):
        self.now=datetime(2026,11,13,7,tzinfo=timezone.utc)
        self.payload={'latitude':21.0,'longitude':105.8,'current_units':dict(weather.UNITS),
            'current':{'time':self.now.timestamp(),'interval':900,'temperature_2m':25,
                       'relative_humidity_2m':70,'precipitation':0,'wind_speed_10m':3}}

    def test_valid_has_source_times_no_risk_invention(self):
        result=weather.normalize(self.payload,21.01,105.81,self.now)
        self.assertEqual(result['source'],'Open-Meteo')
        self.assertEqual(result['risk_status'],'rules_unavailable')
        self.assertEqual(result['interval_seconds'],900)
        self.assertNotEqual(result['model_grid'],result['requested_location'])

    def test_stale_and_future_rejected(self):
        for shift in (-3601,901):
            data=copy.deepcopy(self.payload);data['current']['time']+=shift
            with self.assertRaises(ValueError):weather.normalize(data,21,105,self.now)

    def test_wrong_units_rejected(self):
        self.payload['current_units']['temperature_2m']='°F'
        with self.assertRaises(ValueError):weather.normalize(self.payload,21,105,self.now)

    def test_missing_or_invalid_values_rejected(self):
        for value in (None,float('nan'),float('inf'),True,-1,101):
            data=copy.deepcopy(self.payload);data['current']['relative_humidity_2m']=value
            with self.assertRaises(ValueError):weather.normalize(data,21,105,self.now)

    def test_disabled_never_calls_network(self):
        with patch.dict(os.environ,{'WEATHER_PROVIDER':'none'}),patch.object(weather.http.client,'HTTPSConnection') as client:
            with self.assertRaises(weather.WeatherUnavailable):weather.fetch(21,105)
            client.assert_not_called()

    def test_failure_does_not_return_old_or_fake_data(self):
        with patch.dict(os.environ,{'WEATHER_PROVIDER':'open-meteo'}),patch.object(weather.http.client,'HTTPSConnection') as client:
            client.return_value.request.side_effect=TimeoutError
            with self.assertRaises(weather.WeatherUnavailable):weather.fetch(21,105)
            client.return_value.close.assert_called_once()

    def test_coordinates_bounded(self):
        with patch.object(weather.http.client,'HTTPSConnection') as client:
            for lat,lon in [(91,0),(0,181),(float('nan'),0)]:
                with self.assertRaises(ValueError):weather.fetch(lat,lon)
            client.assert_not_called()


if __name__=='__main__':unittest.main()
