"""Synthetic metric/manifest unit fixtures; not model accuracy evidence."""
import csv
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from project_storage import configure
configure()
from evaluate_dataset import summarize, read_manifest


class EvaluationTests(unittest.TestCase):
    def test_known_confusion_matrix(self):
        result = summarize(['a', 'b'], [('a', 'a'), ('a', 'b'), ('b', 'b')])
        self.assertEqual(result['confusion_matrix'], [[1, 1], [0, 1]])
        self.assertAlmostEqual(result['accuracy'], 2 / 3)
        self.assertAlmostEqual(result['macro_f1'], 2 / 3)
        self.assertEqual(result['per_class'][0]['recall'], .5)

    def test_missing_class_not_claimed_perfect(self):
        result = summarize(['a', 'b'], [('a', 'a')])
        self.assertEqual(result['missing_classes'], ['b'])
        self.assertIsNone(result['per_class'][1]['recall'])
        self.assertEqual(result['macro_f1'], .5)

    def test_empty_rejected(self):
        with self.assertRaises(ValueError):
            summarize(['a'], [])

    def test_manifest_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'image.jpg').write_bytes(b'fixture bytes, not real inference')
            manifest = root / 'manifest.csv'
            fields = ['path', 'label', 'source', 'permission', 'reviewer', 'capture_group']
            row = dict(zip(fields, ['image.jpg', 'a', 'unit fixture', 'fixture', 'fixture', 'group1']))
            def write(rows):
                with manifest.open('w', newline='', encoding='utf-8') as stream:
                    writer = csv.DictWriter(stream, fieldnames=fields)
                    writer.writeheader()
                    writer.writerows(rows)
            write([row])
            self.assertEqual(len(read_manifest(manifest, root, ['a'])), 1)
            for invalid in ({'label': 'unknown'}, {'reviewer': ''}, {'path': str(root / 'image.jpg')}):
                write([{**row, **invalid}])
                with self.assertRaises(ValueError):
                    read_manifest(manifest, root, ['a'])
            write([row, row])
            with self.assertRaisesRegex(ValueError, 'Duplicate'):
                read_manifest(manifest, root, ['a'])


if __name__ == '__main__':
    unittest.main()
