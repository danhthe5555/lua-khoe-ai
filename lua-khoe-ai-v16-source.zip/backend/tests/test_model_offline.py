import io
import os
import sys
import unittest
import json
import tempfile
from unittest.mock import patch
from pathlib import Path
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.ml import PredictionService

class ModelInputTests(unittest.TestCase):
    def setUp(self): self.service=PredictionService()
    def test_invalid_bytes(self):
        with self.assertRaises(ValueError): self.service.validate_image(b'fake jpg')
    def test_large_bytes(self):
        with self.assertRaises(ValueError): self.service.validate_image(b'x'*(10*1024*1024+1))
    def test_too_small(self):
        b=io.BytesIO();Image.new('RGB',(20,20)).save(b,'PNG')
        with self.assertRaises(ValueError):self.service.validate_image(b.getvalue())
    def test_gif_disallowed(self):
        b=io.BytesIO();Image.new('RGB',(100,100)).save(b,'GIF')
        with self.assertRaises(ValueError):self.service.validate_image(b.getvalue())
    def test_valid_png(self):
        b=io.BytesIO();Image.new('RGB',(100,100)).save(b,'PNG')
        self.assertEqual(self.service.validate_image(b.getvalue()).mode,'RGB')
    def test_missing_model_fails_closed(self):
        old=os.environ.get('MODEL_DIR');os.environ['MODEL_DIR']='nonexistent-model'
        try:
            self.service.load_model();self.assertFalse(self.service.health_status()['ready'])
            with self.assertRaises(RuntimeError):self.service.predict(Image.new('RGB',(100,100)))
        finally:
            if old is not None:os.environ['MODEL_DIR']=old
            else:os.environ.pop('MODEL_DIR',None)

    def test_corrupted_weights_rejected_before_deserialization(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'weights.pt').write_bytes(b'CORRUPTED TEST FIXTURE')
            (root/'metadata.json').write_text(json.dumps({'weights_sha256':'0'*64,'architecture':'efficientnet_b0','class_names':['fixture_a','fixture_b'],'display_names_vi':{'fixture_a':'A','fixture_b':'B'}}))
            with patch.dict(os.environ,{'MODEL_DIR':directory}),patch('torch.load') as loader:
                self.service.load_model()
                loader.assert_not_called()
                self.assertFalse(self.service.health_status()['ready'])

if __name__=='__main__':unittest.main()
