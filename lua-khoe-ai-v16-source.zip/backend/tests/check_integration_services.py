"""Exercise Mailpit delivery and real OCR inside the isolated Compose stack."""
import io
import re
import secrets
import time

import httpx
from PIL import Image, ImageDraw, ImageFont


def mailbox_token(mailbox, address):
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        listing = mailbox.get('/api/v1/messages').raise_for_status().json()
        for message in listing['messages']:
            if any(person.get('Address') == address for person in message.get('To', [])):
                detail = mailbox.get('/api/v1/message/' + message['ID']).raise_for_status().json()
                match = re.search(r'#token=([A-Za-z0-9_-]+)', detail.get('Text', ''))
                if match:
                    return match.group(1)
        time.sleep(0.25)
    raise RuntimeError('Mailpit did not receive the password reset link in time.')


def main():
    address = f'acceptance-{secrets.token_hex(12)}@example.com'
    password, new_password = secrets.token_hex(16), secrets.token_hex(16)
    with httpx.Client(base_url='http://api:8000', timeout=40) as api, \
         httpx.Client(base_url='http://mailpit:8025', timeout=5) as mailbox:
        api.post('/api/v1/auth/register', json={'email': address, 'password': password,
                                               'name': 'Acceptance fixture'}).raise_for_status()
        api.post('/api/v1/auth/login', json={'email': address, 'password': password}).raise_for_status()
        api.post('/api/v1/auth/forgot-password', json={'email': address}).raise_for_status()
        token = mailbox_token(mailbox, address)
        reset = {'token': token, 'password': new_password}
        deadline = time.monotonic() + 5
        while True:
            result = api.post('/api/v1/auth/reset-password', json=reset)
            if result.is_success:
                break
            if result.status_code != 400 or time.monotonic() >= deadline:
                raise RuntimeError('The reset link received by Mailpit did not complete the reset.')
            time.sleep(0.25)
        assert api.get('/api/v1/auth/me').status_code == 401
        assert api.post('/api/v1/auth/reset-password', json=reset).status_code == 400
        login = api.post('/api/v1/auth/login', json={'email': address, 'password': new_password}).raise_for_status()
        api.headers['X-CSRF-Token'] = login.json()['csrf']
        print('MAILPIT PASS: SMTP delivery, password change, token reuse denial and old session revocation.')

        assert api.get('/api/v1/ocr/status').raise_for_status().json()['ready']
        picture = Image.new('RGB', (960, 380), 'white')
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 54)
        ImageDraw.Draw(picture).multiline_text((65, 85), 'LUA KHOE AI\nKIEM THU OCR\n123456',
                                               fill='black', font=font, spacing=12)
        payload = io.BytesIO()
        picture.save(payload, format='PNG')
        result = api.post('/api/v1/ocr/label',
                          files={'image': ('acceptance-ocr.png', payload.getvalue(), 'image/png')})
        extracted = result.raise_for_status().json()
        assert extracted['status'] == 'needs_review' and '123456' in extracted['text']
        print('OCR PASS: Tesseract extracted fixture text and returned needs_review.')


if __name__ == '__main__':
    main()
