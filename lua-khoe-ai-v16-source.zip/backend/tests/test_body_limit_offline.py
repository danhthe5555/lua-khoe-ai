import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.body_limit import BodyLimitMiddleware

class BodyLimitTests(unittest.TestCase):
    def drive(self,coroutine):
        # All test receive/send callbacks finish synchronously; no socket/event loop required.
        try:coroutine.send(None)
        except StopIteration as done:return done.value
        finally:coroutine.close()
        self.fail('Fixture unexpectedly suspended')
    async def run_request(self,chunks,headers=None):
        sent=[];read=0
        async def receive():
            nonlocal read
            body=chunks[read];read+=1
            return {'type':'http.request','body':body,'more_body':read<len(chunks)}
        async def send(message):sent.append(message)
        async def downstream(scope,receive,send):
            while (await receive()).get('more_body'):pass
            await send({'type':'http.response.start','status':200,'headers':[]})
            await send({'type':'http.response.body','body':b'OK'})
        await BodyLimitMiddleware(downstream,max_bytes=10)({'type':'http','headers':headers or []},receive,send)
        return sent,read
    def test_exact_boundary(self):
        sent,_=self.drive(self.run_request([b'12345',b'67890']));self.assertEqual(sent[0]['status'],200)
    def test_empty(self):
        sent,_=self.drive(self.run_request([b'']));self.assertEqual(sent[0]['status'],200)
    def test_chunked_no_length(self):
        sent,read=self.drive(self.run_request([b'123456',b'123456',b'unread']))
        self.assertEqual(sent[0]['status'],413);self.assertEqual(read,2)
        self.assertEqual(json.loads(sent[1]['body'])['error']['code'],'413')
    def test_false_content_length(self):
        sent,_=self.drive(self.run_request([b'12345678901'],[(b'content-length',b'1')]));self.assertEqual(sent[0]['status'],413)
    def test_non_http_passes(self):
        called=[]
        async def app(scope,receive,send):called.append(scope['type'])
        self.drive(BodyLimitMiddleware(app)({'type':'lifespan'},None,None))
        self.assertEqual(called,['lifespan'])

if __name__=='__main__':unittest.main()
