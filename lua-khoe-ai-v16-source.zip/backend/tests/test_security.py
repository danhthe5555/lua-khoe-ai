"""Real API/SQL tests. Test accounts are fixtures, never production seed data."""
import os
import tempfile
from pathlib import Path
import pytest

tmp=tempfile.TemporaryDirectory()
os.environ['DATABASE_URL']='sqlite:///'+str(Path(tmp.name)/'test.db')
os.environ['STORAGE_LOCAL_DIR']=str(Path(tmp.name)/'images')
from fastapi.testclient import TestClient
from app.main import app, rate_buckets
from app.db import Base,engine,SessionLocal,User,Knowledge,Audit,Session,Reset,Plot,Season,Activity,Diagnosis,Feedback,now
from app.security import hasher,digest
from sqlalchemy import select
from datetime import timedelta
from sqlalchemy.exc import IntegrityError

PASSWORD='Test-only-safe-passphrase-123'

@pytest.fixture(autouse=True)
def fresh():
    Base.metadata.drop_all(engine);Base.metadata.create_all(engine);rate_buckets.clear()
    yield

def account(email,role='farmer'):
    c=TestClient(app)
    if role=='admin':
        with SessionLocal() as db:
            db.add(User(email=email,name='Admin fixture',role='admin',password_hash=hasher.hash(PASSWORD)));db.commit()
    else:
        assert c.post('/api/v1/auth/register',json={'email':email,'name':'Farmer fixture','password':PASSWORD}).status_code==201
    r=c.post('/api/v1/auth/login',json={'email':email,'password':PASSWORD});assert r.status_code==200
    c.headers['X-CSRF-Token']=r.json()['csrf']
    return c,r.json()['user']

def test_register_cannot_escalate():
    c=TestClient(app)
    assert c.post('/api/v1/auth/register',json={'email':'a@example.com','name':'A','password':PASSWORD,'role':'admin'}).status_code==422

def test_password_whitespace_is_not_silently_removed():
    client=TestClient(app);password='  '+PASSWORD+'  '
    assert client.post('/api/v1/auth/register',json={'email':'space@example.com','name':' Test ','password':password}).status_code==201
    assert client.post('/api/v1/auth/login',json={'email':'space@example.com','password':PASSWORD}).status_code==401
    assert client.post('/api/v1/auth/login',json={'email':'space@example.com','password':password}).status_code==200

def test_guest_and_farmer_admin_denied():
    c=TestClient(app)
    for path in ['/plots','diagnoses','/admin/users']:
        assert c.get('/api/v1/'+path.lstrip('/')).status_code==401
    a,_=account('a@example.com')
    assert a.get('/api/v1/admin/users').status_code==403

def test_reference_import_creates_only_missing_private_drafts(monkeypatch):
    from app.knowledge_drafts import REFERENCE_DRAFTS
    from app.main import predictor

    codes = [draft['code'] for draft in REFERENCE_DRAFTS]
    monkeypatch.setattr(predictor, 'model', object())
    monkeypatch.setattr(predictor, 'labels', codes[:-1])
    officer, user = account('knowledge-review@example.com', 'admin')
    farmer_client, _ = account('knowledge-farmer@example.com')
    path = '/api/v1/admin/knowledge/import-reference-drafts'
    assert farmer_client.post(path, json={'confirmed':True}).status_code == 403
    with SessionLocal() as db:
        db.add(Knowledge(code=codes[0], title='Existing revision', content={}, sources=[],
                         status='archived', created_by=user['id']))
        db.commit()

    result = officer.post(path, json={'confirmed':True})
    assert result.status_code == 200
    assert result.json() == {'created':codes[1:-1], 'skipped':codes[:1], 'unsupported':codes[-1:]}
    assert officer.post(path, json={'confirmed':True}).json()['created'] == []
    assert TestClient(app).get('/api/v1/diseases').json() == []
    with SessionLocal() as db:
        drafts = list(db.scalars(select(Knowledge).where(Knowledge.status=='draft')))
        assert {draft.code for draft in drafts} == set(codes[1:-1])
        assert all(draft.sources and draft.reviewed_at is None for draft in drafts)
        assert len(list(db.scalars(select(Audit).where(Audit.action=='create_draft')))) == len(drafts)

def test_nested_owner_and_admin_isolation():
    a,_=account('a@example.com');b,_=account('b@example.com');admin,_=account('admin@example.com','admin')
    p=a.post('/api/v1/plots',json={'name':'A private','area_m2':100}).json()
    s=a.post(f"/api/v1/plots/{p['id']}/seasons",json={'rice_variety':'Test','sowing_date':'2026-01-01','growing_stage':'Test'}).json()
    assert b.get(f"/api/v1/plots/{p['id']}").status_code==404
    assert b.delete(f"/api/v1/plots/{p['id']}").status_code==404
    assert b.get(f"/api/v1/reports/plots/{p['id']}.pdf").status_code==404
    assert admin.get('/api/v1/plots').status_code==403
    assert b.post('/api/v1/activities',json={'season_id':s['id'],'kind':'reminder','title':'Attack','due_at':'2026-11-10T12:00:00Z'}).status_code==404
    assert b.get('/api/v1/plots').json()==[]

def test_csrf_logout_lock():
    a,user=account('a@example.com');ad,_=account('admin@example.com','admin')
    token=a.headers.pop('X-CSRF-Token')
    assert a.post('/api/v1/plots',json={'name':'Fail','area_m2':1}).status_code==403
    a.headers['X-CSRF-Token']=token
    assert ad.patch(f"/api/v1/admin/users/{user['id']}/status",json={'active':False,'confirmed':True}).status_code==200
    assert a.get('/api/v1/auth/me').status_code==401
    assert a.post('/api/v1/auth/login',json={'email':user['email'],'password':PASSWORD}).status_code==401
    with SessionLocal() as db: assert db.scalar(select(Audit).where(Audit.target_id==user['id']))

def test_logout_revokes_session():
    a,_=account('a@example.com');cookie=a.cookies.get('session')
    assert a.post('/api/v1/auth/logout').status_code==200
    a.cookies.set('session',cookie)
    assert a.get('/api/v1/auth/me').status_code==401

def test_login_rotation_revokes_only_replaced_session_and_push():
    from app.db import PushSubscription
    a,user=account('rotate@example.com')
    old=a.cookies.get('session')
    other=TestClient(app)
    assert other.post('/api/v1/auth/login',json={'email':user['email'],'password':PASSWORD}).status_code==200
    with SessionLocal() as db:
        session=db.scalar(select(Session).where(Session.token_hash==digest(old)))
        db.add(PushSubscription(user_id=user['id'],session_id=session.id,endpoint_hash='b'*64,
                               endpoint='https://fcm.googleapis.com/fixture',keys={}))
        db.commit();old_id=session.id
    result=a.post('/api/v1/auth/login',json={'email':user['email'],'password':PASSWORD})
    assert result.status_code==200 and a.cookies.get('session')!=old
    assert a.get('/api/v1/auth/me').status_code==200
    assert other.get('/api/v1/auth/me').status_code==200
    with SessionLocal() as db:
        assert db.get(Session,old_id) is None
        assert db.scalar(select(PushSubscription).where(PushSubscription.session_id==old_id)) is None
    replay=TestClient(app);replay.cookies.set('session',old)
    assert replay.get('/api/v1/auth/me').status_code==401

def test_failed_login_preserves_current_session():
    a,user=account('keep@example.com');old=a.cookies.get('session')
    assert a.post('/api/v1/auth/login',json={'email':user['email'],'password':'wrong-password'}).status_code==401
    assert a.cookies.get('session')==old
    assert a.get('/api/v1/auth/me').status_code==200

def test_session_listing_owner_metadata_pagination_and_revocation():
    a,user=account('sessions@example.com');b,_=account('other@example.com')
    other=TestClient(app)
    assert other.post('/api/v1/auth/login',json={'email':user['email'],'password':PASSWORD}).status_code==200
    rows=a.get('/api/v1/auth/sessions').json()
    assert len(rows)==2
    assert all(set(row)=={'id','created_at','expires_at','current'} for row in rows)
    current=next(row for row in rows if row['current'])
    target=next(row for row in rows if not row['current'])
    assert len(a.get('/api/v1/auth/sessions?limit=1&offset=1').json())==1
    assert a.get('/api/v1/auth/sessions?limit=101').status_code==422
    assert b.delete('/api/v1/auth/sessions/'+target['id']).status_code==404
    csrf=a.headers.pop('X-CSRF-Token')
    assert a.delete('/api/v1/auth/sessions/'+target['id']).status_code==403
    a.headers['X-CSRF-Token']=csrf
    assert a.delete('/api/v1/auth/sessions/'+current['id']).status_code==409
    assert a.delete('/api/v1/auth/sessions/'+target['id']).status_code==200
    assert other.get('/api/v1/auth/me').status_code==401
    assert a.get('/api/v1/auth/me').status_code==200
    assert a.delete('/api/v1/auth/sessions/'+target['id']).status_code==404

def test_session_list_excludes_expired_and_guest():
    assert TestClient(app).get('/api/v1/auth/sessions').status_code==401
    a,user=account('expired-session@example.com')
    with SessionLocal() as db:
        db.add(Session(user_id=user['id'],token_hash='c'*64,csrf='fixture',expires_at=now()-timedelta(seconds=1)))
        db.commit()
    assert len(a.get('/api/v1/auth/sessions').json())==1

def test_draft_never_public():
    _,ad=account('admin@example.com','admin')
    with SessionLocal() as db:
        db.add(Knowledge(code='fixture',title='DRAFT',content={},sources=[],created_by=ad['id']));db.commit()
    guest=TestClient(app)
    assert guest.get('/api/v1/diseases?status=draft').json()==[]
    assert guest.get('/api/v1/diseases/fixture').status_code==404

def test_admin_last_and_profile_role():
    ad,user=account('admin@example.com','admin')
    assert ad.patch(f"/api/v1/admin/users/{user['id']}/status",json={'active':False,'confirmed':True}).status_code==403
    assert ad.patch('/api/v1/auth/me',json={'name':'Admin','role':'farmer'}).status_code==422

def test_admin_account_filters_pagination_and_masking():
    _,first=account('first@example.com');_,second=account('second@example.com');ad,_=account('admin@example.com','admin')
    with SessionLocal() as db:
        db.get(User,first['id']).name='Alpha%Team';db.get(User,second['id']).name='AlphaXTeam';db.commit()
    rows=ad.get('/api/v1/admin/users',params={'search':'%'}).json()
    assert len(rows)==1 and rows[0]['id']==first['id']
    assert rows[0]['email']=='f***@example.com'
    assert len(ad.get('/api/v1/admin/users?limit=1&offset=1').json())==1
    assert ad.get('/api/v1/admin/users?limit=101').status_code==422
    changed=ad.patch(f"/api/v1/admin/users/{first['id']}/status",json={'active':False,'confirmed':True})
    assert changed.status_code==200
    assert changed.json()['email']=='f***@example.com'
    assert [u['id'] for u in ad.get('/api/v1/admin/users?status=inactive').json()]==[first['id']]
    logs=ad.get('/api/v1/admin/audit?action=deactivate').json()
    assert len(logs)==1 and logs[0]['target_id']==first['id']

def test_reset_once_revokes_old_sessions():
    a,user=account('a@example.com')
    with SessionLocal() as db:
        db.add(Reset(user_id=user['id'],token_hash=digest('x'*40),expires_at=now()+timedelta(minutes=10)));db.commit()
    guest=TestClient(app);body={'token':'x'*40,'password':PASSWORD+'new'}
    assert guest.post('/api/v1/auth/reset-password',json=body).status_code==200
    assert guest.post('/api/v1/auth/reset-password',json=body).status_code==400
    assert a.get('/api/v1/auth/me').status_code==401

def test_reset_email_generic_response_and_delivery(monkeypatch):
    import re
    import app.main as main
    account('a@example.com')
    sent=[]
    class SMTPFixture:
        def __init__(self,*args,**kwargs):pass
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def send_message(self,message):sent.append(message)
    monkeypatch.setenv('SMTP_HOST','fixture-mailpit')
    monkeypatch.delenv('SMTP_USER',raising=False);monkeypatch.delenv('SMTP_TLS',raising=False)
    monkeypatch.setattr(main.smtplib,'SMTP',SMTPFixture)
    client=TestClient(app)
    known=client.post('/api/v1/auth/forgot-password',json={'email':'a@example.com'})
    unknown=client.post('/api/v1/auth/forgot-password',json={'email':'unknown@example.com'})
    assert known.status_code==unknown.status_code==200
    assert known.json()==unknown.json()
    assert len(sent)==1 and sent[0]['To']=='a@example.com'
    token=re.search(r'#token=([^\s]+)',sent[0].get_content()).group(1)
    with SessionLocal() as db:
        row=db.scalar(select(Reset));assert row.token_hash==digest(token) and row.token_hash!=token
    assert client.post('/api/v1/auth/reset-password',json={'token':token,'password':PASSWORD+'new'}).status_code==200

def test_invalid_upload():
    c=TestClient(app)
    assert c.post('/api/v1/diagnoses/predict',files={'image':('evil.jpg',b'not an image','image/jpeg')}).status_code==422
    assert c.post('/api/v1/diagnoses/predict',data={'save':'true'},files={'image':('evil.jpg',b'invalid','image/jpeg')}).status_code==401

def test_database_rejects_cross_owner_links():
    a,ua=account('a@example.com');b,ub=account('b@example.com')
    p=a.post('/api/v1/plots',json={'name':'A','area_m2':1}).json()
    s=a.post(f"/api/v1/plots/{p['id']}/seasons",json={'rice_variety':'Fixture','sowing_date':'2026-01-01','growing_stage':'Fixture'}).json()
    with SessionLocal() as db:
        db.add(Activity(user_id=ub['id'],season_id=s['id'],kind='reminder',title='Cross-owner attack',due_at=now()))
        with pytest.raises(IntegrityError):db.commit()
        db.rollback()

def test_admin_knowledge_filters_before_paging():
    ad,user=account('admin@example.com','admin')
    farmer,_=account('farmer@example.com')
    with SessionLocal() as db:
        # Put the wanted revision beyond the former fixed 200-row window.
        db.add(Knowledge(code='needle_code',title='Old 100% revision',status='archived',
            content={},sources=[],created_by=user['id'],created_at=now()-timedelta(days=1)))
        for i in range(205):
            db.add(Knowledge(code='fixture',title=f'New draft {i}',content={},sources=[],created_by=user['id']))
        db.commit()
    path='/api/v1/admin/knowledge'
    assert farmer.get(path).status_code==403
    found=ad.get(path,params={'search':'100%','status':'archived'}).json()
    assert len(found)==1 and found[0]['code']=='needle_code'
    assert ad.get(path,params={'search':'needle_code','status':'draft'}).json()==[]
    assert len(ad.get(path,params={'search':'needle_code'}).json())==1
    first=ad.get(path,params={'limit':100}).json()
    second=ad.get(path,params={'limit':100,'offset':100}).json()
    third=ad.get(path,params={'limit':100,'offset':200}).json()
    assert len(first)==len(second)==100 and len(third)==6
    assert len({r['id'] for r in first+second+third})==206
    for params in ({'limit':101},{'offset':-1},{'status':'invalid'},{'search':'x'*121}):
        assert ad.get(path,params=params).status_code==422

def test_local_lookup_excludes_unpublished_revisions():
    _,user=account('admin@example.com','admin')
    with SessionLocal() as db:
        for status in ['draft','reviewed','archived','published']:
            db.add(Knowledge(code=status,title='Lookup fixture '+status,status=status,
                content={'field_check':'Lookup fixture condition'},sources=[],created_by=user['id']))
        db.commit()
    guest=TestClient(app)
    response=guest.get('/api/v1/knowledge/search',params={'q':'lookup'})
    assert response.status_code==200
    assert [r['code'] for r in response.json()['results']]==['published']
    assert guest.get('/api/v1/knowledge/search',params={'q':'no-match-token'}).json()['results']==[]
    assert guest.get('/api/v1/knowledge/search',params={'q':'x'*301}).status_code==422

def test_activity_filter_before_pagination_and_owner_isolation():
    a,ua=account('a@example.com');b,ub=account('b@example.com')
    with SessionLocal() as db:
        stamp=now()
        for i in range(205):
            db.add(Activity(user_id=ua['id'],kind='observation',title=f'Future {i}',due_at=stamp+timedelta(days=1)))
        db.add(Activity(user_id=ua['id'],kind='reminder',title='Old due',due_at=stamp-timedelta(days=3)))
        db.add(Activity(user_id=ua['id'],kind='reminder',title='Future reminder',due_at=stamp+timedelta(days=5)))
        db.add(Activity(user_id=ua['id'],kind='reminder',title='Finished',due_at=stamp-timedelta(days=2),completed=True))
        db.add(Activity(user_id=ub['id'],kind='reminder',title='B private',due_at=stamp-timedelta(days=7)))
        db.commit()
    path='/api/v1/activities'
    assert [r['title'] for r in a.get(path,params={'status':'due'}).json()]==['Old due']
    assert [r['title'] for r in a.get(path,params={'due_only':True}).json()]==['Old due']
    assert [r['title'] for r in a.get(path,params={'status':'pending'}).json()]==['Old due','Future reminder']
    assert [r['title'] for r in a.get(path,params={'status':'done'}).json()]==['Finished']
    pages=[a.get(path,params={'status':'observation','limit':100,'offset':offset}).json() for offset in (0,100,200)]
    assert [len(page) for page in pages]==[100,100,5]
    assert len({r['id'] for page in pages for r in page})==205
    assert [r['title'] for r in b.get(path,params={'status':'due'}).json()]==['B private']
    for params in ({'limit':101},{'offset':-1},{'status':'invalid'}):
        assert a.get(path,params=params).status_code==422

def test_ocr_access_and_unavailable_engine(monkeypatch):
    from app import ocr
    a,_=account('a@example.com');ad,_=account('admin@example.com','admin')
    guest=TestClient(app)
    monkeypatch.setattr(ocr,'health',lambda:{'ready':False,'message':'Fixture unavailable'})
    assert guest.get('/api/v1/ocr/status').status_code==401
    assert ad.get('/api/v1/ocr/status').status_code==403
    assert a.get('/api/v1/ocr/status').json()['ready'] is False
    files={'image':('fixture.png',b'fixture','image/png')}
    assert guest.post('/api/v1/ocr/label',files=files).status_code==401
    assert a.post('/api/v1/ocr/label',files=files).status_code==503
    assert a.post('/api/v1/ocr/label',files={'image':('bad.txt',b'bad','text/plain')}).status_code==422
    assert a.post('/api/v1/ocr/label',files={'image':('empty.png',b'','image/png')}).status_code==422

def test_assistant_access_and_no_draft_context(monkeypatch):
    from app import rag
    a,_=account('a@example.com');ad,user=account('admin@example.com','admin')
    with SessionLocal() as db:
        db.add(Knowledge(code='fixture',title='SECRET DRAFT',status='draft',content={'field_check':'private fixture'},sources=[],created_by=user['id']))
        db.commit()
    observed=[]
    def answer(question,articles):
        observed.extend(articles)
        return {'status':'no_evidence','citations':[],'message':'Fixture'}
    monkeypatch.setattr(rag,'answer',answer)
    path='/api/v1/assistant/ask';body={'question':'fixture question'}
    assert TestClient(app).post(path,json=body).status_code==401
    assert ad.post(path,json=body).status_code==403
    response=a.post(path,json=body)
    assert response.status_code==200 and observed==[]
    assert 'no-store' in response.headers['cache-control']
    assert a.post(path,json={'question':'x'*1001}).status_code==422
    def unavailable(*args):raise rag.RAGUnavailable('Fixture unavailable')
    monkeypatch.setattr(rag,'answer',unavailable)
    assert a.post(path,json=body).status_code==503

def test_weather_requires_farmer_and_explicit_consent(monkeypatch):
    from app import weather
    a,_=account('a@example.com');ad,_=account('admin@example.com','admin')
    calls=[]
    def fetch(lat,lon):calls.append((lat,lon));return {'source':'fixture'}
    monkeypatch.setattr(weather,'fetch',fetch)
    path='/api/v1/weather/current';body={'latitude':21,'longitude':105,'consent_to_share_location':True}
    assert TestClient(app).post(path,json=body).status_code==401
    assert ad.post(path,json=body).status_code==403
    assert a.post(path,json={**body,'consent_to_share_location':False}).status_code==422
    assert a.post(path,json={**body,'latitude':91}).status_code==422
    assert calls==[]
    response=a.post(path,json=body)
    assert response.status_code==200 and calls==[(21,105)]
    assert 'no-store' in response.headers['cache-control']

def test_push_session_owner_revoke_and_logout(monkeypatch):
    import base64
    from app.db import PushSubscription
    monkeypatch.setenv('PUSH_ENABLED','true');monkeypatch.setenv('VAPID_PUBLIC_KEY','fixture')
    monkeypatch.setenv('VAPID_PRIVATE_KEY','fixture');monkeypatch.setenv('VAPID_SUBJECT','mailto:fixture@example.com')
    a,ua=account('a@example.com');b,_=account('b@example.com')
    enc=lambda value:base64.urlsafe_b64encode(value).decode().rstrip('=')
    body={'endpoint':'https://fcm.googleapis.com/fixture','keys':{'auth':enc(b'a'*16),'p256dh':enc(b'\x04'+b'b'*64)}}
    a.post('/api/v1/activities',json={'kind':'reminder','title':'PRIVATE','due_at':now().isoformat()})
    response=a.post('/api/v1/push/subscriptions',json=body)
    assert response.status_code==201
    id=response.json()['id']
    assert a.get(f'/api/v1/push/verify/{id}').json()['show'] is True
    assert b.get(f'/api/v1/push/verify/{id}').json()['show'] is False
    assert b.delete(f'/api/v1/push/subscriptions/{id}').status_code==404
    listing=a.get('/api/v1/push/subscriptions').text
    assert 'endpoint' not in listing and 'p256dh' not in listing
    assert a.post('/api/v1/auth/logout').status_code==200
    with SessionLocal() as db:assert db.get(PushSubscription,id) is None
    assert a.get(f'/api/v1/push/verify/{id}').status_code==401

def test_push_worker_no_duplicate_and_expired_session(monkeypatch):
    from app.db import PushSubscription
    from app import push_worker
    a,ua=account('a@example.com')
    with SessionLocal() as db:
        session=db.scalar(select(Session).where(Session.user_id==ua['id']))
        record=PushSubscription(user_id=ua['id'],session_id=session.id,endpoint_hash='a'*64,endpoint='https://fcm.googleapis.com/fixture',keys={})
        db.add(record);db.commit();id=record.id;session_id=session.id
    a.post('/api/v1/activities',json={'kind':'reminder','title':'PRIVATE','due_at':now().isoformat()})
    sent=[]
    monkeypatch.setattr(push_worker,'configured',lambda:True)
    monkeypatch.setattr(push_worker,'send',lambda record:sent.append(record.id) or 'sent')
    assert push_worker.run_once()['sent']==1
    assert push_worker.run_once()['sent']==0
    assert sent==[id]
    with SessionLocal() as db:
        db.get(Session,session_id).expires_at=now()-timedelta(seconds=1);db.commit()
    assert push_worker.run_once()['sent']==0
    with SessionLocal() as db:assert db.get(PushSubscription,id) is None

def test_label_catalogue_publication_expiry_and_roles():
    from app.db import ProductLabel
    ad,_=account('admin@example.com','admin');farmer,_=account('farmer@example.com')
    guest=TestClient(app)
    body={'registration':'TEST-REG','name':'TEST LABEL ONLY','crop':'Fixture crop','target':'Fixture target',
          'ingredients':'Fixture ingredients','label_text':'Fixture text','precautions':'Fixture precautions',
          'valid_until':(now().date()+timedelta(days=30)).isoformat(),
          'source':{'title':'Fixture','url':'https://example.com','publisher':'Fixture','checked_at':now().date().isoformat(),'reuse_permission':'INTERNAL'}}
    assert farmer.post('/api/v1/admin/labels',json=body).status_code==403
    first=ad.post('/api/v1/admin/labels',json=body);assert first.status_code==201
    id=first.json()['id']
    assert guest.get('/api/v1/labels?search=TEST').json()==[]
    assert ad.post(f'/api/v1/admin/labels/{id}/publish',json={'confirmed':True}).status_code==200
    response=guest.get('/api/v1/labels?search=TEST')
    assert len(response.json())==1 and 'INTERNAL' not in response.text and 'created_by' not in response.text
    second=ad.post('/api/v1/admin/labels',json={**body,'name':'TEST LABEL REVISION'}).json()['id']
    assert ad.post(f'/api/v1/admin/labels/{second}/publish',json={'confirmed':True}).status_code==200
    assert [r['id'] for r in guest.get('/api/v1/labels?search=TEST').json()]==[second]
    with SessionLocal() as db:
        assert db.get(ProductLabel,id).status=='archived'
        db.get(ProductLabel,second).valid_until=(now().date()-timedelta(days=1)).isoformat();db.commit()
    assert guest.get('/api/v1/labels?search=TEST').json()==[]
    expired=ad.post('/api/v1/admin/labels',json={**body,'valid_until':(now().date()-timedelta(days=1)).isoformat()}).json()['id']
    assert ad.post(f'/api/v1/admin/labels/{expired}/publish',json={'confirmed':True}).status_code==422

def test_calendar_owner_and_completed_rules():
    a,_=account('a@example.com');b,_=account('b@example.com')
    body={'kind':'reminder','title':'Private reminder','notes':'Private notes','due_at':now().isoformat()}
    item=a.post('/api/v1/activities',json=body).json()
    path=f"/api/v1/activities/{item['id']}/calendar.ics"
    response=a.get(path)
    assert response.status_code==200 and 'BEGIN:VCALENDAR' in response.text
    assert 'no-store' in response.headers['cache-control']
    assert b.get(path).status_code==404
    assert TestClient(app).get(path).status_code==401
    assert a.patch(f"/api/v1/activities/{item['id']}",json={**body,'completed':True}).status_code==200
    assert a.get(path).status_code==422

def test_stage_guidance_only_published_reviewed_content():
    _,user=account('admin@example.com','admin')
    with SessionLocal() as db:
        db.add(Knowledge(code='fixture',title='Stage fixture',status='draft',
            content={'stage_seedling':'SECRET DRAFT'},sources=[],created_by=user['id']))
        db.commit()
    guest=TestClient(app)
    path='/api/v1/diseases/fixture/guidance'
    result=guest.get(path,params={'stage':'seedling'})
    assert result.status_code==200 and result.json()['text'] is None
    assert 'SECRET DRAFT' not in result.text
    with SessionLocal() as db:
        db.add(Knowledge(code='fixture',title='Published stage fixture',status='published',
            content={'stage_seedling':'PUBLIC FIXTURE'},sources=[{'title':'TEST ONLY'}],
            created_by=user['id'],reviewed_by=user['id'],reviewed_at=now()))
        db.commit()
    assert guest.get(path,params={'stage':'seedling'}).json()['text']=='PUBLIC FIXTURE'
    assert guest.get(path,params={'stage':'ripening'}).json()['text'] is None
    assert guest.get(path,params={'stage':'unknown'}).status_code==422

def test_knowledge_workflow_and_rollback():
    ad,user=account('admin@example.com','admin')
    with SessionLocal() as db:
        first=Knowledge(code='fixture',title='Fixture revision 1',content={'symptoms':'fixture','field_check':'fixture','prevention':'fixture'},sources=[{'url':'https://example.com','title':'TEST FIXTURE ONLY'}],created_by=user['id'])
        second=Knowledge(code='fixture',title='Fixture revision 2',content={'symptoms':'fixture','field_check':'fixture','prevention':'fixture'},sources=[{'url':'https://example.com','title':'TEST FIXTURE ONLY'}],created_by=user['id'])
        db.add_all([first,second]);db.commit();ids=[first.id,second.id]
    guest=TestClient(app)
    assert ad.post(f'/api/v1/admin/knowledge/{ids[0]}/publish',json={'confirmed':True}).status_code==422
    for id in ids:
        assert ad.post(f'/api/v1/admin/knowledge/{id}/review',json={'confirmed':True}).status_code==200
        assert ad.post(f'/api/v1/admin/knowledge/{id}/publish',json={'confirmed':True}).status_code==200
    assert guest.get('/api/v1/diseases/fixture').json()['id']==ids[1]
    assert ad.post(f'/api/v1/admin/knowledge/{ids[0]}/rollback',json={'confirmed':True}).status_code==200
    assert guest.get('/api/v1/diseases/fixture').json()['id']==ids[0]
    assert len(guest.get('/api/v1/diseases').json())==1

def test_private_responses_not_cached():
    a,_=account('a@example.com')
    assert 'no-store' in a.get('/api/v1/plots').headers['cache-control']
    assert 'httponly' in a.post('/api/v1/auth/login',json={'email':'a@example.com','password':PASSWORD}).headers['set-cookie'].lower()

def test_public_article_excludes_internal_review_metadata():
    _,ad=account('admin@example.com','admin')
    with SessionLocal() as db:
        db.add(Knowledge(code='fixture',title='Public fixture',content={'symptoms':'fixture'},
            sources=[{'title':'Fixture','url':'https://example.com','publisher':'Fixture','checked_at':'2026-11-11','reuse_permission':'INTERNAL NOTE'}],
            created_by=ad['id'],reviewed_by=ad['id'],reviewed_at=now(),status='published'));db.commit()
    guest=TestClient(app)
    for path in ['/api/v1/diseases','/api/v1/diseases/fixture']:
        response=guest.get(path)
        assert response.status_code==200
        assert ad['id'] not in response.text
        assert 'INTERNAL NOTE' not in response.text
        assert 'reuse_permission' not in response.text

def test_feedback_consent_controls_admin_view():
    a,ua=account('a@example.com');b,_=account('b@example.com');ad,_=account('admin@example.com','admin')
    with SessionLocal() as db:
        d=Diagnosis(user_id=ua['id'],result={},request_key='feedback-fixture');db.add(d);db.flush()
        public=Feedback(user_id=ua['id'],diagnosis_id=d.id,notes='CONSENTED FIXTURE',consented_to_review=True)
        private=Feedback(user_id=ua['id'],diagnosis_id=d.id,notes='PRIVATE FIXTURE',consented_to_review=False)
        db.add_all([public,private]);db.commit();id=public.id
    assert a.get('/api/v1/admin/feedback').status_code==403
    assert TestClient(app).get('/api/v1/admin/feedback').status_code==401
    response=ad.get('/api/v1/admin/feedback');assert response.status_code==200
    assert len(response.json())==1 and response.json()[0]['notes']=='CONSENTED FIXTURE'
    assert all(key not in response.text for key in ['user_id','diagnosis_id','PRIVATE FIXTURE',ua['email']])
    body={'notes':'CONSENTED FIXTURE','consented_to_review':False}
    assert b.patch(f'/api/v1/feedback/{id}',json=body).status_code==404
    assert b.delete(f'/api/v1/feedback/{id}').status_code==404
    assert a.patch(f'/api/v1/feedback/{id}',json=body).status_code==200
    assert ad.get('/api/v1/admin/feedback').json()==[]
    assert len(a.get('/api/v1/me/feedback').json())==2
    assert b.get('/api/v1/me/feedback').json()==[]
    assert a.delete(f'/api/v1/feedback/{id}').status_code==200

def test_history_filters_dates_pagination_and_owner():
    a,ua=account('a@example.com');b,ub=account('b@example.com')
    with SessionLocal() as db:
        for owner,label,days in [(ua,'A',0),(ua,'B',1),(ub,'A',0)]:
            db.add(Diagnosis(user_id=owner['id'],result={'predicted_class':label},
                request_key=owner['id']+label,created_at=now()-timedelta(days=days)))
        db.commit()
    assert len(a.get('/api/v1/diagnoses?label=A').json())==1
    assert len(a.get('/api/v1/diagnoses?limit=1&offset=1').json())==1
    assert a.get('/api/v1/diagnoses?offset=2').json()==[]
    assert len(a.get('/api/v1/diagnoses?from_date='+now().date().isoformat()).json())==1
    assert a.get('/api/v1/diagnoses?from_date=2026-12-01&to_date=2026-01-01').status_code==422
    assert len(b.get('/api/v1/diagnoses').json())==1

def test_stats_pdf_and_history_use_same_owner_filters(monkeypatch):
    a,ua=account('a@example.com');b,_=account('b@example.com')
    plot=a.post('/api/v1/plots',json={'name':'A filtered','area_m2':500}).json()
    season=a.post(f"/api/v1/plots/{plot['id']}/seasons",json={'rice_variety':'Fixture','sowing_date':'2026-01-01','growing_stage':'Fixture'}).json()
    with SessionLocal() as db:
        for index,label in enumerate(['A','B','A']):
            db.add(Diagnosis(user_id=ua['id'],season_id=season['id'],result={'predicted_class':label},request_key=f'filter-{index}'))
        db.commit()
    params={'plot_id':plot['id'],'season_id':season['id'],'label':'A','to_date':'9999-12-31'}
    history=a.get('/api/v1/diagnoses',params=params).json()
    assert len(history)==a.get('/api/v1/stats/overview',params=params).json()['total']==2
    captured={}
    def capture(plot,seasons,diagnoses,activities,filters=None):
        captured['ids']={d['id'] for d in diagnoses};return b'%PDF-fixture'
    monkeypatch.setattr('app.report.create_pdf',capture)
    response=a.get('/api/v1/reports/overview.pdf',params=params)
    assert response.status_code==200 and response.headers['content-type']=='application/pdf'
    assert captured['ids']=={d['id'] for d in history}
    for path in ['/diagnoses','/stats/overview','/reports/overview.pdf']:
        assert b.get('/api/v1'+path,params=params).status_code==404
    other=a.post('/api/v1/plots',json={'name':'Different plot','area_m2':1}).json()
    assert a.get('/api/v1/stats/overview',params={**params,'plot_id':other['id']}).status_code==422

def test_delete_data_keeps_other_account_and_removes_private_image():
    from app.main import storage
    a,ua=account('a@example.com');b,ub=account('b@example.com')
    pa=a.post('/api/v1/plots',json={'name':'A','area_m2':1}).json()
    pb=b.post('/api/v1/plots',json={'name':'B','area_m2':1}).json()
    season=a.post(f"/api/v1/plots/{pa['id']}/seasons",json={'rice_variety':'Fixture','sowing_date':'2026-01-01','growing_stage':'Fixture'}).json()
    storage.mkdir(exist_ok=True,parents=True);image=storage/'fixture-delete.jpg';image.write_bytes(b'test-fixture')
    with SessionLocal() as db:
        d=Diagnosis(user_id=ua['id'],season_id=season['id'],image_key=image.name,result={},request_key='delete-fixture');db.add(d);db.flush()
        db.add(Feedback(user_id=ua['id'],diagnosis_id=d.id,notes='Fixture',consented_to_review=False))
        db.add(Activity(user_id=ua['id'],season_id=season['id'],diagnosis_id=d.id,kind='reminder',title='Fixture',due_at=now()));db.commit()
    assert a.request('DELETE','/api/v1/me/data',json={'password':'wrong','confirmed':True}).status_code==401
    assert image.exists()
    assert a.request('DELETE','/api/v1/me/data',json={'password':PASSWORD,'confirmed':True}).status_code==200
    assert not image.exists()
    assert all(not values for values in a.get('/api/v1/me/data').json().values())
    assert b.get(f"/api/v1/plots/{pb['id']}").status_code==200
    assert a.get('/api/v1/auth/me').status_code==200
