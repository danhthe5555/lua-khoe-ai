import os
import sys
from pathlib import Path
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import rag


class RAGTests(unittest.TestCase):
    def setUp(self):
        self.article={'id':'fixture','code':'fixture','title':'Đốm lá',
                      'reviewed_at':'2026-11-13','sources':[{'title':'TEST FIXTURE ONLY'}],
                      'content':{'field_check':'Không kết luận đốm lá chỉ từ một ảnh.'}}

    def test_exact_quote_and_citation(self):
        with patch.object(rag,'local_completion',return_value={'references':['S1']}):
            result=rag.answer('đốm lá',[self.article])
        self.assertEqual(result['status'],'answered')
        self.assertEqual(result['citations'][0]['text'],self.article['content']['field_check'])
        self.assertEqual(result['citations'][0]['id'],'fixture')

    def test_no_evidence_does_not_call_model(self):
        with patch.object(rag,'local_completion') as model:
            self.assertEqual(rag.answer('unrelatedkeyword',[self.article])['status'],'no_evidence')
            model.assert_not_called()

    def test_missing_review_or_source_excluded(self):
        for override in ({'reviewed_at':None},{'sources':[]}):
            self.assertEqual(rag.passages('đốm lá',[{**self.article,**override}]),[])

    def test_hallucinated_or_duplicate_citations_rejected(self):
        candidates=rag.passages('đốm lá',[self.article])
        for reply in ({'references':['FAKE']},{'references':['S1','S1']},{'references':['S1'],'advice':'invented'},{'references':'S1'},[]):
            with self.assertRaises(ValueError):rag.select_references(reply,candidates)

    def test_model_failure_releases_slot(self):
        with patch.object(rag,'local_completion',side_effect=TimeoutError):
            with self.assertRaises(rag.RAGUnavailable):rag.answer('đốm lá',[self.article])
        with patch.object(rag,'local_completion',return_value={'references':[]}):
            self.assertEqual(rag.answer('đốm lá',[self.article])['status'],'no_evidence')

    def test_remote_and_credential_urls_rejected(self):
        for url in ['https://example.com','http://127.0.0.1.evil.test','http://user:pass@localhost','http://localhost/other']:
            with patch.dict(os.environ,{'RAG_LOCAL_URL':url,'RAG_MODEL':'fixture'}):
                with self.assertRaises(rag.RAGUnavailable):rag.configuration()

    def test_loopback_configuration(self):
        with patch.dict(os.environ,{'RAG_LOCAL_URL':'http://127.0.0.1:11434','RAG_MODEL':'fixture'}):
            self.assertEqual(rag.configuration(),('127.0.0.1',11434,'fixture'))

    def test_no_context_truncation(self):
        large={**self.article,'content':{'field_check':'đốm lá '*5000}}
        self.assertEqual(rag.passages('đốm lá',[large]),[])

    def test_busy_rejected(self):
        rag._slot.acquire()
        try:
            with self.assertRaises(rag.RAGBusy):rag.answer('đốm lá',[self.article])
        finally:rag._slot.release()


if __name__=='__main__':unittest.main()
