import io
import json
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.backup import FILES,sha256,validate_backup

class BackupTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        (self.root/'database.dump').write_bytes(b'FIXTURE ONLY')
        (self.root/'inventory.json').write_text('{}')
        self.archive('image.jpg');self.manifest()
    def tearDown(self):self.temp.cleanup()
    def archive(self,name,kind=tarfile.REGTYPE):
        with tarfile.open(self.root/'images.tar.gz','w:gz') as out:
            item=tarfile.TarInfo(name);item.type=kind
            if kind==tarfile.REGTYPE:item.size=7;out.addfile(item,io.BytesIO(b'fixture'))
            else:item.linkname='/etc/passwd';out.addfile(item)
    def manifest(self):
        (self.root/'checksums.json').write_text(json.dumps([{'name':name,'sha256':sha256(self.root/name)} for name in FILES]))
    def test_valid(self):self.assertTrue(validate_backup(self.root))
    def test_modified_dump(self):
        (self.root/'database.dump').write_bytes(b'changed')
        with self.assertRaises(ValueError):validate_backup(self.root)
    def test_missing_file(self):
        (self.root/'inventory.json').unlink()
        with self.assertRaises(ValueError):validate_backup(self.root)
    def test_parent_traversal(self):
        self.archive('../outside');self.manifest()
        with self.assertRaises(ValueError):validate_backup(self.root)
    def test_absolute_path(self):
        self.archive('/outside');self.manifest()
        with self.assertRaises(ValueError):validate_backup(self.root)
    def test_symlink(self):
        self.archive('link',tarfile.SYMTYPE);self.manifest()
        with self.assertRaises(ValueError):validate_backup(self.root)
    def test_windows_path(self):
        self.archive('C:\\outside');self.manifest()
        with self.assertRaises(ValueError):validate_backup(self.root)
    def test_manifest_path(self):
        (self.root/'checksums.json').write_text(json.dumps([{'name':'../escape','sha256':'x'}]*3))
        with self.assertRaises(ValueError):validate_backup(self.root)

if __name__=='__main__':unittest.main()
