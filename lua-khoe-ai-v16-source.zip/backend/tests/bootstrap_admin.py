"""Explicit acceptance-only fixture, never an HTTP bootstrap endpoint."""
import os
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

def main():
    if os.getenv('APP_ENV')!='test' or os.getenv('ACCEPTANCE_FIXTURE')!='true':
        raise SystemExit('Acceptance fixture requires explicit isolated test configuration.')
    email=os.environ['TEST_ADMIN_EMAIL'];password=os.environ['TEST_ADMIN_PASSWORD']
    if not email.endswith('@example.com') or len(password)<24:raise SystemExit('Invalid fixture credentials.')
    from sqlalchemy import select
    from app.db import SessionLocal,User
    from app.security import hasher
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.email==email)):raise SystemExit('Fixture exists; refusing to change an existing account.')
        db.add(User(email=email,name='ADMIN ACCEPTANCE FIXTURE',password_hash=hasher.hash(password),role='admin'));db.commit()
    print('Isolated acceptance admin created; credentials omitted.')

if __name__=='__main__':main()
