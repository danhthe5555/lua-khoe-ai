import os
import subprocess
import sys
import unittest
from pathlib import Path

class BootstrapGuardTests(unittest.TestCase):
    def check_rejected(self,app_env,flag,password='x'*32):
        env={**os.environ,'APP_ENV':app_env,'ACCEPTANCE_FIXTURE':flag,'TEST_ADMIN_EMAIL':'fixture@example.com','TEST_ADMIN_PASSWORD':password}
        result=subprocess.run([sys.executable,str(Path(__file__).with_name('bootstrap_admin.py'))],env=env,capture_output=True,text=True,timeout=10)
        self.assertNotEqual(result.returncode,0)
        self.assertNotIn('Traceback',result.stderr)
        self.assertNotIn(password,result.stdout+result.stderr)
    def test_production_rejected(self):self.check_rejected('production','true')
    def test_missing_opt_in_rejected(self):self.check_rejected('test','false')
    def test_weak_fixture_credentials_rejected(self):self.check_rejected('test','true','short')

if __name__=='__main__':unittest.main()
