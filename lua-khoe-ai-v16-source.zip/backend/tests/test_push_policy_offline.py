import base64
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.push_policy import validate_subscription,reminder_digest,configured

def enc(value):return base64.urlsafe_b64encode(value).decode().rstrip('=')

class PushPolicyTests(unittest.TestCase):
    def setUp(self):self.keys={'auth':enc(b'a'*16),'p256dh':enc(b'\x04'+b'b'*64)}
    def test_known_services(self):
        for host in ('fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com'):
            self.assertEqual(len(validate_subscription('https://'+host+'/fixture',self.keys)),64)
    def test_ssrf_and_deceptive_hosts(self):
        for url in ['http://fcm.googleapis.com/x','https://localhost/x','https://127.0.0.1/x','https://fcm.googleapis.com.evil.test/x','https://user@fcm.googleapis.com/x','https://fcm.googleapis.com:444/x','https://fcm.googleapis.com/x#fragment','https://fcm.googleapis.com/x\r\nheader']:
            with self.assertRaises(ValueError):validate_subscription(url,self.keys)
    def test_keys_strict(self):
        for keys in ({**self.keys,'auth':enc(b'x')},{**self.keys,'p256dh':enc(b'\x03'+b'b'*64)},{**self.keys,'auth':'$bad'},{**self.keys,'extra':'x'}):
            with self.assertRaises(ValueError):validate_subscription('https://fcm.googleapis.com/x',keys)
    def test_disabled_by_default(self):
        with patch.dict(os.environ,{},clear=True):self.assertFalse(configured())
    def test_requires_all_keys(self):
        with patch.dict(os.environ,{'PUSH_ENABLED':'true','VAPID_PUBLIC_KEY':'fixture'},clear=True):self.assertFalse(configured())
    def test_fingerprint_order_independent(self):
        self.assertEqual(reminder_digest([('a','1'),('b','2')]),reminder_digest([('b','2'),('a','1')]))
    def test_changed_work_updates_fingerprint(self):
        self.assertNotEqual(reminder_digest([('a','1')]),reminder_digest([('a','2')]))
        self.assertIsNone(reminder_digest([]))

if __name__=='__main__':unittest.main()
