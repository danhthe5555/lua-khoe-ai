import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.knowledge_search import search_articles


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.article=dict(id='one',code='fixture',title='Bệnh đốm lá',reviewed_at=None,sources=[],
                          content={'field_check':'Không kết luận chỉ từ một ảnh. Đối chiếu đốm lá ngoài ruộng.'})

    def test_vietnamese_unaccented(self):
        self.assertEqual(search_articles('dom la', [self.article])[0]['id'], 'one')

    def test_verbatim_conditions(self):
        result=search_articles('ảnh', [self.article])[0]
        self.assertEqual(result['extracts'][0]['text'], self.article['content']['field_check'])

    def test_absent_or_punctuation_no_answer(self):
        for query in ['!!!', 'unrelatedkeyword']:
            self.assertEqual(search_articles(query, [self.article]), [])

    def test_internal_fields_not_returned(self):
        result=search_articles('đốm', [{**self.article,'created_by':'private','reuse_permission':'private'}])[0]
        self.assertNotIn('created_by',result)
        self.assertNotIn('reuse_permission',result)

    def test_limit_and_stable_order(self):
        articles=[{**self.article,'id':str(i)} for i in range(10)]
        self.assertEqual([r['id'] for r in search_articles('đốm',reversed(articles))], ['0','1','2','3','4'])


if __name__=='__main__':unittest.main()
