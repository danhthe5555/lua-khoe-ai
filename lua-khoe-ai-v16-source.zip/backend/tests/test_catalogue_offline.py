from datetime import date
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.label_catalogue import validate_review,public_label

class CatalogueTests(unittest.TestCase):
    def setUp(self):
        self.today=date(2026,11,16)
        self.row={key:'TEST FIXTURE ONLY' for key in ('id','registration','name','crop','target','ingredients','label_text','precautions','reviewed_at')}
        self.row.update(valid_until='2026-11-16',source={'title':'Fixture','url':'https://example.com','publisher':'Fixture','checked_at':'2026-11-15','reuse_permission':'PRIVATE NOTE'})
    def test_review_valid_on_boundary(self):validate_review(self.row,self.today)
    def test_expired_rejected(self):
        with self.assertRaises(ValueError):validate_review({**self.row,'valid_until':'2026-11-15'},self.today)
    def test_future_source_rejected(self):
        with self.assertRaises(ValueError):validate_review({**self.row,'source':{**self.row['source'],'checked_at':'2026-11-17'}},self.today)
    def test_missing_precautions_rejected(self):
        with self.assertRaises(ValueError):validate_review({**self.row,'precautions':'  '},self.today)
    def test_missing_permission_rejected(self):
        with self.assertRaises(ValueError):validate_review({**self.row,'source':{**self.row['source'],'reuse_permission':''}},self.today)
    def test_public_excludes_internal_metadata(self):
        result=public_label({**self.row,'created_by':'PRIVATE','reviewed_by':'PRIVATE'})
        self.assertNotIn('created_by',result);self.assertNotIn('reviewed_by',result)
        self.assertNotIn('reuse_permission',result['source'])

if __name__=='__main__':unittest.main()
