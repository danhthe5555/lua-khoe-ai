import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.stage_guidance import guidance
from app.calendar_export import calendar_event


class GuidanceTests(unittest.TestCase):
    def setUp(self):
        self.article={'id':'fixture','sources':[{'title':'TEST ONLY'}],'reviewed_at':'2026-11-12',
                      'content':{'stage_seedling':'Fixture seedling instruction','stage_heading':'Fixture heading instruction'}}

    def test_stage_selects_correct_revision_text(self):
        self.assertEqual(guidance(self.article,'seedling')['text'],'Fixture seedling instruction')
        self.assertEqual(guidance(self.article,'heading')['text'],'Fixture heading instruction')
        self.assertEqual(guidance(self.article,'heading')['knowledge_id'],'fixture')

    def test_no_fallback_from_another_stage(self):
        result=guidance(self.article,'ripening')
        self.assertEqual(result['status'],'content_unavailable')
        self.assertIsNone(result['text'])

    def test_requires_review_and_sources(self):
        for article in [None,{**self.article,'reviewed_at':None},{**self.article,'sources':[]}]:
            self.assertIsNone(guidance(article,'seedling')['text'])

    def test_invalid_stage_rejected(self):
        with self.assertRaises(ValueError):guidance(self.article,'arbitrary')


class CalendarTests(unittest.TestCase):
    def event(self,**values):
        return {'id':'fixture','title':'Kiểm tra lá','notes':'Ghi chú',
                'due_at':datetime(2026,11,12,9,tzinfo=timezone(timedelta(hours=7))),**values}

    def test_timezone_and_private(self):
        text=calendar_event(self.event()).decode()
        self.assertIn('DTSTART:20261112T020000Z\r\n',text)
        self.assertIn('CLASS:PRIVATE\r\n',text)
        self.assertIn('TRIGGER:-PT15M\r\n',text)

    def test_newline_cannot_inject_event(self):
        text=calendar_event(self.event(title='fake\r\nEND:VEVENT\r\nBEGIN:VEVENT',notes='a,b;c\\d')).decode()
        self.assertEqual(text.count('\r\nBEGIN:VEVENT\r\n'),1)
        self.assertIn('DESCRIPTION:a\\,b\\;c\\\\d',text)

    def test_unicode_lines_fold_on_bytes(self):
        text=calendar_event(self.event(title='Nhắc kiểm tra ruộng lúa '*40)).decode()
        self.assertTrue(all(len(line.encode())<=75 for line in text.split('\r\n')))
        unfolded=text.replace('\r\n ','')
        self.assertIn('SUMMARY:'+'Nhắc kiểm tra ruộng lúa '*40,unfolded)

    def test_stable_uid_and_upper_date(self):
        text=calendar_event(self.event(due_at=datetime.max.replace(tzinfo=timezone.utc))).decode()
        self.assertIn('UID:fixture@lua-khoe.local',text)
        self.assertIn('DURATION:PT15M',text)


if __name__=='__main__':unittest.main()
