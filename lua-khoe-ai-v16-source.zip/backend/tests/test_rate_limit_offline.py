import sys
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.rate_limit import RateLimiter

class RateLimitTests(unittest.TestCase):
    def setUp(self):
        self.time=0;self.limiter=RateLimiter(limit=2,window=60,max_entries=2,clock=lambda:self.time)
    def test_window_boundary(self):
        self.assertTrue(self.limiter.allow('a'));self.assertTrue(self.limiter.allow('a'))
        self.assertFalse(self.limiter.allow('a'));self.time=60;self.assertTrue(self.limiter.allow('a'))
    def test_distinct_clients(self):
        self.limiter.allow('a');self.limiter.allow('a');self.assertTrue(self.limiter.allow('b'))
    def test_memory_bound_fails_closed(self):
        self.limiter.allow('a');self.limiter.allow('b');self.assertFalse(self.limiter.allow('c'))
        self.assertEqual(len(self.limiter.entries),2)
    def test_expired_capacity_reclaimed(self):
        self.limiter.allow('a');self.time=1;self.limiter.allow('b');self.time=60
        self.assertTrue(self.limiter.allow('c'));self.assertNotIn('a',self.limiter.entries)
    def test_denials_do_not_extend_window(self):
        self.limiter.allow('a');self.limiter.allow('a');self.time=59;self.assertFalse(self.limiter.allow('a'))
        self.time=60;self.assertTrue(self.limiter.allow('a'))
    def test_clear(self):
        self.limiter.allow('a');self.limiter.clear();self.assertEqual(len(self.limiter.entries),0)
    def test_concurrent_attempts(self):
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(lambda _:self.limiter.allow('a'),range(20)))
        self.assertEqual(sum(results),2)

if __name__=='__main__':unittest.main()
