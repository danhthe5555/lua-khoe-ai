import hashlib
import io
import json
import os
import time
import warnings
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 20_000_000

class PredictionService:
    def __init__(self):
        self.model = None
        self.error = 'Chưa cấu hình mô hình.'

    def load_model(self):
        try:
            import torch
            from torchvision import models, transforms
            root = Path(os.environ['MODEL_DIR'])
            self.metadata = json.loads((root / 'metadata.json').read_text(encoding='utf-8'))
            m = self.metadata
            weights = root / 'weights.pt'
            self.sha = hashlib.sha256(weights.read_bytes()).hexdigest()
            if self.sha != m['weights_sha256']:raise ValueError('Checksum mismatch')
            if m['architecture'] != 'efficientnet_b0':raise ValueError('Unsupported architecture')
            self.labels = m['class_names']
            if len(self.labels) != len(set(self.labels)) or len(self.labels)<=1:raise ValueError('Invalid class map')
            if set(m['display_names_vi']) != set(self.labels):raise ValueError('Incomplete display labels')
            self.model = models.efficientnet_b0(weights=None)
            self.model.classifier[-1] = torch.nn.Linear(self.model.classifier[-1].in_features, len(self.labels))
            self.model.load_state_dict(torch.load(weights, map_location='cpu', weights_only=True), strict=True)
            self.model.eval()
            torch.set_num_threads(int(os.getenv('TORCH_THREADS', '4')))
            p = m['preprocessing']
            self.transform = transforms.Compose([
                transforms.Resize(p['eval_resize'], interpolation=transforms.InterpolationMode(p['interpolation']), antialias=True),
                transforms.CenterCrop(p['input_size']), transforms.ToTensor(), transforms.Normalize(p['mean'], p['std'])])
            self.mapping_version = hashlib.sha256(json.dumps(self.labels).encode()).hexdigest()
            self.preprocessing_version = hashlib.sha256(json.dumps(p, sort_keys=True).encode()).hexdigest()
            self.error = None
        except Exception:
            self.model = None
            self.error = 'Mô hình chưa sẵn sàng hoặc cấu hình không khớp.'

    def validate_image(self, data):
        if not data or len(data) > 10 * 1024 * 1024:
            raise ValueError('Ảnh phải có dung lượng từ 1 byte đến 10 MB.')
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                image = Image.open(io.BytesIO(data))
                if image.format not in ('JPEG', 'PNG', 'WEBP'):
                    raise ValueError('Chỉ nhận ảnh JPEG, PNG hoặc WebP.')
                image.verify()
                image = Image.open(io.BytesIO(data))
                if min(image.size) < 64:
                    raise ValueError('Ảnh quá nhỏ. Hãy chụp lại rõ lá lúa.')
                image = ImageOps.exif_transpose(image).convert('RGB')
                image.load()
                return image
        except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning):
            raise ValueError('Ảnh hỏng hoặc kích thước ảnh không an toàn.')

    def predict(self, image):
        import torch
        if self.model is None:
            raise RuntimeError(self.error)
        started = time.perf_counter()
        with torch.inference_mode():
            probabilities = self.model(self.transform(image).unsqueeze(0)).float().softmax(1)[0]
        scores, indices = probabilities.topk(min(3, len(self.labels)))
        top = [{'class_id': int(i), 'label': self.labels[i], 'label_vi': self.metadata['display_names_vi'][self.labels[i]], 'score': float(s)} for s, i in zip(scores.tolist(), indices.tolist())]
        return {'model_version': self.sha, 'label_mapping_version': self.mapping_version,
                'preprocessing_version': self.preprocessing_version, 'knowledge_version': None,
                'predicted_class': top[0]['label'], 'display_label_vi': top[0]['label_vi'],
                'raw_score': top[0]['score'], 'top_k': top, 'quality_status': 'uncertain',
                'review_message': 'Đây là điểm dự đoán, không phải độ chính xác chẩn đoán. Chưa kiểm định khả năng phát hiện ảnh ngoài phạm vi. Hãy đối chiếu triệu chứng thực tế.',
                'elapsed_ms': round((time.perf_counter()-started)*1000, 2)}

    def health_status(self):
        return {'ready': self.model is not None, 'message': self.error}

predictor = PredictionService()
