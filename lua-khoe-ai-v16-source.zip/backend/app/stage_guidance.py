"""Select reviewed text for an explicit growth stage, without inventing rules."""
STAGES = {
    'seedling': 'Mạ / cây con',
    'tillering': 'Đẻ nhánh',
    'booting': 'Làm đòng',
    'heading': 'Trổ bông',
    'grain_filling': 'Chắc hạt',
    'ripening': 'Chín',
}


def guidance(article, stage):
    if stage not in STAGES:
        raise ValueError('Unknown growth stage')
    text = (article.get('content', {}).get('stage_' + stage) or '').strip() if article else ''
    ready = bool(article and article.get('sources') and article.get('reviewed_at') and text)
    return {
        'status': 'available' if ready else 'content_unavailable',
        'stage': stage, 'stage_name': STAGES[stage],
        'text': text if ready else None,
        'reason': 'Bạn chọn giai đoạn ' + STAGES[stage] + '; hệ thống chỉ lấy nội dung đã duyệt đúng giai đoạn này.' if ready
                  else 'Chưa có hướng dẫn đã duyệt cho giai đoạn này. Không tự dùng hướng dẫn của giai đoạn khác.',
        'knowledge_id': article['id'] if ready else None,
        'reviewed_at': article['reviewed_at'] if ready else None,
        'sources': article['sources'] if ready else [],
    }
