"""Backup validation and inventories; never print private records or credentials."""
import hashlib
import json
import os
import tarfile
from pathlib import Path, PurePosixPath

FILES=('database.dump','images.tar.gz','inventory.json')

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def validate_backup(directory):
    root=Path(directory)
    manifest=json.loads((root/'checksums.json').read_text(encoding='utf-8-sig'))
    if not isinstance(manifest,list) or len(manifest)!=len(FILES):raise ValueError('Invalid manifest')
    if {entry['name'] for entry in manifest}!=set(FILES):raise ValueError('Unexpected backup files')
    for entry in manifest:
        file=root/entry['name']
        if file.is_symlink() or not file.is_file() or sha256(file).lower()!=entry['sha256'].lower():
            raise ValueError('Backup checksum mismatch')
    with tarfile.open(root/'images.tar.gz','r:gz') as archive:
        seen=set()
        for item in archive:
            name=PurePosixPath(item.name)
            if name.is_absolute() or '..' in name.parts or '\\' in item.name or ':' in item.name:
                raise ValueError('Unsafe archive path')
            if not (item.isfile() or item.isdir()):raise ValueError('Archive links/special files forbidden')
            if item.isfile():
                if len(name.parts)!=1 or str(name) in seen:raise ValueError('Unexpected image path')
                seen.add(str(name))
    return True

def inventory():
    from sqlalchemy import select,func
    from .db import Base,SessionLocal,Plot,Season,Diagnosis,Activity,Feedback,PushSubscription,Session
    root=Path(os.environ['STORAGE_LOCAL_DIR'])
    with SessionLocal() as db:
        counts={table.name:db.scalar(select(func.count()).select_from(table)) for table in Base.metadata.sorted_tables}
        plots={p.id:p.user_id for p in db.scalars(select(Plot))}
        seasons={s.id:(s.user_id,s.plot_id) for s in db.scalars(select(Season))}
        diagnoses={d.id:(d.user_id,d.season_id,d.image_key) for d in db.scalars(select(Diagnosis))}
        for owner,plot in seasons.values():
            if plots.get(plot)!=owner:raise ValueError('Season ownership mismatch')
        for owner,season,_ in diagnoses.values():
            if season and (season not in seasons or seasons[season][0]!=owner):raise ValueError('Diagnosis ownership mismatch')
        for a in db.scalars(select(Activity)):
            if a.season_id and (a.season_id not in seasons or seasons[a.season_id][0]!=a.user_id):raise ValueError('Activity ownership mismatch')
            if a.diagnosis_id and (a.diagnosis_id not in diagnoses or diagnoses[a.diagnosis_id][0]!=a.user_id):raise ValueError('Activity diagnosis mismatch')
        for f in db.scalars(select(Feedback)):
            if f.diagnosis_id not in diagnoses or diagnoses[f.diagnosis_id][0]!=f.user_id:raise ValueError('Feedback ownership mismatch')
        sessions={s.id:s.user_id for s in db.scalars(select(Session))}
        for subscription in db.scalars(select(PushSubscription)):
            if sessions.get(subscription.session_id)!=subscription.user_id:raise ValueError('Push session ownership mismatch')
        images={}
        for _,_,key in diagnoses.values():
            if key:
                if Path(key).name!=key or '/' in key or '\\' in key:raise ValueError('Invalid image key')
                file=root/key
                if file.is_symlink() or not file.is_file():raise ValueError('Referenced image missing')
                images[key]=sha256(file)
        return {'schema_version':1,'counts':counts,'referenced_images':images}

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('action',choices=['snapshot','verify','compare']);p.add_argument('path');args=p.parse_args()
    if args.action=='verify':validate_backup(args.path)
    elif args.action=='snapshot':Path(args.path).write_text(json.dumps(inventory(),indent=2),encoding='utf-8')
    else:
        expected=json.loads(Path(args.path).read_text(encoding='utf-8'))
        if inventory()!=expected:raise ValueError('Restored database/images differ from backup inventory')
    print('Backup check completed: '+args.action)

if __name__=='__main__':main()
