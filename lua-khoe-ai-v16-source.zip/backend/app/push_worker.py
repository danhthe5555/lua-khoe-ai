"""Explicit opt-in worker; no sends unless PUSH_ENABLED and --send are set."""
import argparse
import json
import os
import time
from datetime import timezone,timedelta
from sqlalchemy import select
from .db import SessionLocal,PushSubscription,Session,User,Activity,now
from .push_policy import configured,validate_subscription,reminder_digest

def send(record):
    from pywebpush import webpush,WebPushException
    import requests
    class NoRedirect(requests.Session):
        def request(self,*args,**kwargs):
            kwargs['allow_redirects']=False
            return super().request(*args,**kwargs)
    validate_subscription(record.endpoint,record.keys)
    try:
        with NoRedirect() as connection:
            connection.trust_env=False
            webpush({'endpoint':record.endpoint,'keys':record.keys},
                    data=json.dumps({'subscription_id':record.id}),vapid_private_key=os.environ['VAPID_PRIVATE_KEY'],
                    vapid_claims={'sub':os.environ['VAPID_SUBJECT']},timeout=15,ttl=60,requests_session=connection)
        return 'sent'
    except WebPushException as error:
        response=getattr(error,'response',None)
        return 'expired' if response is not None and response.status_code in (404,410) else 'retry'

def run_once():
    if not configured():raise RuntimeError('Web Push is disabled or keys are missing')
    with SessionLocal() as db:ids=list(db.scalars(select(PushSubscription.id)))
    counts={'sent':0,'retry':0,'expired':0}
    for id in ids:
        with SessionLocal() as db:
            record=db.scalar(select(PushSubscription).where(PushSubscription.id==id).with_for_update())
            if not record:continue
            session=db.get(Session,record.session_id);user=db.get(User,record.user_id)
            if not session or session.user_id!=record.user_id or session.expires_at.replace(tzinfo=timezone.utc)<=now() or not user or not user.active or user.role!='farmer':
                db.delete(record);db.commit();continue
            rows=db.execute(select(Activity.id,Activity.updated_at).where(Activity.user_id==record.user_id,Activity.kind=='reminder',Activity.completed==False,Activity.due_at<=now())).all()
            fingerprint=reminder_digest(rows)
            if not fingerprint:
                record.last_digest=None;db.commit();continue
            if fingerprint==record.last_digest or record.last_attempt and now()-record.last_attempt.replace(tzinfo=timezone.utc)<timedelta(minutes=15):continue
            record.last_attempt=now()
            try:status=send(record)
            except Exception:status='retry'  # Do not log private endpoint/keys or provider bodies.
            counts[status]+=1
            if status=='expired':db.delete(record)
            elif status=='sent':record.last_digest=fingerprint
            db.commit()
    return counts

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--send',action='store_true');parser.add_argument('--loop',action='store_true');args=parser.parse_args()
    if not args.send:raise SystemExit('No notifications sent. Use --send only after configuring opt-in subscriptions.')
    while True:
        print(run_once(),flush=True)
        if not args.loop:break
        time.sleep(60)
