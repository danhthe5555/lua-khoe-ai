import hashlib
import os
import secrets
from datetime import timezone
from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
from .db import get_db, Session, User, now

hasher = PasswordHasher()
dummy_hash = hasher.hash(secrets.token_urlsafe(32))

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()

def verify(password, hashed):
    try:
        return hasher.verify(hashed, password)
    except VerificationError:
        return False

def current(request: Request, db=Depends(get_db)):
    token = request.cookies.get('session')
    session = db.scalar(select(Session).where(Session.token_hash == digest(token))) if token else None
    if not session or session.expires_at.replace(tzinfo=timezone.utc) <= now():
        raise HTTPException(401, 'Vui lòng đăng nhập lại.')
    user = db.get(User, session.user_id)
    if not user or not user.active:
        raise HTTPException(401, 'Phiên đăng nhập không còn hiệu lực.')
    if request.method not in ('GET', 'HEAD', 'OPTIONS'):
        if not secrets.compare_digest(request.headers.get('X-CSRF-Token', ''), session.csrf):
            raise HTTPException(403, 'Yêu cầu không hợp lệ. Hãy tải lại trang.')
    request.state.session = session
    return user

def farmer(user=Depends(current)):
    if user.role != 'farmer':
        raise HTTPException(403, 'Chức năng dành cho tài khoản nông dân.')
    return user

def admin(user=Depends(current)):
    if user.role != 'admin':
        raise HTTPException(403, 'Bạn không có quyền quản trị.')
    return user

def profile(user):
    return {'id': user.id, 'name': user.name, 'email': user.email, 'role': user.role, 'active': user.active}
