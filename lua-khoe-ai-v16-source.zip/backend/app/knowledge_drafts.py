"""Source-based review drafts for the current rice-leaf model labels."""

IRRI = ('Diagnosis of Common Diseases of Rice', 'International Rice Research Institute',
        'https://www.knowledgebank.irri.org/images/docs/diagnostic-of-common-diseases-of-rice.pdf')
PHILRICE = ('Field Guide on Major Disorders of the Rice Plant', 'Philippine Rice Research Institute',
            'https://www.philrice.gov.ph/wp-content/uploads/2023/02/Field-Guide_-Major-Disorders-of-the-rice-plant-Diseases-and-Nutritional-Deficiencies.pdf')
LSU = ('Leaf Smut of Rice', 'LSU AgCenter',
       'https://www.lsuagcenter.com/~/media/system/2/4/f/4/24f45ba528119f20218233f1be1b608f/pub3115leafsmutlowres.pdf')
VIETNAM_TUNGRO = ('QCVN 01-140:2013/BNNPTNT, Phụ lục 1 về triệu chứng bệnh virus hại lúa',
                  'Bộ Nông nghiệp và Phát triển nông thôn',
                  'https://vbpl.vn/FileData/TW/Lists/vbpq/Attachments/30679/VanBanGoc_32.2013.TT.BNNPTNT.pdf')
BROWN_SPOT = ('Rice brown leaf spot (427)', 'Pacific Pests, Pathogens & Weeds',
              'https://apps.lucidcentral.org/pppw_v13/pdf/web_full/rice_brown_leaf_spot_427.pdf')
BLAST = ('Rice Blast — Pest Management Guidelines', 'University of California Statewide IPM Program',
         'https://ipm.ucanr.edu/agriculture/rice/rice-blast/')
SHEATH_BLIGHT = ('Rice Sheath Blight', 'American Phytopathological Society',
                'https://www.apsnet.org/edcenter/pdlessons/Pages/RiceSheath.aspx')
TUNGRO = ('Tungro — Factsheet', 'International Rice Research Institute',
          'https://keyserver.lucidcentral.org/key-server/data/0e090d01-0209-460e-810c-0d060708030c/media/Html/Tungro.htm')
REGISTER = ('Thông tư 75/2025/TT-BNNMT — Danh mục thuốc bảo vệ thực vật',
            'Bộ Nông nghiệp và Môi trường',
            'https://vanban.chinhphu.vn/?docid=216337&pageid=27160')
REGISTER_UPDATE = 'https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/7/28-bnnmt-kem.pdf'
PLANT_PROTECTION_LAW = ('Luật Bảo vệ và kiểm dịch thực vật số 41/2013/QH13, Điều 72',
                       'Quốc hội',
                       'https://vbpl.vn/FileData/TW/Lists/vbpq/Attachments/32909/VanBanGoc_41.2013.QH13.pdf')

LABEL_CAUTION = ('Chỉ cân nhắc thuốc sau khi xác minh bệnh và thấy cần xử lý. Đối chiếu đúng tên thương phẩm, '
                 'dạng thuốc và cặp bệnh/cây lúa trên nhãn tiếng Việt và danh mục hiện hành. Tuân thủ liều, '
                 'cách dùng, bảo hộ và thời gian cách ly trên chính nhãn đó. Không lấy liều từ sản phẩm khác '
                 'hoặc tự pha trộn. Điểm dự đoán AI không phải ngưỡng quyết định phun.')


def reference(title, publisher, url):
    return {'title': title, 'publisher': publisher, 'url': url, 'checked_at': '2026-11-21',
            'reuse_permission': 'Tóm lược bằng lời riêng và dẫn liên kết tài liệu gốc; không sao chép hình ảnh.'}


REFERENCE_DRAFTS = (
    {
        'code': 'Brown_Spot', 'title': 'Bệnh đốm nâu',
        'content': {
            'symptoms': 'Trên lá đã phát triển, vết thường tròn hoặc bầu dục, tâm nâu nhạt đến xám, viền nâu đỏ.',
            'field_check': 'Chụp cận cảnh một vết và chụp toàn lá. Đốm nâu thường tròn hoặc bầu dục, còn vết đạo ôn điển hình thuôn nhọn ở hai đầu. So sánh trên nhiều lá vì hình dạng vết có thể thay đổi theo giống. Tác nhân đốm nâu là nấm Bipolaris oryzae.',
            'treatment': 'Kiểm tra ruộng có bị thiếu nước hoặc mất cân đối dinh dưỡng không, nhất là ở vùng cây sinh trưởng kém. Điều chỉnh nước và phân bón theo tình trạng ruộng và hướng dẫn địa phương. Khi vết xuất hiện trên nhiều khóm hoặc tiếp tục lan sau khi đã điều chỉnh, nhờ cán bộ kỹ thuật kiểm tra lại tác nhân.',
            'medicine': 'Ưu tiên xử lý nước và dinh dưỡng. Nếu cán bộ kỹ thuật xác nhận cần dùng thuốc, hãy đối chiếu đúng mục đốm nâu trên lúa trong danh mục và trên nhãn. Đăng ký cho đốm nâu trên lạc hoặc cây khác không áp dụng cho lúa.',
            'cautions': 'Hình dạng vết thay đổi theo giống và tuổi lá. Không tự chuyển sang thuốc trị đạo ôn chỉ vì vết trông tương tự. ' + LABEL_CAUTION,
            'prevention': 'Ưu tiên hạt giống được chứng nhận cho vụ sau. Xem lại tình trạng nước và dinh dưỡng của ruộng cùng cán bộ kỹ thuật để chọn biện pháp phù hợp.',
            'stage_seedling': 'Quan sát vết nâu trên cây mạ và ghi lại vùng cây sinh trưởng kém để cán bộ kỹ thuật đối chiếu thêm.',
            'stage_grain_filling': 'Ghi lại vết trên lá và dấu hiệu đổi màu ở vỏ hạt nếu quan sát được. Chụp riêng từng bộ phận để đối chiếu.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*BROWN_SPOT), reference(*REGISTER), reference(*PLANT_PROTECTION_LAW)],
    },
    {
        'code': 'Blast', 'title': 'Bệnh đạo ôn',
        'content': {
            'symptoms': 'Vết trên lá thường thuôn, nhọn về hai đầu, tâm xám và viền sẫm. Biểu hiện có thể khác nhau theo giống và tuổi vết.',
            'field_check': 'Ghi riêng vị trí tổn thương ở phiến lá, cổ lá hoặc cổ bông. Gửi ảnh cận cảnh và ảnh toàn khóm khi cần xác minh. Đạo ôn trên lá và trên cổ bông cần được quan sát ở đúng bộ phận.',
            'treatment': 'Kiểm tra nhiều khóm để xác định phạm vi bệnh. Tránh bón thúc thêm đạm khi bệnh đang phát triển. Giữ nước phù hợp với giai đoạn sinh trưởng theo hướng dẫn địa phương. Nếu thấy cổ bông sẫm màu, bông bạc hoặc lúa đang trổ ở ruộng có bệnh, liên hệ sớm với cán bộ bảo vệ thực vật.',
            'medicine': 'Ví dụ để đối chiếu nhãn khi đã xác nhận đạo ôn trên lúa: Beyond 40SC (tricyclazole), đăng ký đạo ôn/lúa tại Phụ lục II Thông tư 28/2026/TT-BNNMT. Với dấu hiệu ở cổ bông, xác nhận đúng vị trí bệnh và yêu cầu ghi trên nhãn trước khi chọn thuốc.',
            'cautions': LABEL_CAUTION,
            'prevention': 'Khi chọn giống, hỏi cán bộ địa phương về giống có khả năng kháng đạo ôn phù hợp vùng trồng. Bón phân cân đối và tránh bón thừa đạm.',
            'stage_tillering': 'Kiểm tra phiến lá ở nhiều khóm và ghi lại vết thuôn mới xuất hiện.',
            'stage_heading': 'Quan sát thêm cổ bông và ghi nhận riêng những bông có phần cổ đổi màu. Ảnh lá riêng lẻ chưa đủ để đánh giá cổ bông.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*BLAST), reference(*REGISTER),
                    reference('Phụ lục II Thông tư 28/2026/TT-BNNMT, thuốc trừ bệnh mục 113',
                              'Bộ Nông nghiệp và Môi trường', REGISTER_UPDATE + '#page=17'),
                    reference(*PLANT_PROTECTION_LAW)],
    },
    {
        'code': 'Healthy', 'title': 'Lá lúa khỏe theo ảnh quan sát',
        'content': {
            'symptoms': 'Mô hình xếp phần lá trong ảnh vào nhóm lá khỏe. Kết quả chỉ mô tả ảnh đã gửi. Ngay cả khi ảnh nhìn bình thường, các lá khác, bẹ và cổ bông vẫn cần được quan sát trực tiếp.',
            'field_check': 'Kiểm tra cả khóm, lá ở các tầng và các khóm xung quanh. Chụp lại khi có vết mới, vàng lá hoặc sinh trưởng bất thường.',
            'treatment': 'Tiếp tục thăm ruộng và quan sát thêm nếu xuất hiện dấu hiệu mới. Nếu cây sinh trưởng kém hoặc vàng bất thường dù ảnh lá nhìn bình thường, kiểm tra cả khóm, bẹ, cổ bông và điều kiện ruộng.',
            'medicine': 'Không có căn cứ phun thuốc từ một kết quả “lá lúa khỏe”.',
            'cautions': 'Ảnh lá nhìn bình thường không xác nhận toàn ruộng sạch bệnh. Nếu có dấu hiệu ở bộ phận khác, chụp riêng bộ phận đó và hỏi cán bộ kỹ thuật khi cần.',
            'prevention': 'Duy trì lịch quan sát ruộng và ghi nhận thay đổi theo thời gian để đối chiếu khi cần.',
        },
        'sources': [reference(*IRRI)],
    },
    {
        'code': 'Leaf_Smut', 'title': 'Đốm than trên lá lúa',
        'content': {
            'symptoms': 'Trên lá có thể thấy nhiều đốm đen nhỏ hơi nổi và nằm tách nhau. Tổn thương thường được quan sát vào cuối vụ.',
            'field_check': 'Chụp cả hai mặt lá dưới ánh sáng đều. Tìm các đốm đen hơi nổi, riêng rẽ trên phiến lá. Đây là nhóm dấu hiệu của bệnh do nấm Entyloma oryzae; cần mô tả riêng nếu thấy bất thường chủ yếu ở hạt hoặc bông.',
            'treatment': 'Ghi lại vị trí và theo dõi các lá khác. Nếu lá vàng hoặc héo trên diện rộng, nhờ cán bộ kỹ thuật kiểm tra bệnh khác hoặc nguyên nhân đi kèm.',
            'medicine': 'LSU AgCenter ghi nhận bệnh thường gây thiệt hại ít và không khuyến nghị phòng trừ riêng. Không phun chỉ vì ảnh được xếp vào nhóm đốm than lá.',
            'cautions': 'Tổn thương chủ yếu ở hạt hoặc bông cần được kiểm tra theo nhóm bệnh khác. Chụp riêng hạt hoặc bông để đối chiếu.',
            'prevention': 'Bón phân cân đối, tránh bón thừa đạm và tiếp tục kiểm tra lá vào cuối vụ.',
            'stage_ripening': 'Chụp cận cảnh các đốm còn tách biệt và ghi vị trí lá bị ảnh hưởng. Trao đổi với cán bộ kỹ thuật nếu vàng lá lan rộng.',
        },
        'sources': [reference(*LSU)],
    },
    {
        'code': 'Rice_Tungro', 'title': 'Bệnh Tungro trên lúa',
        'content': {
            'symptoms': 'Khóm lúa có thể thấp, ít nhánh và lá chuyển vàng đến vàng cam, thường thấy từ chóp lá.',
            'field_check': 'So sánh chiều cao và số nhánh của các khóm. Ghi thêm lá vàng cam, đốm màu gỉ sắt hoặc bông ngắn nếu thấy. Tài liệu kỹ thuật Việt Nam liệt kê Tungro và bệnh vàng lùn do virus lúa cỏ là hai mục riêng. Cần đối chiếu chuyên môn khi các dấu hiệu giống nhau.',
            'treatment': 'Đánh dấu vùng có khóm lùn, ít nhánh và vàng cam. Báo cán bộ bảo vệ thực vật địa phương để xác minh bệnh và đánh giá rầy xanh truyền bệnh. Trao đổi về biện pháp xử lý ổ bệnh theo tình trạng ruộng.',
            'medicine': 'Cây đã nhiễm virus Tungro không có thuốc chữa. Thuốc trừ nấm không trị virus. Việc quản lý rầy xanh là biện pháp hạn chế lây lan và cần theo hướng dẫn tại địa phương. Không phun trừ rầy chỉ từ kết quả ảnh.',
            'cautions': 'Chụp cả khóm và khu vực xung quanh. Một lá vàng chưa đủ để phân biệt Tungro với thiếu dinh dưỡng hoặc các bệnh virus khác.',
            'prevention': 'Ưu tiên giống phù hợp có khả năng kháng tại địa phương, gieo đồng loạt theo lịch vùng và quản lý lúa chét, gốc rạ sau thu hoạch theo hướng dẫn kỹ thuật.',
            'stage_tillering': 'Quan sát đồng thời màu lá, số nhánh và chiều cao nhiều khóm. Ghi vị trí khóm sinh trưởng khác thường.',
            'stage_heading': 'Ghi lại nếu khóm trổ muộn hoặc bông khó thoát khỏi bẹ, kèm ảnh toàn khóm để đối chiếu.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*VIETNAM_TUNGRO), reference(*TUNGRO)],
    },
    {
        'code': 'Sheath_Blight', 'title': 'Bệnh khô vằn',
        'content': {
            'symptoms': 'Vết thường thấy ở bẹ lá thấp, ban đầu bầu dục màu xám xanh; vết lớn có thể có tâm xám trắng và viền nâu sẫm.',
            'field_check': 'Quan sát phần bẹ thấp, nhất là gần mặt nước. Chụp bẹ và toàn khóm để xác định vết bắt đầu ở đâu và đã lên đến tầng nào. Tác nhân khô vằn là nấm Rhizoctonia solani.',
            'treatment': 'Kiểm tra bẹ ở nhiều điểm trong ruộng và ghi xem vết có lan lên tầng lá trên hay không. Tránh bón thừa đạm. Khi bệnh lan lên cao hoặc nhiều khóm bị ảnh hưởng, nhờ cán bộ kỹ thuật đánh giá giai đoạn lúa và nhu cầu xử lý.',
            'medicine': 'Ví dụ để đối chiếu nhãn khi đã xác nhận khô vằn trên lúa: Anvil® 5 SC (hexaconazole), đăng ký khô vằn/lúa tại Phụ lục II Thông tư 28/2026/TT-BNNMT.',
            'cautions': 'Vết ở bẹ trên ôm đòng hoặc tổn thương rời rạc có thể thuộc bệnh khác. Kiểm tra cả bẹ thấp và bẹ trên trước khi chọn thuốc. ' + LABEL_CAUTION,
            'prevention': 'Giữ mật độ gieo phù hợp và tránh bón đạm quá mức. Trao đổi với cán bộ địa phương về quản lý nước và tàn dư thực vật theo điều kiện ruộng.',
            'stage_tillering': 'Kiểm tra các bẹ thấp ở nhiều khóm, nhất là vùng tán rậm. Ghi độ cao của vết so với gốc.',
            'stage_booting': 'So sánh vị trí vết theo các tầng bẹ với lần kiểm tra trước để có thông tin khi trao đổi với cán bộ kỹ thuật.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*SHEATH_BLIGHT), reference(*REGISTER),
                    reference('Phụ lục II Thông tư 28/2026/TT-BNNMT, thuốc trừ bệnh mục 65',
                              'Bộ Nông nghiệp và Môi trường', REGISTER_UPDATE + '#page=13'),
                    reference(*PLANT_PROTECTION_LAW)],
    },
)
