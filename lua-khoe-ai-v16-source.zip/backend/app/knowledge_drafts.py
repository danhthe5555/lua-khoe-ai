"""Source-based review drafts for the current rice-leaf model labels."""

IRRI = ('Diagnosis of Common Diseases of Rice', 'International Rice Research Institute',
        'https://www.knowledgebank.irri.org/images/docs/diagnostic-of-common-diseases-of-rice.pdf')
PHILRICE = ('Field Guide on Major Disorders of the Rice Plant', 'Philippine Rice Research Institute',
            'https://www.philrice.gov.ph/wp-content/uploads/2023/02/Field-Guide_-Major-Disorders-of-the-rice-plant-Diseases-and-Nutritional-Deficiencies.pdf')
LSU = ('Leaf Smut of Rice', 'LSU AgCenter',
       'https://www.lsuagcenter.com/~/media/system/2/4/f/4/24f45ba528119f20218233f1be1b608f/pub3115leafsmutlowres.pdf')
VIETNAM_TUNGRO = ('QCVN 01-140:2013/BNNPTNT, Phụ lục 1 về triệu chứng bệnh virus hại lúa',
                  'Bộ Nông nghiệp và Phát triển nông thôn',
                  'https://vbpl.vn/FileData/TW/Lists/vbpq/Attachments/30679/VanBanGoc_32.2013.TT.BNNPTNT.pdf')
BROWN_SPOT = ('Rice brown leaf spot (427)', 'Pacific Pests, Pathogens & Weeds',
              'https://apps.lucidcentral.org/pppw_v13/pdf/web_full/rice_brown_leaf_spot_427.pdf')
BLAST = ('Rice Blast — Pest Management Guidelines', 'University of California Statewide IPM Program',
         'https://ipm.ucanr.edu/agriculture/rice/rice-blast/')
SHEATH_BLIGHT = ('Rice Sheath Blight', 'American Phytopathological Society',
                'https://www.apsnet.org/edcenter/pdlessons/Pages/RiceSheath.aspx')
TUNGRO = ('Tungro — Factsheet', 'International Rice Research Institute',
          'https://keyserver.lucidcentral.org/key-server/data/0e090d01-0209-460e-810c-0d060708030c/media/Html/Tungro.htm')
TUNGRO_FIELD = ('Tungro — Cultural management', 'Pinoy Rice Knowledge Bank',
                'https://www.pinoyrice.com/wp-content/uploads/tungro.pdf')
SHEATH_FIELD = ('Sheath blight — Factsheet', 'International Rice Research Institute',
                'https://keyserver.lucidcentral.org/key-server/data/0e090d01-0209-460e-810c-0d060708030c/media/Html/Sheath_blight.htm')
REGISTER = ('Thông tư 75/2025/TT-BNNMT — Danh mục thuốc bảo vệ thực vật',
            'Bộ Nông nghiệp và Môi trường',
            'https://vanban.chinhphu.vn/?docid=216337&pageid=27160')
REGISTER_LIST = 'https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/12/75-bnnmt-pl1.pdf'
REGISTER_UPDATE = 'https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/7/28-bnnmt-kem.pdf'
PLANT_PROTECTION_LAW = ('Luật Bảo vệ và kiểm dịch thực vật số 41/2013/QH13, Điều 72',
                       'Quốc hội',
                       'https://vbpl.vn/FileData/TW/Lists/vbpq/Attachments/32909/VanBanGoc_41.2013.QH13.pdf')

LABEL_CAUTION = ('Chỉ cân nhắc thuốc sau khi xác minh bệnh và thấy cần xử lý. Đối chiếu đúng tên thương phẩm, '
                 'dạng thuốc và cặp bệnh/cây lúa trên nhãn tiếng Việt và danh mục hiện hành. Tuân thủ liều, '
                 'cách dùng, bảo hộ và thời gian cách ly trên chính nhãn đó. Không lấy liều từ sản phẩm khác '
                 'hoặc tự pha trộn. Điểm dự đoán AI không phải ngưỡng quyết định phun.')


def reference(title, publisher, url, checked_at='2026-11-21'):
    return {'title': title, 'publisher': publisher, 'url': url, 'checked_at': checked_at,
            'reuse_permission': 'Tóm lược bằng lời riêng và dẫn liên kết tài liệu gốc; không sao chép hình ảnh.'}


REFERENCE_DRAFTS = (
    {
        'code': 'Brown_Spot', 'title': 'Bệnh đốm nâu',
        'content': {
            'symptoms': 'Trên lá đã phát triển, vết thường tròn hoặc bầu dục, tâm nâu nhạt đến xám, viền nâu đỏ.',
            'field_check': 'Chụp cận cảnh một vết và chụp toàn lá. Đốm nâu thường tròn hoặc bầu dục, còn vết đạo ôn điển hình thuôn nhọn ở hai đầu. So sánh trên nhiều lá vì hình dạng vết có thể thay đổi theo giống. Tác nhân đốm nâu là nấm Bipolaris oryzae.',
            'treatment': 'Kiểm tra độ ẩm, nước tưới và tình trạng dinh dưỡng ở vùng lúa yếu. Điều chỉnh nước và phân bón theo tình trạng ruộng và khuyến cáo địa phương.\nNếu vết xuất hiện ở nhiều khóm hoặc vẫn có vết mới sau khi điều chỉnh, nhờ cán bộ kỹ thuật phân biệt đốm nâu với đạo ôn và các nguyên nhân khác.',
            'medicine': ('Nếu đã xác nhận bệnh trên lúa và cần xử lý bằng thuốc, đối chiếu nhãn Camilo 150SC (azoxystrobin 50 g/lít + hexaconazole 100 g/lít).\n'
                         'Liều thuốc: 0,6 lít/ha.\n'
                         'Lượng nước phun bằng bình: 400–600 lít/ha.\n'
                         'Cách dùng: lắc kỹ trước khi pha. Khi đã xác nhận bệnh và cần phun, đối chiếu hướng dẫn áp dụng lúc bệnh mới xuất hiện.\n'
                         'Cách ly trước thu hoạch: 14 ngày.'),
            'cautions': 'Hình dạng vết thay đổi theo giống và tuổi lá. Không tự chuyển sang thuốc trị đạo ôn chỉ vì vết trông tương tự. ' + LABEL_CAUTION,
            'prevention': 'Dùng hạt giống khỏe, có nguồn gốc rõ ràng. Quản lý nước và bón phân cân đối theo tình trạng ruộng.\nTrong các lượt thăm đồng, kiểm tra lá ở cả vùng cây khỏe và vùng cây yếu. Ghi lại các khóm mới có vết để cán bộ kỹ thuật đối chiếu khi cần.',
            'stage_seedling': 'Quan sát vết nâu trên cây mạ và ghi lại vùng cây sinh trưởng kém để cán bộ kỹ thuật đối chiếu thêm.',
            'stage_grain_filling': 'Ghi lại vết trên lá và dấu hiệu đổi màu ở vỏ hạt nếu quan sát được. Chụp riêng từng bộ phận để đối chiếu.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*BROWN_SPOT),
                    reference('Danh mục thuốc trừ bệnh mục 72: Camilo 150SC', 'Bộ Nông nghiệp và Môi trường', REGISTER_LIST + '#page=156', '2026-11-23'),
                    reference('Hướng dẫn Camilo 150SC trên lúa', 'ADC',
                              'https://www.adcagrotech.com/shop/thuoc-bvtv/thuoc-tru-benh/camilo-150sc-lua/', '2026-11-23'), reference(*PLANT_PROTECTION_LAW)],
    },
    {
        'code': 'Blast', 'title': 'Bệnh đạo ôn',
        'content': {
            'symptoms': 'Vết trên lá thường thuôn, nhọn về hai đầu, tâm xám và viền sẫm. Biểu hiện có thể khác nhau theo giống và tuổi vết.',
            'field_check': 'Ghi riêng vị trí tổn thương ở phiến lá, cổ lá hoặc cổ bông. Gửi ảnh cận cảnh và ảnh toàn khóm khi cần xác minh. Đạo ôn trên lá và trên cổ bông cần được quan sát ở đúng bộ phận.',
            'treatment': 'Kiểm tra nhiều khóm và ghi riêng vết trên lá, cổ lá và cổ bông. Nếu đang phát hiện vết đạo ôn mới, tạm dừng bón thúc thêm đạm và giữ nước phù hợp theo hướng dẫn địa phương.\nNếu bệnh lan ở nhiều khóm, lúa sắp trổ hoặc thấy cổ bông sẫm màu và bông bạc, báo cán bộ bảo vệ thực vật để xác minh sớm.',
            'medicine': ('Nếu đã xác nhận bệnh trên lúa và cần xử lý bằng thuốc, đối chiếu nhãn NewTec 300SC (hexaconazole 50 g/lít + tricyclazole 250 g/lít).\n'
                         'Liều thuốc: 0,75–1,0 lít/ha.\n'
                         'Lượng nước phun bằng bình: 400–600 lít/ha.\n'
                         'Cách dùng: hướng dẫn của nhà đăng ký ghi mức khoảng 5–10% bệnh ngoài ruộng. Nhờ cán bộ kỹ thuật xác định tỷ lệ bệnh thực tế và thời điểm phun.\n'
                         'Cách ly trước thu hoạch: 10 ngày.'),
            'cautions': LABEL_CAUTION,
            'prevention': 'Hỏi cán bộ địa phương về giống có khả năng kháng đạo ôn. Bón phân cân đối, tránh thừa đạm và tránh để ruộng thiếu nước kéo dài.\nKhi thăm lại ruộng, ghi số khóm có vết mới và kiểm tra cổ bông riêng lúc lúa vào giai đoạn trổ.',
            'stage_tillering': 'Kiểm tra phiến lá ở nhiều khóm và ghi lại vết thuôn mới xuất hiện.',
            'stage_heading': 'Quan sát thêm cổ bông và ghi nhận riêng những bông có phần cổ đổi màu. Ảnh lá riêng lẻ chưa đủ để đánh giá cổ bông.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*BLAST),
                    reference('Danh mục thuốc trừ bệnh mục 518: NewTec 300SC', 'Bộ Nông nghiệp và Môi trường', REGISTER_LIST + '#page=213', '2026-11-23'),
                    reference('Hướng dẫn NewTec 300SC trên lúa', 'Syngenta Việt Nam',
                              'https://www.syngenta.com.vn/newtecr-300sc', '2026-11-23'),
                    reference(*PLANT_PROTECTION_LAW)],
    },
    {
        'code': 'Healthy', 'title': 'Lá lúa khỏe theo ảnh quan sát',
        'content': {
            'symptoms': 'Mô hình xếp phần lá trong ảnh vào nhóm lá khỏe. Kết quả chỉ mô tả ảnh đã gửi. Ngay cả khi ảnh nhìn bình thường, các lá khác, bẹ và cổ bông vẫn cần được quan sát trực tiếp.',
            'field_check': 'Kiểm tra cả khóm, lá ở các tầng và các khóm xung quanh. Chụp lại khi có vết mới, vàng lá hoặc sinh trưởng bất thường.',
            'treatment': 'Tiếp tục thăm ruộng và quan sát thêm nếu xuất hiện dấu hiệu mới. Nếu cây sinh trưởng kém hoặc vàng bất thường dù ảnh lá nhìn bình thường, kiểm tra cả khóm, bẹ, cổ bông và điều kiện ruộng.',
            'medicine': 'Không có căn cứ phun thuốc từ một kết quả “lá lúa khỏe”.',
            'cautions': 'Ảnh lá nhìn bình thường không xác nhận toàn ruộng sạch bệnh. Nếu có dấu hiệu ở bộ phận khác, chụp riêng bộ phận đó và hỏi cán bộ kỹ thuật khi cần.',
            'prevention': 'Duy trì lịch quan sát ruộng và ghi nhận thay đổi theo thời gian để đối chiếu khi cần.',
        },
        'sources': [reference(*IRRI)],
    },
    {
        'code': 'Leaf_Smut', 'title': 'Đốm than trên lá lúa',
        'content': {
            'symptoms': 'Trên lá có thể thấy nhiều đốm đen nhỏ hơi nổi và nằm tách nhau. Tổn thương thường được quan sát vào cuối vụ.',
            'field_check': 'Chụp cả hai mặt lá dưới ánh sáng đều. Tìm các đốm đen hơi nổi, riêng rẽ trên phiến lá. Đây là nhóm dấu hiệu của bệnh do nấm Entyloma oryzae; cần mô tả riêng nếu thấy bất thường chủ yếu ở hạt hoặc bông.',
            'treatment': 'Kiểm tra hai mặt lá có đốm đen nhỏ và ghi khu vực có lá bị ảnh hưởng. Nếu nhiều khóm héo, vàng lan rộng hoặc bất thường tập trung ở hạt và bông, cần nhờ cán bộ kỹ thuật xác minh nguyên nhân khác.',
            'medicine': 'LSU AgCenter ghi nhận bệnh thường gây thiệt hại ít và không khuyến nghị phòng trừ riêng. Không phun chỉ vì ảnh được xếp vào nhóm đốm than lá.',
            'cautions': 'Tổn thương chủ yếu ở hạt hoặc bông cần được kiểm tra theo nhóm bệnh khác. Chụp riêng hạt hoặc bông để đối chiếu.',
            'prevention': 'Bón phân cân đối, tránh bón thừa đạm. Theo dõi các lá khác vào cuối vụ và ghi nhận nếu dấu hiệu lan rộng hoặc xuất hiện ở bộ phận khác.',
            'stage_ripening': 'Chụp cận cảnh các đốm còn tách biệt và ghi vị trí lá bị ảnh hưởng. Trao đổi với cán bộ kỹ thuật nếu vàng lá lan rộng.',
        },
        'sources': [reference(*LSU)],
    },
    {
        'code': 'Rice_Tungro', 'title': 'Bệnh Tungro trên lúa',
        'content': {
            'symptoms': 'Khóm lúa có thể thấp, ít nhánh và lá chuyển vàng đến vàng cam, thường thấy từ chóp lá.',
            'field_check': 'So sánh chiều cao và số nhánh của các khóm. Ghi thêm lá vàng cam, đốm màu gỉ sắt hoặc bông ngắn nếu thấy. Tài liệu kỹ thuật Việt Nam liệt kê Tungro và bệnh vàng lùn do virus lúa cỏ là hai mục riêng. Cần đối chiếu chuyên môn khi các dấu hiệu giống nhau.',
            'treatment': 'Đánh dấu chỗ có khóm lùn, ít nhánh, lá vàng cam. Chụp toàn khóm và ghi giai đoạn lúa, số khóm nghi bệnh và vị trí trên ruộng.\nBáo cán bộ bảo vệ thực vật để xác minh bệnh và kiểm tra rầy xanh. Nếu xác nhận ổ bệnh còn ít, trao đổi về việc loại bỏ khóm bệnh tại chỗ. Nếu dấu hiệu đã xuất hiện ở nhiều đám, cần đánh giá toàn ruộng trước khi xử lý.',
            'medicine': 'Hiện chưa có thuốc chữa cây lúa đã nhiễm virus Tungro. Thuốc trừ nấm không trị bệnh này.\nThuốc trừ rầy chỉ có mục đích quản lý côn trùng truyền bệnh. Phun theo kết quả ảnh hoặc phun định kỳ để trị Tungro thường không hiệu quả.\nNếu cán bộ địa phương xác nhận cần xử lý rầy xanh, đối chiếu sản phẩm có đăng ký đúng rầy xanh trên lúa, liều, cách dùng, bảo hộ và thời gian cách ly trên nhãn hiện hành.',
            'cautions': 'Chụp cả khóm và khu vực xung quanh. Một lá vàng chưa đủ để phân biệt Tungro với thiếu dinh dưỡng hoặc các bệnh virus khác.',
            'prevention': 'Trong vụ: thăm lại vị trí đã đánh dấu và các khóm xung quanh, nhất là giai đoạn đẻ nhánh. Ghi thêm khóm mới có dấu hiệu và báo cán bộ kỹ thuật nếu vùng nghi bệnh mở rộng.\nVụ sau: ưu tiên giống phù hợp có khả năng kháng theo khuyến cáo địa phương, gieo đồng loạt theo lịch vùng, dùng mạ từ nguồn không có dấu hiệu bệnh và xử lý lúa chét, gốc rạ sau thu hoạch theo hướng dẫn địa phương.',
            'stage_tillering': 'Quan sát đồng thời màu lá, số nhánh và chiều cao nhiều khóm. Ghi vị trí khóm sinh trưởng khác thường.',
            'stage_heading': 'Ghi lại nếu khóm trổ muộn hoặc bông khó thoát khỏi bẹ, kèm ảnh toàn khóm để đối chiếu.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*VIETNAM_TUNGRO), reference(*TUNGRO, checked_at='2026-11-23'),
                    reference(*TUNGRO_FIELD, checked_at='2026-11-23'), reference(*REGISTER)],
    },
    {
        'code': 'Sheath_Blight', 'title': 'Bệnh khô vằn',
        'content': {
            'symptoms': 'Vết thường thấy ở bẹ lá thấp, ban đầu bầu dục màu xám xanh; vết lớn có thể có tâm xám trắng và viền nâu sẫm.',
            'field_check': 'Quan sát phần bẹ thấp, nhất là gần mặt nước. Chụp bẹ và toàn khóm để xác định vết bắt đầu ở đâu và đã lên đến tầng nào. Tác nhân khô vằn là nấm Rhizoctonia solani.',
            'treatment': 'Tách nhẹ khóm để xem bẹ thấp sát mặt nước, rồi kiểm tra vết ở các tầng bẹ phía trên. Kiểm tra cả vùng tán rậm và các khóm bên cạnh.\nTránh bón thúc thêm đạm khi bệnh đang phát triển. Nếu vết đã lên tầng bẹ cao hoặc lan sang nhiều khóm, nhờ cán bộ kỹ thuật đánh giá trước khi dùng thuốc.',
            'medicine': ('Nếu đã xác nhận bệnh trên lúa và cần xử lý bằng thuốc, đối chiếu nhãn Anvil 5SC (hexaconazole 50 g/lít).\n'
                         'Liều thuốc: 1,0 lít/ha.\n'
                         'Lượng nước phun bằng bình: 320–600 lít/ha.\n'
                         'Cách dùng: chỉ xem xét phun khi đã xác nhận bệnh xuất hiện và có nhu cầu xử lý. Dùng lượng nước nêu trên cho phun bằng bình.\n'
                         'Cách ly trước thu hoạch: 14 ngày.'),
            'cautions': 'Vết ở bẹ trên ôm đòng hoặc tổn thương rời rạc có thể thuộc bệnh khác. Kiểm tra cả bẹ thấp và bẹ trên trước khi chọn thuốc. ' + LABEL_CAUTION,
            'prevention': 'Gieo với mật độ phù hợp, bón phân cân đối và quản lý cỏ bờ ruộng.\nTừ đẻ nhánh đến giai đoạn hạt sữa, thăm lại các điểm có bẹ bệnh. Ghi số khóm có vết mới và tầng bẹ cao nhất có vết để trao đổi với cán bộ kỹ thuật.',
            'stage_tillering': 'Kiểm tra các bẹ thấp ở nhiều khóm, nhất là vùng tán rậm. Ghi độ cao của vết so với gốc.',
            'stage_booting': 'So sánh vị trí vết theo các tầng bẹ với lần kiểm tra trước để có thông tin khi trao đổi với cán bộ kỹ thuật.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE), reference(*SHEATH_BLIGHT), reference(*SHEATH_FIELD, checked_at='2026-11-23'), reference(*REGISTER),
                    reference('Phụ lục II Thông tư 28/2026/TT-BNNMT, thuốc trừ bệnh mục 65',
                              'Bộ Nông nghiệp và Môi trường', REGISTER_UPDATE + '#page=13', '2026-11-23'),
                    reference('Hướng dẫn Anvil 5SC trên lúa', 'Syngenta Việt Nam',
                              'https://www.syngenta.com.vn/anvilr-5sc', '2026-11-23'),
                    reference(*PLANT_PROTECTION_LAW)],
    },
)
