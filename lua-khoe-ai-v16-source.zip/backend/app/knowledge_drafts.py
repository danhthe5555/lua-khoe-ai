"""Source-based review drafts for the current rice-leaf model labels."""

IRRI = ('Diagnosis of Common Diseases of Rice', 'International Rice Research Institute',
        'https://www.knowledgebank.irri.org/images/docs/diagnostic-of-common-diseases-of-rice.pdf')
PHILRICE = ('Field Guide on Major Disorders of the Rice Plant', 'Philippine Rice Research Institute',
            'https://www.philrice.gov.ph/wp-content/uploads/2023/02/Field-Guide_-Major-Disorders-of-the-rice-plant-Diseases-and-Nutritional-Deficiencies.pdf')
LSU = ('Leaf Smut of Rice', 'LSU AgCenter',
       'https://www.lsuagcenter.com/~/media/system/2/4/f/4/24f45ba528119f20218233f1be1b608f/pub3115leafsmutlowres.pdf')


def reference(title, publisher, url):
    return {'title': title, 'publisher': publisher, 'url': url, 'checked_at': '2026-11-21',
            'reuse_permission': 'Tóm lược bằng lời riêng và dẫn liên kết tài liệu gốc; không sao chép hình ảnh.'}


REFERENCE_DRAFTS = (
    {
        'code': 'Brown_Spot', 'title': 'Bệnh đốm nâu',
        'content': {
            'symptoms': 'Trên lá đã phát triển, vết thường tròn hoặc bầu dục, tâm nâu nhạt đến xám, viền nâu đỏ.',
            'field_check': 'Chụp gần một vết và chụp toàn lá. So sánh hình dạng vết ở nhiều lá trước khi phân biệt với đạo ôn hoặc các đốm khác.',
            'prevention': 'Khi lập kế hoạch vụ sau, ưu tiên giống và hạt giống có nguồn rõ ràng; trao đổi về cân đối dinh dưỡng và nước theo điều kiện ruộng.',
            'stage_seedling': 'Quan sát vết nâu trên cây mạ và ghi lại vùng cây sinh trưởng kém để cán bộ kỹ thuật đối chiếu thêm.',
            'stage_grain_filling': 'Ghi lại vết trên lá và dấu hiệu đổi màu ở vỏ hạt nếu quan sát được. Chụp riêng từng bộ phận để đối chiếu.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE)],
    },
    {
        'code': 'Blast', 'title': 'Bệnh đạo ôn',
        'content': {
            'symptoms': 'Vết trên lá thường thuôn, nhọn về hai đầu, tâm xám và viền sẫm. Biểu hiện có thể khác nhau theo giống và tuổi vết.',
            'field_check': 'Ghi lại vị trí tổn thương trên phiến lá, cổ lá hoặc cổ bông. Gửi cả ảnh cận cảnh và ảnh toàn khóm khi cần xác minh.',
            'prevention': 'Trao đổi với cán bộ địa phương về giống phù hợp và kế hoạch bón phân cân đối cho ruộng.',
            'stage_tillering': 'Kiểm tra phiến lá ở nhiều khóm và ghi lại vết thuôn mới xuất hiện.',
            'stage_heading': 'Quan sát thêm cổ bông và ghi nhận riêng những bông có phần cổ đổi màu. Ảnh lá riêng lẻ chưa đủ để đánh giá cổ bông.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE)],
    },
    {
        'code': 'Healthy', 'title': 'Lá lúa khỏe theo ảnh quan sát',
        'content': {
            'symptoms': 'Ảnh phù hợp với nhãn lá khỏe của mô hình. Dấu hiệu ở phần cây ngoài khung hình hoặc bệnh chưa có triệu chứng vẫn cần theo dõi.',
            'field_check': 'Kiểm tra cả khóm, lá ở các tầng và các khóm xung quanh. Chụp lại khi có vết mới, vàng lá hoặc sinh trưởng bất thường.',
            'prevention': 'Duy trì lịch quan sát ruộng và ghi nhận thay đổi theo thời gian để đối chiếu khi cần.',
        },
        'sources': [reference(*IRRI)],
    },
    {
        'code': 'Leaf_Smut', 'title': 'Đốm than trên lá lúa',
        'content': {
            'symptoms': 'Trên lá có thể thấy nhiều đốm đen nhỏ hơi nổi và nằm tách nhau. Tổn thương thường được quan sát vào cuối vụ.',
            'field_check': 'Chụp cả hai mặt lá dưới ánh sáng đều. Quan sát hình dạng và vị trí đốm để đối chiếu với các vết nâu hoặc đốm trên bộ phận khác.',
            'prevention': 'Ghi nhật ký vị trí phát hiện và rà soát cách bón đạm cùng cán bộ kỹ thuật nếu dấu hiệu lặp lại.',
            'stage_ripening': 'Chụp cận cảnh các đốm còn tách biệt và ghi vị trí lá bị ảnh hưởng. Trao đổi với cán bộ kỹ thuật nếu vàng lá lan rộng.',
        },
        'sources': [reference(*LSU)],
    },
    {
        'code': 'Rice_Tungro', 'title': 'Bệnh vàng lùn Tungro',
        'content': {
            'symptoms': 'Khóm lúa có thể thấp, ít nhánh và lá chuyển vàng đến vàng cam, thường thấy từ chóp lá.',
            'field_check': 'So sánh chiều cao và số nhánh giữa khóm nghi ngờ với khóm lân cận. Vàng lá có nhiều nguyên nhân; gửi ảnh toàn khóm để được xác minh.',
            'prevention': 'Hỏi cán bộ địa phương về lịch gieo đồng loạt và giống phù hợp trước khi chuẩn bị vụ tiếp theo.',
            'stage_tillering': 'Quan sát đồng thời màu lá, số nhánh và chiều cao nhiều khóm. Ghi vị trí khóm sinh trưởng khác thường.',
            'stage_heading': 'Ghi lại nếu khóm trổ muộn hoặc bông khó thoát khỏi bẹ, kèm ảnh toàn khóm để đối chiếu.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE)],
    },
    {
        'code': 'Sheath_Blight', 'title': 'Bệnh khô vằn',
        'content': {
            'symptoms': 'Vết thường thấy ở bẹ lá thấp, ban đầu bầu dục màu xám xanh; vết lớn có thể có tâm xám trắng và viền nâu sẫm.',
            'field_check': 'Quan sát bẹ ở phần gốc, kể cả gần mặt nước nếu ruộng có nước. Chụp bẹ và toàn khóm để ghi nhận vết ở các tầng lá.',
            'prevention': 'Trao đổi về mật độ gieo và dinh dưỡng cân đối khi lập kế hoạch vụ sau.',
            'stage_tillering': 'Kiểm tra các bẹ thấp ở nhiều khóm, nhất là vùng tán rậm. Ghi độ cao của vết so với gốc.',
            'stage_booting': 'So sánh vị trí vết theo các tầng bẹ với lần kiểm tra trước để có thông tin khi trao đổi với cán bộ kỹ thuật.',
        },
        'sources': [reference(*IRRI), reference(*PHILRICE)],
    },
)
