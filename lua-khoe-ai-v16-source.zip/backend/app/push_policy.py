import base64
import hashlib
import os
import re
from urllib.parse import urlsplit


def validate_subscription(endpoint,keys):
    if any(c.isspace() for c in endpoint) or '\\' in endpoint or set(keys)!={'auth','p256dh'}:
        raise ValueError('Đăng ký Push không hợp lệ.')
    url=urlsplit(endpoint)
    if len(endpoint)>2048 or url.scheme!='https' or url.hostname not in (
        'fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com') or url.port not in (None,443) or url.username or url.password or url.fragment:
        raise ValueError('Dịch vụ Push của trình duyệt này chưa được hỗ trợ hoặc địa chỉ không hợp lệ.')
    for key,length in (('p256dh',65),('auth',16)):
        value=keys.get(key,'')
        if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}={0,2}',value):raise ValueError('Khóa Push không hợp lệ.')
        raw=base64.urlsafe_b64decode(value+'='*((-len(value))%4))
        if len(raw)!=length or key=='p256dh' and raw[0]!=4:raise ValueError('Khóa Push không hợp lệ.')
    return hashlib.sha256(endpoint.encode()).hexdigest()


def configured():
    return os.getenv('PUSH_ENABLED')=='true' and all(os.getenv(key) for key in ('VAPID_PUBLIC_KEY','VAPID_PRIVATE_KEY','VAPID_SUBJECT'))


def reminder_digest(rows):
    if not rows:return None
    return hashlib.sha256('\n'.join(sorted(f'{id}:{updated}' for id,updated in rows)).encode()).hexdigest()
