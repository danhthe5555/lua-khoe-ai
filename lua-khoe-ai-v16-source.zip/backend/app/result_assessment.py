"""Read optional, versioned controls from the existing reviewed guide."""
import re

from .stage_guidance import STAGES

GENERAL_VERSION = 'result-workflow-v2'
GENERAL_TASKS = ('Đối chiếu lại lá ngoài ruộng', 'Ghi nhận vị trí lá có dấu hiệu', 'Kiểm tra lại hoặc hỏi cán bộ kỹ thuật khi chưa rõ')
SPREAD = {'unknown': 'Chưa rõ', 'few': 'Vài lá hoặc khóm', 'many': 'Nhiều khóm', 'widespread': 'Lan rộng'}


def lines(value):
    return [line.strip() for line in value.splitlines() if line.strip()]


def validate_fields(content):
    for key, maximum in [('verification_questions', 4), ('reviewed_tasks', 5), ('similar_diseases', 3)]:
        items = lines(content.get(key, ''))
        if len(items) > maximum or any(len(item) > 500 for item in items) or len(set(items)) != len(items):
            raise ValueError(f'{key}: tối đa {maximum} dòng khác nhau, mỗi dòng tối đa 500 ký tự.')
        if key == 'similar_diseases':
            relations = [item.partition('|') for item in items]
            if any(not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', code.strip()) or not detail.strip()
                   for code, _, detail in relations):
                raise ValueError('Bệnh dễ nhầm cần định dạng Mã nhãn | dấu hiệu phân biệt.')
            if len({code.strip() for code, _, _ in relations}) != len(relations):
                raise ValueError('Mỗi bệnh dễ nhầm chỉ được xuất hiện một lần.')


def snapshot(article, alternatives):
    content = article['content'] if article else {}
    tasks = lines(content.get('reviewed_tasks', ''))
    return {
        'version': article['id'] if article else GENERAL_VERSION,
        'guide': {k: article[k] for k in ('id', 'code', 'title', 'reviewed_at', 'sources')} if article else None,
        'questions': lines(content.get('verification_questions', '')),
        'task_version': article['id'] if tasks else GENERAL_VERSION,
        'tasks': tasks or list(GENERAL_TASKS),
        'alternatives': alternatives,
        'stage_text': {stage: content.get('stage_' + stage, '') for stage in STAGES},
        'spread_text': {spread: content.get('spread_' + spread, '') for spread in SPREAD if spread!='unknown'},
        'general_text': content.get('field_check', ''),
    }


def alignment(answers):
    known = [answer for answer in answers.values() if answer != 'unknown']
    if len(known) < 2:
        return 'insufficient'
    if all(answer == 'yes' for answer in known):
        return 'consistent'
    if all(answer == 'no' for answer in known):
        return 'conflicting'
    return 'partial'
