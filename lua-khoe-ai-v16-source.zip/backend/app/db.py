import os
import uuid
from datetime import datetime, timezone
from sqlalchemy import create_engine, String, ForeignKey, ForeignKeyConstraint, UniqueConstraint, JSON, Boolean, DateTime, CheckConstraint, Float, event, Index, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

def now():
    return datetime.now(timezone.utc)

class Base(DeclarativeBase):
    pass

class Record:
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)

class User(Record, Base):
    __tablename__ = 'users'
    __table_args__ = (CheckConstraint("role in ('farmer','admin')"),)
    email: Mapped[str] = mapped_column(String(254), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default='farmer')
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Session(Record, Base):
    __tablename__ = 'sessions'
    __table_args__ = (Index('uq_sessions_id_user_id','id','user_id',unique=True),)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    csrf: Mapped[str] = mapped_column(String(100))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class PushSubscription(Record, Base):
    __tablename__ = 'push_subscriptions'
    __table_args__ = (ForeignKeyConstraint(['session_id','user_id'],['sessions.id','sessions.user_id'],ondelete='CASCADE'),)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    session_id: Mapped[str] = mapped_column(String(36),index=True)
    endpoint_hash: Mapped[str] = mapped_column(String(64),unique=True)
    endpoint: Mapped[str] = mapped_column(String(2048))
    keys: Mapped[dict] = mapped_column(JSON)
    last_digest: Mapped[str | None] = mapped_column(String(64))
    last_attempt: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class Reset(Record, Base):
    __tablename__ = 'password_resets'
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class Plot(Record, Base):
    __tablename__ = 'plots'
    __table_args__ = (CheckConstraint('area_m2 > 0'), UniqueConstraint('id','user_id'))
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    name: Mapped[str] = mapped_column(String(120))
    area_m2: Mapped[float] = mapped_column(Float)
    notes: Mapped[str] = mapped_column(String(2000), default='')
    archived: Mapped[bool] = mapped_column(Boolean, default=False)

class Season(Record, Base):
    __tablename__ = 'crop_seasons'
    __table_args__ = (UniqueConstraint('id','user_id'), ForeignKeyConstraint(['plot_id','user_id'],['plots.id','plots.user_id']))
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    plot_id: Mapped[str] = mapped_column(ForeignKey('plots.id'), index=True)
    rice_variety: Mapped[str] = mapped_column(String(120))
    sowing_date: Mapped[str] = mapped_column(String(10))
    growing_stage: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(20), default='active')

class Diagnosis(Record, Base):
    __tablename__ = 'diagnoses'
    __table_args__ = (UniqueConstraint('id','user_id'), ForeignKeyConstraint(['season_id','user_id'],['crop_seasons.id','crop_seasons.user_id']))
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    season_id: Mapped[str | None] = mapped_column(ForeignKey('crop_seasons.id'), index=True)
    image_key: Mapped[str | None] = mapped_column(String(100))
    result: Mapped[dict] = mapped_column(JSON)
    request_key: Mapped[str] = mapped_column(String(150), unique=True)

class Activity(Record, Base):
    __tablename__ = 'activities'
    __table_args__ = (CheckConstraint("kind in ('observation','intervention','reminder')"),
                     ForeignKeyConstraint(['season_id','user_id'],['crop_seasons.id','crop_seasons.user_id']),
                     ForeignKeyConstraint(['diagnosis_id','user_id'],['diagnoses.id','diagnoses.user_id']))
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    season_id: Mapped[str | None] = mapped_column(ForeignKey('crop_seasons.id'), index=True)
    diagnosis_id: Mapped[str | None] = mapped_column(ForeignKey('diagnoses.id'), index=True)
    kind: Mapped[str] = mapped_column(String(20))
    title: Mapped[str] = mapped_column(String(200))
    notes: Mapped[str] = mapped_column(String(4000), default='')
    due_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed: Mapped[bool] = mapped_column(Boolean, default=False)

class Feedback(Record, Base):
    __tablename__ = 'prediction_feedback'
    __table_args__ = (ForeignKeyConstraint(['diagnosis_id','user_id'],['diagnoses.id','diagnoses.user_id']),)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    diagnosis_id: Mapped[str] = mapped_column(ForeignKey('diagnoses.id'), index=True)
    notes: Mapped[str] = mapped_column(String(2000))
    consented_to_review: Mapped[bool] = mapped_column(Boolean)

class Knowledge(Record, Base):
    __tablename__ = 'knowledge_revisions'
    __table_args__ = (CheckConstraint("status in ('draft','reviewed','published','archived')"),
                     Index('one_published_revision_per_code','code',unique=True,
                           postgresql_where=text("status = 'published'"),sqlite_where=text("status = 'published'")),)
    code: Mapped[str] = mapped_column(String(100), index=True)
    title: Mapped[str] = mapped_column(String(200))
    content: Mapped[dict] = mapped_column(JSON)
    sources: Mapped[list] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20), default='draft')
    created_by: Mapped[str] = mapped_column(ForeignKey('users.id'))
    reviewed_by: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class ProductLabel(Record, Base):
    __tablename__ = 'product_labels'
    __table_args__ = (CheckConstraint("status in ('draft','published','archived')"),
                     Index('uq_product_label_published','registration',unique=True,postgresql_where=text("status='published'"),sqlite_where=text("status='published'")))
    registration: Mapped[str] = mapped_column(String(120),index=True)
    name: Mapped[str] = mapped_column(String(200))
    crop: Mapped[str] = mapped_column(String(100))
    target: Mapped[str] = mapped_column(String(500))
    ingredients: Mapped[str] = mapped_column(String(1000))
    label_text: Mapped[str] = mapped_column(String(15000))
    precautions: Mapped[str] = mapped_column(String(8000))
    valid_until: Mapped[str] = mapped_column(String(10))
    source: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20),default='draft')
    created_by: Mapped[str] = mapped_column(ForeignKey('users.id'))
    reviewed_by: Mapped[str | None] = mapped_column(ForeignKey('users.id'))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

class Audit(Record, Base):
    __tablename__ = 'audit_logs'
    admin_id: Mapped[str] = mapped_column(ForeignKey('users.id'), index=True)
    action: Mapped[str] = mapped_column(String(80))
    target_id: Mapped[str] = mapped_column(String(36))

url = os.getenv('DATABASE_URL', 'sqlite:///./development.db')
engine = create_engine(url, **({'connect_args': {'check_same_thread': False}} if url.startswith('sqlite') else {}))
if url.startswith('sqlite'):
    @event.listens_for(engine, 'connect')
    def fk(connection, _):
        connection.execute('PRAGMA foreign_keys=ON')
SessionLocal = sessionmaker(engine, expire_on_commit=False)

def get_db():
    with SessionLocal() as db:
        yield db

def serialize(record):
    return {c.name: getattr(record, c.name) for c in record.__table__.columns}
