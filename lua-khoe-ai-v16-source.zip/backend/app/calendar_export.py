"""Private, user-requested calendar export. Does not send Web Push."""
from datetime import datetime, timezone


def escape(value):
    return str(value).replace('\\', '\\\\').replace('\r\n', '\n').replace('\r', '\n').replace('\n', '\\n').replace(';', '\\;').replace(',', '\\,')


def fold(line):
    parts, current, size = [], '', 0
    for character in line:
        length = len(character.encode('utf-8'))
        if size + length > 75:
            parts.append(current)
            current, size = ' ', 1
        current += character
        size += length
    return '\r\n'.join(parts + [current])


def calendar_event(event, created_at=None):
    due = event['due_at']
    # SQLite test fixtures may return naive UTC; production stores aware datetimes.
    if due.tzinfo is None:
        due = due.replace(tzinfo=timezone.utc)
    due = due.astimezone(timezone.utc)
    stamp = (created_at or datetime.now(timezone.utc)).astimezone(timezone.utc)
    fmt = '%Y%m%dT%H%M%SZ'
    lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Lua Khoe AI//Local reminders//VI',
             'CALSCALE:GREGORIAN', 'BEGIN:VEVENT', 'UID:' + escape(event['id']) + '@lua-khoe.local',
             'DTSTAMP:' + stamp.strftime(fmt), 'DTSTART:' + due.strftime(fmt),
             'DURATION:PT15M',
             'SUMMARY:' + escape(event['title']), 'DESCRIPTION:' + escape(event.get('notes', '')),
             'CLASS:PRIVATE', 'BEGIN:VALARM', 'TRIGGER:-PT15M', 'ACTION:DISPLAY',
             'DESCRIPTION:' + escape(event['title']), 'END:VALARM', 'END:VEVENT', 'END:VCALENDAR']
    return ('\r\n'.join(fold(line) for line in lines) + '\r\n').encode('utf-8')
