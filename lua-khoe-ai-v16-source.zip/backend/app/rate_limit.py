"""Bounded, thread-safe sliding window for the single-worker deployment."""
import time
from collections import OrderedDict,deque
from threading import Lock

class RateLimiter:
    def __init__(self,limit=15,window=60,max_entries=4096,clock=time.monotonic):
        self.limit=limit;self.window=window;self.max_entries=max_entries;self.clock=clock
        self.entries=OrderedDict();self.lock=Lock()

    def clear(self):
        with self.lock:self.entries.clear()

    def allow(self,key):
        with self.lock:
            cutoff=self.clock()-self.window
            # Entries are ordered by last accepted event, never by denied attempts.
            while self.entries:
                oldest=next(iter(self.entries))
                if self.entries[oldest][-1]>cutoff:break
                self.entries.popitem(last=False)
            bucket=self.entries.get(key)
            if bucket is None:
                if len(self.entries)>=self.max_entries:return False
                bucket=deque();self.entries[key]=bucket
            while bucket and bucket[0]<=cutoff:bucket.popleft()
            if len(bucket)>=self.limit:return False
            bucket.append(cutoff+self.window);self.entries.move_to_end(key)
            return True
