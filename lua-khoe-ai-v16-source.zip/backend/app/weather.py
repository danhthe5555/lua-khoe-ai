"""Opt-in weather lookup; never invents disease-risk thresholds."""
import http.client
import json
import math
import os
from datetime import datetime, timezone
from urllib.parse import urlencode

class WeatherUnavailable(RuntimeError):pass

UNITS={'temperature_2m':'°C','relative_humidity_2m':'%','precipitation':'mm','wind_speed_10m':'km/h'}

def number(value,low,high):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not low<=value<=high:
        raise ValueError('Invalid weather value')
    return value

def normalize(payload,latitude,longitude,now=None):
    now=now or datetime.now(timezone.utc)
    current=payload['current'];units=payload['current_units']
    if any(units.get(key)!=unit for key,unit in UNITS.items()):raise ValueError('Unexpected units')
    stamp=number(current['time'],0,253402300799)
    age=now.timestamp()-stamp
    if age>3600 or age < -900:raise ValueError('Stale or future weather data')
    values={key:number(current[key],*bounds) for key,bounds in {
        'temperature_2m':(-100,70),'relative_humidity_2m':(0,100),
        'precipitation':(0,2000),'wind_speed_10m':(0,500)}.items()}
    interval=number(current['interval'],1,3600)
    grid_lat=number(payload['latitude'],-90,90);grid_lon=number(payload['longitude'],-180,180)
    return {'source':'Open-Meteo','source_url':'https://open-meteo.com/',
            'requested_location':{'latitude':latitude,'longitude':longitude},
            'model_grid':{'latitude':grid_lat,'longitude':grid_lon},
            'valid_at':datetime.fromtimestamp(stamp,timezone.utc).isoformat(),
            'retrieved_at':now.isoformat(),'interval_seconds':interval,'units':UNITS,'current':values,
            'risk_status':'rules_unavailable',
            'notice':'Dữ liệu thời tiết theo mô hình, không phải đo tại ruộng. Chưa có quy tắc chuyên môn đã duyệt để kết luận nguy cơ bệnh.'}

def fetch(latitude,longitude):
    number(latitude,-90,90);number(longitude,-180,180)
    if os.getenv('WEATHER_PROVIDER')!='open-meteo':
        raise WeatherUnavailable('Chưa bật nhà cung cấp thời tiết. Các chức năng khác vẫn dùng được trên máy.')
    connection=http.client.HTTPSConnection('api.open-meteo.com',timeout=12)
    params=urlencode({'latitude':latitude,'longitude':longitude,'current':','.join(UNITS),
                      'temperature_unit':'celsius','wind_speed_unit':'kmh','precipitation_unit':'mm',
                      'timezone':'UTC','timeformat':'unixtime','forecast_days':1})
    try:
        connection.request('GET','/v1/forecast?'+params)
        response=connection.getresponse();raw=response.read(65537)
        if response.status!=200 or len(raw)>65536:raise ValueError('Provider response failed')
        return normalize(json.loads(raw),latitude,longitude)
    except (OSError,ValueError,KeyError,TypeError,http.client.HTTPException):
        raise WeatherUnavailable('Không lấy được thời tiết mới hợp lệ. Kiểm tra kết nối và thử lại; hệ thống không dùng số liệu giả.') from None
    finally:connection.close()
