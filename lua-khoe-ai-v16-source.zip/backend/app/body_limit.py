"""Limit actual streamed request bytes, including uploads without Content-Length."""
import json

class BodyTooLarge(Exception):
    pass

class BodyLimitMiddleware:
    def __init__(self,app,max_bytes=11*1024*1024):
        self.app=app;self.max_bytes=max_bytes

    async def __call__(self,scope,receive,send):
        if scope['type']!='http':return await self.app(scope,receive,send)
        size=0;started=False
        async def limited_receive():
            nonlocal size
            message=await receive()
            if message['type']=='http.request':
                size+=len(message.get('body',b''))
                if size>self.max_bytes:raise BodyTooLarge()
            return message
        async def tracked_send(message):
            nonlocal started
            if message['type']=='http.response.start':started=True
            await send(message)
        try:await self.app(scope,limited_receive,tracked_send)
        except BodyTooLarge:
            if started:raise
            body=json.dumps({'error':{'code':'413','message':'Yêu cầu vượt giới hạn tải lên. Ảnh tối đa 10 MB.'}},ensure_ascii=False).encode('utf-8')
            await send({'type':'http.response.start','status':413,'headers':[(b'content-type',b'application/json; charset=utf-8'),(b'cache-control',b'no-store, private'),(b'content-length',str(len(body)).encode())]})
            await send({'type':'http.response.body','body':body})
