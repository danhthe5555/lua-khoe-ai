"""Local extractive lookup; never generates agricultural advice."""
import re
import unicodedata


def tokens(value):
    text = unicodedata.normalize('NFD', value.lower().replace('đ', 'd'))
    text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
    return set(re.findall(r'[a-z0-9]+', text))


def search_articles(query, articles, limit=5):
    wanted = tokens(query)
    if not wanted:
        return []
    ranked = []
    for article in articles:
        title_tokens = tokens(article['title'] + ' ' + article['code'])
        sections = [(key, value) for key, value in article['content'].items() if isinstance(value, str) and value.strip()]
        matches = [(len(wanted & tokens(value)), key, value) for key, value in sections]
        matches.sort(key=lambda item: (-item[0], item[1]))
        content_tokens = set().union(*(tokens(value) for _, value in sections))
        overlap = wanted & (title_tokens | content_tokens)
        if not overlap:
            continue
        score = len(overlap) + 2 * len(wanted & title_tokens)
        # Whole sections preserve negations and conditions. No generated summary.
        extracts = [{'section': key, 'text': value} for count, key, value in matches if count][:2]
        ranked.append((score, {key: article[key] for key in ('id', 'code', 'title', 'reviewed_at', 'sources')} | {'extracts': extracts}))
    ranked.sort(key=lambda item: (-item[0], item[1]['code'], item[1]['id']))
    return [item for _, item in ranked[:limit]]
