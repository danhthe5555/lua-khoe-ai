import os
from fastapi import APIRouter,Depends,HTTPException,Request
from pydantic import BaseModel,ConfigDict,Field
from sqlalchemy import select,delete,func
from sqlalchemy.exc import IntegrityError
from .db import PushSubscription,Activity,get_db,User
from .security import farmer
from .push_policy import validate_subscription,configured
from .db import now

router=APIRouter(prefix='/api/v1/push')
class Subscribe(BaseModel):
    model_config=ConfigDict(extra='forbid')
    endpoint:str=Field(max_length=2048)
    keys:dict[str,str]=Field(max_length=2)

@router.get('/config')
def config(user=Depends(farmer)):
    return {'enabled':bool(configured()),'public_key':os.getenv('VAPID_PUBLIC_KEY') if configured() else None}

@router.get('/subscriptions')
def subscriptions(request:Request,user=Depends(farmer),db=Depends(get_db)):
    return [{'id':r.id,'created_at':r.created_at,'current_session':r.session_id==request.state.session.id}
            for r in db.scalars(select(PushSubscription).where(PushSubscription.user_id==user.id))]

@router.post('/subscriptions',status_code=201)
def subscribe(data:Subscribe,request:Request,user=Depends(farmer),db=Depends(get_db)):
    if not configured():raise HTTPException(503,'Chưa cấu hình Web Push.')
    try:key=validate_subscription(data.endpoint,data.keys)
    except ValueError as error:raise HTTPException(422,str(error))
    # Serialize registrations for a user to enforce the device limit.
    db.scalar(select(User).where(User.id==user.id).with_for_update())
    old=db.scalar(select(PushSubscription).where(PushSubscription.endpoint_hash==key).with_for_update())
    if old and (old.user_id!=user.id or old.session_id!=request.state.session.id):
        raise HTTPException(409,'Thiết bị còn đăng ký phiên cũ. Tắt rồi bật lại thông báo.')
    if old:return {'id':old.id}
    count=db.scalar(select(func.count()).select_from(PushSubscription).where(PushSubscription.user_id==user.id))
    if count>=10:raise HTTPException(422,'Đã đủ 10 đăng ký. Thu hồi thiết bị cũ trước.')
    record=PushSubscription(user_id=user.id,session_id=request.state.session.id,endpoint_hash=key,endpoint=data.endpoint,keys=data.keys)
    db.add(record)
    try:db.commit()
    except IntegrityError:db.rollback();raise HTTPException(409,'Đăng ký đã thay đổi. Hãy thử lại.')
    return {'id':record.id}

@router.delete('/subscriptions/{id}')
def unsubscribe(id:str,user=Depends(farmer),db=Depends(get_db)):
    record=db.scalar(select(PushSubscription).where(PushSubscription.id==id,PushSubscription.user_id==user.id).with_for_update())
    if not record:raise HTTPException(404,'Không tìm thấy đăng ký.')
    db.delete(record);db.commit();return {'message':'Đã thu hồi đăng ký.'}

@router.get('/verify/{id}')
def verify_push(id:str,request:Request,user=Depends(farmer),db=Depends(get_db)):
    record=db.get(PushSubscription,id)
    if not configured() or not record or record.user_id!=user.id or record.session_id!=request.state.session.id:
        return {'show':False}
    due=db.scalar(select(Activity.id).where(Activity.user_id==user.id,Activity.kind=='reminder',Activity.completed==False,Activity.due_at<=now()).limit(1))
    return {'show':bool(due)}
