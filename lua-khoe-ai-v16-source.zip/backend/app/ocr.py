"""Local Tesseract adapter. Text extraction does not validate a pesticide."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
from .ml import PredictionService

_slot = threading.BoundedSemaphore(1)


class OCRUnavailable(RuntimeError):
    pass


class OCRBusy(RuntimeError):
    pass


def executable():
    configured = os.getenv('TESSERACT_CMD')
    path = Path(configured) if configured else None
    if path:
        return str(path) if path.is_absolute() and path.is_file() else None
    return shutil.which('tesseract')


def health():
    binary = executable()
    if not binary:
        return {'ready': False, 'message': 'Chưa cài bộ đọc chữ Tesseract trên máy chủ cục bộ.'}
    try:
        result = subprocess.run([binary, '--list-langs'], capture_output=True, timeout=5,
                                encoding='utf-8', errors='replace', creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        available = set(result.stdout.splitlines())
        if result.returncode or not {'vie','eng'}.issubset(available):
            return {'ready': False, 'message': 'Cần dữ liệu ngôn ngữ tiếng Việt và tiếng Anh cho OCR.'}
    except (OSError, subprocess.TimeoutExpired):
        return {'ready': False, 'message': 'Chưa khởi động được bộ đọc chữ cục bộ.'}
    return {'ready': True, 'message': 'Đọc chữ cục bộ; kết quả cần bạn kiểm tra lại.'}


def recognize(data):
    if not _slot.acquire(blocking=False):
        raise OCRBusy('Đang xử lý một ảnh khác. Vui lòng thử lại sau.')
    try:
        state = health()
        if not state['ready']:
            raise OCRUnavailable(state['message'])
        image = PredictionService().validate_image(data)
        # No original filename, EXIF, persistent upload, shell, or network request.
        with tempfile.TemporaryDirectory(prefix='lua-ocr-',dir=os.getenv('OCR_TEMP_DIR') or None) as directory:
            root = Path(directory)
            image.save(root / 'input.png', format='PNG')
            try:
                result = subprocess.run([executable(), str(root / 'input.png'), str(root / 'output'),
                                         '-l', 'vie+eng', '--psm', '3'],
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30,
                                        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            except subprocess.TimeoutExpired:
                raise ValueError('Đọc chữ quá thời gian. Hãy chụp rõ vùng nhãn nhỏ hơn.') from None
            except OSError:
                raise OCRUnavailable('Không chạy được bộ đọc chữ cục bộ.') from None
            output = root / 'output.txt'
            if result.returncode or not output.is_file():
                raise ValueError('Chưa đọc được chữ. Hãy chụp lại nhãn rõ hơn.')
            with output.open('rb') as stream:
                raw = stream.read(65537)
            if len(raw) > 65536:
                raise ValueError('Nhãn quá nhiều chữ; hãy chụp riêng từng phần.')
            text = raw.decode('utf-8', errors='replace').strip()
            if len(text)>12000:
                raise ValueError('Nhãn quá nhiều chữ; hãy chụp riêng từng phần.')
            return {'text': text, 'status': 'needs_review' if text else 'no_text',
                    'engine': 'tesseract-local', 'drug_verification': 'unavailable',
                    'message': 'Chữ đọc được có thể sai tên, số và đơn vị. Chưa xác minh đăng ký, đối tượng dùng hoặc liều lượng thuốc.'}
    finally:
        _slot.release()
