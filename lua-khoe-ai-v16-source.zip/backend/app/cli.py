import getpass
from sqlalchemy import select
from .db import SessionLocal, User
from .security import hasher

def main():
    email=input('Email quản trị: ').strip().lower()
    name=input('Tên người có thẩm quyền: ').strip()
    password=getpass.getpass('Mật khẩu (tối thiểu 12 ký tự): ')
    if len(password)<12 or '@' not in email or not name: raise SystemExit('Thông tin không hợp lệ.')
    if password!=getpass.getpass('Nhập lại mật khẩu: '): raise SystemExit('Mật khẩu không khớp.')
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.email==email)): raise SystemExit('Email đã tồn tại; không tự nâng quyền.')
        db.add(User(email=email,name=name,password_hash=hasher.hash(password),role='admin')); db.commit()
    print('Đã tạo tài khoản quản trị. Không có mật khẩu mặc định.')

if __name__=='__main__': main()
