import io
import os
from datetime import datetime,timezone
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.enums import TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

def create_pdf(plot,seasons,diagnoses,activities,filters=None):
    paths=[os.getenv('PDF_FONT',''),'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','C:/Windows/Fonts/arial.ttf']
    font=next((p for p in paths if p and Path(p).is_file()),None)
    if not font: raise RuntimeError('Configure PDF_FONT with a Vietnamese-capable TTF')
    pdfmetrics.registerFont(TTFont('Vietnamese',font))
    styles=getSampleStyleSheet()
    for style in styles.byName.values(): style.fontName='Vietnamese';style.leading=17
    styles['Title'].textColor=colors.HexColor('#236B45')
    out=io.BytesIO();doc=SimpleDocTemplate(out,title='Báo cáo ruộng lúa',author='Lúa Khỏe AI')
    items=[]
    def add(text,style='BodyText'):
        items.extend([Paragraph(escape(str(text)),styles[style]),Spacer(1,10)])
    add('LÚA KHỎE AI','Title');add('BÁO CÁO THEO DÕI RUỘNG','Heading1')
    add(plot['name'],'Heading2');add(f"Diện tích: {plot['area_m2']} m²")
    add(f"Xuất lúc: {datetime.now(timezone.utc).isoformat()}")
    if filters:
        add(f"Bộ lọc: từ ngày {filters['from_date']} đến {filters['to_date']} (UTC); nhãn {filters['label']}; mùa vụ {filters['season']}.")
        add(f"Số lượt ảnh trong bộ lọc: {len(diagnoses)}. Báo cáo thống kê này không gồm nhật ký chăm sóc.")
    add('Kết quả AI chỉ là dự đoán. Báo cáo không khẳng định mức độ bệnh, khỏi bệnh hoặc hiệu quả thuốc.')
    for s in seasons: add(f"Vụ: {s['rice_variety']} | Gieo: {s['sowing_date']} | Giai đoạn ghi nhận: {s['growing_stage']}")
    add('Lịch sử kiểm tra','Heading2')
    if not diagnoses: add('Chưa có kết quả được lưu vào các vụ của ruộng này.')
    for d in diagnoses:
        r=d['result'];add(f"{d['created_at']} — AI dự đoán: {r['display_label_vi']}; điểm {r['raw_score']*100:.1f}%")
        add(f"Model SHA-256: {r['model_version']}");add(f"Phiên bản tri thức: {r.get('knowledge_version') or 'Chưa có nội dung đã duyệt'}")
        if r.get('knowledge_sources'):
            add(f"Tri thức được duyệt lúc: {r.get('knowledge_reviewed_at') or 'Không có thời gian lưu'}")
            for source in r['knowledge_sources']:
                add(f"Nguồn: {source.get('title','')} | {source.get('publisher','')} | {source.get('url','')} | Rà soát: {source.get('checked_at','')}")
        else: add('Không có bản chụp nguồn tri thức trong lần nhận diện này.')
    if filters is None:
        add('Nhật ký do người dùng ghi nhận','Heading2')
        for a in activities: add(f"{a['due_at']} | {a['title']} | {a['notes']}")
    def footer(canvas,doc):
        canvas.setFont('Vietnamese',9);canvas.drawRightString(550,25,f'Trang {doc.page}')
    doc.build(items,onFirstPage=footer,onLaterPages=footer)
    return out.getvalue()
