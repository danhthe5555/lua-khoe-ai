from datetime import date

PUBLIC_FIELDS=('id','registration','name','crop','target','ingredients','label_text','precautions','valid_until','reviewed_at')

def validate_review(record,today=None):
    today=today or date.today()
    if date.fromisoformat(record['valid_until'])<today:raise ValueError('Bản ghi đã quá hạn rà soát.')
    source=record['source']
    checked=date.fromisoformat(source['checked_at'])
    if checked>today:raise ValueError('Ngày kiểm tra nguồn không thể ở tương lai.')
    if not all(str(record.get(key,'')).strip() for key in ('registration','name','crop','target','ingredients','label_text','precautions')):
        raise ValueError('Cần đủ nhãn, cây trồng, đối tượng và cảnh báo trước khi xuất bản.')
    if not all(source.get(key) for key in ('title','url','publisher','checked_at','reuse_permission')):
        raise ValueError('Nguồn và quyền sử dụng chưa đầy đủ.')

def public_label(record):
    return {key:record[key] for key in PUBLIC_FIELDS} | {'source':{
        key:record['source'].get(key) for key in ('title','url','publisher','checked_at')}}
