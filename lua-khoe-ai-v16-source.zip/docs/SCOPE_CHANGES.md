# Phạm vi

## Nghiệm thu chính ngày 21/11/2026

- Luồng chính gồm đăng nhập, chụp hoặc chọn ảnh, kiểm tra ảnh, nhận diện, tự lưu kết quả và ảnh, đối chiếu cẩm nang đã duyệt, ghi việc đã làm và theo dõi các lần kiểm tra. Người dùng có thể gắn kết quả với ruộng/vụ, mở lại lịch sử, xem thống kê cơ bản và xuất phiếu kết quả. Quản trị viên duyệt nội dung, xem phản hồi và quản lý tài khoản theo quyền đã cấp.
- Tính chi phí, OCR nhãn thuốc, danh mục nhãn thuốc (kể cả màn hình quản trị), hỏi đáp bằng mô hình, trang thời tiết và Web Push nằm ngoài phạm vi nghiệm thu chính. Các màn hình và đường dẫn cũ của những công cụ này được rút khỏi bản web. Mã backend và dữ liệu của các tích hợp được giữ lại để tránh mất dữ liệu và hỗ trợ phiên bản mở rộng.
- Tra cứu tài liệu theo từ khóa, hướng dẫn theo giai đoạn và nhắc việc trong web vẫn có thể dùng. Cơ chế dọn đăng ký thông báo cũ khi đăng xuất được giữ để chuyển tiếp từ phiên bản trước.
- Yêu cầu lịch sử liên quan đến các công cụ tạm hoãn trong ma trận V1.6 được đối chiếu theo quyết định phạm vi này. Kết quả hồi quy kỹ thuật của các tích hợp bổ sung không phải tiêu chí nghiệm thu chính.

## Cập nhật 20/11/2026

Mục tiêu bàn giao là hệ thống Lúa Khỏe AI V1.6 đầy đủ trên GitHub và Cloudflare, dùng được trên điện thoại và máy tính. Giữ nguyên các yêu cầu C/E và theo dõi từng yêu cầu D theo ma trận V1.6. EfficientNet-B0 là mô hình của chức năng nhận diện.

Bản Pages hiện có xác nhận luồng chọn ảnh và chạy suy luận ONNX. Cổng production của toàn hệ thống còn mở cho đến khi kiểm chứng API, phân quyền ba vai trò, dữ liệu riêng tư, email, sao lưu và các hành trình người dùng trên hạ tầng thật.

Không thay đổi hoặc loại bỏ mã yêu cầu. C/E/D giữ theo V1.6. Chỉ triển khai local; production chờ hạ tầng. SQLite chỉ là lựa chọn phát triển/kiểm thử, không thay thế gate PostgreSQL và Docker.

Ngày 12/11/2026: chủ dự án yêu cầu hoàn thiện offline trước, tự đưa lên web sau. Production được hoãn theo thứ tự triển khai; không xóa yêu cầu chức năng. Tra cứu tài liệu bằng từ khóa là chức năng local bổ sung, không thay nghiệm thu RAG/LLM. Các chức năng phụ thuộc dữ liệu/model/dịch vụ vẫn được ghi rõ chưa hoàn thành.
