# Tích hợp giao diện Lúa Khỏe AI v2.0

Giao diện React dùng chung cho desktop và điện thoại. Các liên kết cũ dưới `/ket-qua/:id` vẫn mở được cùng bản ghi. Lịch sử mới dùng `/results/:id`, phần Theo dõi ở `/theo-doi` và phiếu có thể in hoặc lưu PDF từ `/results/:id/report`.

| Việc | API và dữ liệu |
| --- | --- |
| Nhận diện, kiểm tra ảnh, lưu ảnh | `POST /api/v1/diagnoses/predict` xác minh định dạng thực, kích thước và độ sáng sơ bộ. Ảnh mới lưu đúng byte với MIME được xác minh. Ảnh JPEG cũ tiếp tục đọc được qua URL theo mã bản ghi. |
| Lịch sử và theo dõi | `GET /api/v1/diagnoses` và `GET /api/v1/tracking` dựa trên chủ sở hữu trong phiên. Các ảnh liên kết qua `GET /api/v1/diagnoses/{id}/image` và không được cache công khai. |
| Câu trả lời, bối cảnh và checklist | `GET/PATCH /api/v1/diagnoses/{id}/assessment`. Mỗi lần cập nhật kiểm tra chủ sở hữu và phiên bản. Câu trả lời, dấu tick, thời điểm và phiên bản nằm trong trường JSON `assessment` của bản ghi. |
| Biên tập nội dung | Thêm câu hỏi, checklist chuyên môn và bệnh dễ nhầm trong bản nháp cẩm nang. Mỗi bệnh dễ nhầm dùng một dòng dạng `Mã nhãn \| dấu hiệu phân biệt`. Các mục chuyên môn chỉ hiện khi bản cẩm nang đã duyệt và xuất bản. |
| Phiếu tham khảo | Bản in dùng ảnh, dữ liệu nhận diện, câu trả lời, bối cảnh và checklist của cùng lượt kiểm tra. Việc lưu PDF hoặc gửi tệp do người dùng thao tác trên thiết bị. |

## Vận hành

Không cần biến môi trường mới. Dùng các thiết lập phiên, mô hình EfficientNet-B0, PostgreSQL và ổ lưu ảnh riêng đang có. Trước khi triển khai, chạy workflow `full-stack.yml` trên nhánh phát hành. Sao lưu PostgreSQL rồi chạy Alembic từ `0004` lên `0005` trước khi khởi động API mới. Kiểm tra `/health/ready`, quyền ảnh cá nhân và mở lại kết quả có ảnh. Nếu cần quay lại, phục hồi nhãn ảnh Docker của API/web trước đó. Migration chỉ bổ sung cột, nên giữ cột mới để bảo toàn dữ liệu nếu đã có lượt dùng v2.

## Giới hạn nghiệm thu

- Cơ chế kiểm tra ảnh dùng chất lượng kỹ thuật và phát hiện tệp trùng theo SHA-256. Đánh giá ảnh không phải lá lúa và hiệu chỉnh điểm mô hình cần bộ mẫu độc lập và ngưỡng được xác minh.
- Các câu hỏi, cặp bệnh dễ nhầm và hướng dẫn chuyên môn bổ sung cần được người có thẩm quyền duyệt từng phiên bản.
- Quy trình nội dung dùng quyền quản trị và nhật ký hiện có. Hai vai trò biên tập và thẩm định độc lập chưa được cấp riêng.
