# Độ phủ tri thức

## Chuẩn hóa hướng dẫn nhận biết và xử lý

Sáu bản tham khảo dùng cùng cấu trúc: dấu hiệu, đối chiếu ngoài ruộng, biện pháp xử lý trước, thuốc bảo vệ thực vật, lưu ý quan trọng và phòng ngừa. Hướng dẫn theo giai đoạn được giữ cùng nguồn của bài. Các mục xử lý và thuốc chỉ xuất hiện trong hướng dẫn người dùng sau khi phiên bản được duyệt và công khai.

- **Đạo ôn:** kiểm tra riêng phiến lá và cổ bông, tránh bón thúc đạm khi bệnh đang phát triển. Phụ lục II của Thông tư 28/2026/TT-BNNMT, mục 113 nhóm thuốc trừ bệnh, ghi Beyond 40SC (tricyclazole) cho đạo ôn/lúa.
- **Khô vằn:** tìm vết từ bẹ thấp, theo dõi vết lan lên các tầng bẹ, tránh bón thừa đạm và gieo quá dày. Cùng phụ lục, mục 65 nhóm thuốc trừ bệnh, ghi Anvil 5 SC (hexaconazole) cho khô vằn/lúa.
- **Đốm nâu:** ưu tiên rà soát dinh dưỡng và nước, dùng giống và hạt giống phù hợp. Bản tham khảo chưa chỉ định tên thương phẩm.
- **Tungro:** bệnh do virus, rầy xanh truyền bệnh. Cây đã nhiễm không có thuốc chữa. Ưu tiên xác minh ổ bệnh, quản lý lây lan và gieo đồng loạt theo lịch địa phương.
- **Đốm than lá và lá khỏe theo ảnh:** hướng dẫn theo dõi thực tế. LSU AgCenter không khuyến nghị phòng trừ riêng với đốm than lá thông thường. Nhãn lá khỏe không đủ căn cứ để phun thuốc.

Các ví dụ thuốc dùng để đối chiếu đăng ký. Khi sử dụng phải theo hướng dẫn trên nhãn của đúng sản phẩm, gồm liều, cách dùng, bảo hộ và thời gian cách ly. Không nhập liều hay khuyến cáo phun tự động từ điểm dự đoán. Nguồn pháp lý: [Thông tư 75/2025/TT-BNNMT](https://vanban.chinhphu.vn/?docid=216337&pageid=27160), [Phụ lục Thông tư 28/2026/TT-BNNMT](https://datafiles.chinhphu.vn/cpp/files/vbpq/2026/7/28-bnnmt-kem.pdf).

Nút **Tạo bản cập nhật cẩm nang** sao chép các mục tham khảo mới vào bản nháp, kể cả khi mã bệnh đã có bài. Bản trùng nội dung và nguồn được bỏ qua. Quản trị viên có thẩm quyền có thể rà soát từng bản nháp, duyệt rồi xuất bản bằng luồng hiện có.

## Cẩm nang đang công khai trên Azure

Ngày 21/11/2026, theo yêu cầu của chủ dự án, sáu bài tham khảo đã được đối chiếu nguồn và xuất bản vào cơ sở dữ liệu đang chạy. Danh sách công khai đã trả đủ năm bài bệnh và một bài về nhãn lá khỏe. Đã kiểm tra cả sáu thẻ trên giao diện và nội dung hướng dẫn đẻ nhánh của Tungro qua API. [Mở cẩm nang](https://lua-khoe-ai-v16.eastasia.cloudapp.azure.com/cam-nang)

Lần xuất bản này được ghi ở nhật ký với mã `publish_reference_sources` và định danh tác vụ nội bộ không có quyền đăng nhập. Giao dịch chỉ thêm nhãn thiếu phiên bản công khai; phiên bản đang công khai, nếu có, được giữ nguyên. Bài Tungro phân biệt tên bệnh với bệnh vàng lùn do virus lúa cỏ, theo tài liệu kỹ thuật Việt Nam.

## Quy trình biên tập tiếp theo

### Ảnh đối chiếu

Bản Azure `076b6ae` đã hiển thị ảnh cho cả sáu thẻ và sáu bài chi tiết. Đã xác minh trình duyệt đọc được kích thước gốc của cả sáu ảnh, các bài có liên kết mở ảnh lớn và cổng HTTPS trả đúng tệp WebP theo gói phát hành. [Kiểm thử CI](https://github.com/danhthe5555/lua-khoe-ai/actions/runs/44877078153) · [Ảnh chụp giao diện](evidence/cam-nang-co-anh-076b6ae.jpg).

| Mã nhãn | Ảnh gốc | Nguồn |
|---|---|---|
| `Blast` | `blast_628.jpg` | RiceLeafDiseaseBD v3 |
| `Brown_Spot` | `brown spot_568.jpg` | RiceLeafDiseaseBD v3 |
| `Leaf_Smut` | `Leaf smut_563.jpg` | RiceLeafDiseaseBD v3 |
| `Rice_Tungro` | `Rice Tungro_2197.jpg` | RiceLeafDiseaseBD v3 |
| `Healthy` | `Healthy_503.jpg` | RiceLeafDiseaseBD v3 |
| `Sheath_Blight` | `RiceSheathArk.jpg` | Peggy Greb, USDA Agricultural Research Service, phạm vi công cộng |

Năm ảnh từ [RiceLeafDiseaseBD v3](https://doi.org/10.17632/86s4jzj2m4.3), Mohammad Mehedi Hasan Munna và cộng sự, dùng giấy phép [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Ảnh khô vằn lấy từ [ảnh gốc của USDA ARS](https://commons.wikimedia.org/wiki/File:RiceSheathArk.jpg). Tất cả ảnh được chuyển sang WebP và giữ toàn bộ khung hình; các ảnh dataset được giảm kích thước. Bài chi tiết hiển thị điểm cần quan sát. Thông tin tác giả, tên tệp gốc và giấy phép được ghi tại trang Ghi công ảnh cẩm nang.

Gói bản nháp tham khảo bao phủ sáu mã của EfficientNet-B0. Có thể nhập từ **Quản trị**, mục **Nội dung & nguồn**, bằng nút **Thêm bản nháp tham khảo**. Mỗi bài có nguồn, ngày tra cứu và ghi chú về tái sử dụng. Chín đoạn hướng dẫn quan sát được gắn với các giai đoạn phù hợp; giai đoạn thiếu dữ liệu vẫn hiện trạng thái chưa có nội dung.

Thao tác nhập chỉ tạo bản nháp cho mã đã được mô hình xác nhận và chưa có phiên bản nào trong cơ sở dữ liệu. Các bản nháp cần người có thẩm quyền rà soát và duyệt riêng. Sau khi xuất bản, API cẩm nang và trang kết quả dùng mã nhãn để truy xuất phiên bản đang công khai.

Không tự tạo seed published hoặc công nhận nội dung cũ là đã duyệt. Admin có thể tạo bản nháp, sửa thành phiên bản mới, thêm nguồn/ngày/quyền tái sử dụng, duyệt/xuất bản/ẩn/khôi phục. Bản mới không thay bản đang công khai trước khi duyệt và xuất bản.

Tiếp tục đối chiếu danh sách nhãn trong `model_assets/efficientnet_b0/metadata.json` khi bổ sung nội dung. Tư vấn theo giai đoạn hiện bao phủ các đoạn quan sát đã có trong từng bài; giai đoạn thiếu bài vẫn có trạng thái rõ. Danh mục thuốc và liều lượng cần dữ liệu được xác minh riêng.

API công khai chỉ trả nội dung, nguồn trích dẫn và ngày duyệt; không trả ID người tạo/người duyệt hoặc ghi chú nội bộ về quyền tái sử dụng.
