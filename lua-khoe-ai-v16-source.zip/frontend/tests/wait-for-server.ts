import type {FullConfig} from '@playwright/test';
export default async function waitForServer(config:FullConfig){
 if(process.env.TEST_REQUIRE_COMPLETE==='true'){
  if(process.env.TEST_ALLOW_WRITES!=='true'||!process.env.TEST_IMAGE||!process.env.TEST_ADMIN_EMAIL||!process.env.TEST_ADMIN_PASSWORD)
   throw new Error('Complete acceptance requires an isolated database, real image and test admin. No skipped run is accepted.');
 }
 const baseURL=String(config.projects[0].use.baseURL);const deadline=Date.now()+60000;
 while(Date.now()<deadline){
  try{
   const response=await fetch(new URL('/health/ready',baseURL),{signal:AbortSignal.timeout(5000)});
   const health=await response.json();if(response.ok&&health.database&&health.model?.ready)return;
  }catch{/* Retry until the configured readiness deadline, never substitute a model. */}
  await new Promise(resolve=>setTimeout(resolve,1000));
 }
 throw new Error('API/database/model did not become ready in 60 seconds; E2E was not started.');
}
