import {test,expect} from '@playwright/test';

test('mobile public routes have no overflow and camera guidance',async({page})=>{
 for(const width of [320,360,390,430,768,1024,1440]){
  await page.setViewportSize({width,height:900});
  for(const path of ['/','/nhan-dien','/cam-nang','/dang-nhap']){
   await page.goto(path);await expect(page.locator('h1')).toBeVisible();
   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBeTruthy();
   if([390,1440].includes(width))await page.screenshot({path:`${process.env.TEST_SCREENSHOT_DIR||'../docs/ui/screenshots'}/public-${path.replaceAll('/','')||'home'}-${width}.png`,fullPage:true});
  }
 }
});

test('register, create real plot, logout, second account cannot see it',async({page})=>{
 test.skip(process.env.TEST_ALLOW_WRITES!=='true','Use an isolated test database with TEST_ALLOW_WRITES=true.');
 const stamp=Date.now();
 async function register(email:string){await page.goto('/dang-ky');await page.getByLabel('Tên hiển thị').fill('E2E fixture');await page.getByLabel('Email',{exact:true}).fill(email);await page.getByLabel('Mật khẩu',{exact:true}).fill('E2E-fixture-password-123');await page.getByLabel('Nhập lại mật khẩu').fill('E2E-fixture-password-123');await page.getByRole('button',{name:'Tạo tài khoản',exact:true}).click();await expect(page).toHaveURL(/ruong-lua/)}
 await register(`a${stamp}@example.com`);await page.getByLabel('Tên ruộng',{exact:true}).fill('PRIVATE FARM A');await page.getByLabel('Diện tích (m²)').fill('1000');await page.getByRole('button',{name:'Tạo ruộng',exact:true}).click();await expect(page.getByRole('heading',{name:'PRIVATE FARM A'})).toBeVisible();
 await page.goto('/tai-khoan');await page.getByRole('button',{name:'Đăng xuất'}).click();
 await register(`b${stamp}@example.com`);await expect(page.getByText('PRIVATE FARM A')).toHaveCount(0);
});
