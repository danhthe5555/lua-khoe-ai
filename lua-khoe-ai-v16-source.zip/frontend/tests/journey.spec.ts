import {test,expect} from '@playwright/test';

test('mobile public routes have no overflow and camera guidance',async({page})=>{
 test.slow();
 for(const width of [320,360,390,430,768,1024,1440]){
  await page.setViewportSize({width,height:900});
  for(const path of ['/','/nhan-dien','/cam-nang','/dang-nhap']){
   await page.goto(path);
   await expect(page.locator('h1'),`Page heading for ${path} at ${width}px`).toBeVisible();
   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),`Horizontal overflow on ${path} at ${width}px`).toBeTruthy();
   if(path==='/nhan-dien')await expect(page.getByRole('button',{name:'Chụp ảnh',exact:true})).toBeVisible();
   if([390,1440].includes(width))await page.screenshot({path:`${process.env.TEST_SCREENSHOT_DIR||'../docs/ui/screenshots'}/public-${path.replaceAll('/','')||'home'}-${width}.png`,fullPage:true});
  }
 }
});

test('register, logout, second account cannot access private report',async({page})=>{
 test.skip(process.env.TEST_ALLOW_WRITES!=='true','Use an isolated test database with TEST_ALLOW_WRITES=true.');
 const stamp=Date.now();
 async function register(email:string){await page.goto('/dang-ky');await page.getByLabel('Tên hiển thị').fill('E2E fixture');await page.getByLabel('Email',{exact:true}).fill(email);await page.getByLabel('Mật khẩu',{exact:true}).fill('E2E-fixture-password-123');await page.getByLabel('Nhập lại mật khẩu').fill('E2E-fixture-password-123');await page.getByRole('button',{name:'Tạo tài khoản',exact:true}).click();await expect(page).toHaveURL(/nhan-dien$/)}
 await register(`a${stamp}@example.com`);
 const session=await page.request.get('/api/v1/auth/me');
 expect(session.ok()).toBeTruthy();
 const plotResponse=await page.request.post('/api/v1/plots',{
  headers:{'X-CSRF-Token':(await session.json()).csrf},
  data:{name:'PRIVATE FARM A',area_m2:1000},
 });
 expect(plotResponse.status()).toBe(201);
 const plot=await plotResponse.json();
 const detail='/api/v1/plots/'+plot.id;
 const pdf='/api/v1/reports/plots/'+plot.id+'.pdf';
 const filtered='/api/v1/reports/overview.pdf?plot_id='+plot.id;
 for(const route of [pdf,filtered]){
  const report=await page.request.get(route);
  expect(report.status()).toBe(200);
  expect(report.headers()['cache-control']).toContain('no-store');
  expect((await report.body()).subarray(0,5).toString()).toBe('%PDF-');
 }
 await page.goto('/tai-khoan');await page.getByRole('button',{name:'Đăng xuất',exact:true}).click();
 await expect(page).toHaveURL(/\/$/);
 for(const route of [detail,pdf,filtered])expect((await page.request.get(route)).status()).toBe(401);
 await page.goBack();
 await expect(page).toHaveURL(/\/dang-nhap$/);
 await expect(page.getByText(`a${stamp}@example.com`,{exact:false})).toHaveCount(0);
 await register(`b${stamp}@example.com`);
 for(const route of [detail,pdf,filtered])expect((await page.request.get(route)).status()).toBe(404);
});
