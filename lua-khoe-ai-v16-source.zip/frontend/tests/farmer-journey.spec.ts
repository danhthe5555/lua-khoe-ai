import {test,expect,type BrowserContext} from '@playwright/test';
import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {basename,extname} from 'node:path';

const password='E2E-isolated-fixture-12345';
async function account(context:BrowserContext){
 const email=`e2e-${randomUUID()}@example.com`;
 const registered=await context.request.post('/api/v1/auth/register',{data:{email,name:'E2E TEST FIXTURE',password}});
 expect(registered.status()).toBe(201);
 const logged=await context.request.post('/api/v1/auth/login',{data:{email,password}});
 expect(logged.status()).toBe(200);return (await logged.json()).csrf as string;
}
test.describe('real API and browser on isolated test deployment',()=>{
 test.skip(process.env.TEST_ALLOW_WRITES!=='true','Set TEST_ALLOW_WRITES=true only for an isolated test database.');
 test('E2E-03: create season, record reminder, complete and retain after reload',async({page,context})=>{
  await account(context);await page.goto('/ruong-lua');
  await page.getByLabel('Tên ruộng',{exact:true}).fill('RUỘNG KIỂM THỬ');
  await page.getByLabel('Diện tích (m²)').fill('1500');await page.getByRole('button',{name:'Tạo ruộng',exact:true}).click();
  await page.getByRole('link',{name:'RUỘNG KIỂM THỬ',exact:true}).click();
  await page.getByLabel('Giống lúa',{exact:true}).fill('GIỐNG KIỂM THỬ');
  await page.getByLabel('Ngày gieo sạ').fill('2026-01-01');await page.getByLabel('Giai đoạn do bạn ghi nhận').fill('GIAI ĐOẠN KIỂM THỬ');
  await page.getByRole('button',{name:'Thêm vụ',exact:true}).click();
  await expect(page.getByRole('heading',{name:'GIỐNG KIỂM THỬ',exact:true})).toBeVisible();
  await page.goto('/ruong-lua');await page.getByRole('button',{name:'Ẩn ruộng',exact:true}).click();
  await expect(page.getByRole('dialog',{name:'Xác nhận thao tác'})).toBeVisible();
  await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).not.toBeVisible();
  await expect(page.getByRole('heading',{name:'RUỘNG KIỂM THỬ',exact:true})).toBeVisible();
  await page.goto('/cong-viec');await page.getByLabel('Tiêu đề',{exact:true}).fill('KIỂM TRA LẠI - FIXTURE');
  await page.getByLabel('Ngày giờ tại thiết bị của bạn').fill('2020-01-01T08:00');
  await page.getByLabel('Ruộng và mùa vụ').selectOption({label:'RUỘNG KIỂM THỬ · GIỐNG KIỂM THỬ · 2026-01-01'});
  await page.getByRole('button',{name:'Lưu ghi chép',exact:true}).click();
  await expect(page.getByRole('heading',{name:'KIỂM TRA LẠI - FIXTURE'})).toBeVisible();
  await page.getByLabel('Lọc ghi chép').selectOption('due');
  await page.getByRole('button',{name:'Đánh dấu xong',exact:true}).click();
  await expect(page.getByRole('heading',{name:'KIỂM TRA LẠI - FIXTURE'})).toHaveCount(0);
  await page.reload();await page.getByLabel('Lọc ghi chép').selectOption('done');
  await expect(page.getByRole('heading',{name:'KIỂM TRA LẠI - FIXTURE'})).toBeVisible();
 });
 test('E2E-08: cost calculation updates after changing actual inputs',async({page,context})=>{
  await account(context);await page.goto('/thong-ke');
  await page.getByLabel('Diện tích cần tính (m²)').fill('2500');await page.getByLabel('Định mức đã xác minh',{exact:true}).fill('2');
  await page.getByLabel('Định mức áp dụng cho diện tích (m²)').fill('1000');await page.getByLabel('Đơn vị số lượng (ví dụ kg hoặc lít)').fill('kg');
  await page.getByLabel('Đơn giá (đồng / đơn vị đã nhập)').fill('15000');await page.getByLabel('Nguồn định mức, ngày và người xác minh').fill('TEST FIXTURE — NOT AGRONOMIC ADVICE');
  await page.getByRole('button',{name:'Tính chi phí',exact:true}).click();await expect(page.getByText('Tổng dự tính: 75.000 đồng',{exact:true})).toBeVisible();
  await page.getByLabel('Diện tích cần tính (m²)').fill('5000');await expect(page.getByText('Tổng dự tính: 75.000 đồng',{exact:true})).toHaveCount(0);
  await page.getByRole('button',{name:'Tính chi phí',exact:true}).click();await expect(page.getByText('Tổng dự tính: 150.000 đồng',{exact:true})).toBeVisible();
 });
 test('E2E-06/19/20: inference retry, private image and delete isolation',async({browser})=>{
  test.skip(!process.env.TEST_IMAGE,'A test image is required. Use an authorized real leaf image for field acceptance.');
  const a=await browser.newContext({baseURL:process.env.TEST_BASE_URL||'http://localhost:8080'}),b=await browser.newContext({baseURL:process.env.TEST_BASE_URL||'http://localhost:8080'});
  try{
   const csrfA=await account(a),csrfB=await account(b);const key=randomUUID();
   const imagePath=process.env.TEST_IMAGE!;
   const ext=extname(imagePath).toLowerCase();
   const mimeType=ext==='.png'?'image/png':ext==='.webp'?'image/webp':'image/jpeg';
   const multipart={save:'true',save_image:'true',image:{name:basename(imagePath),mimeType,buffer:readFileSync(imagePath)}};
   const first=await a.request.post('/api/v1/diagnoses/predict',{headers:{'X-CSRF-Token':csrfA,'Idempotency-Key':key},multipart});
   expect(first.status()).toBe(200);const result=await first.json();expect(result.model_version).toMatch(/^[a-f0-9]{64}$/);expect(result.diagnosis_id).toBeTruthy();
   const retry=await a.request.post('/api/v1/diagnoses/predict',{headers:{'X-CSRF-Token':csrfA,'Idempotency-Key':key},multipart});expect((await retry.json()).diagnosis_id).toBe(result.diagnosis_id);
   const path=`/api/v1/diagnoses/${result.diagnosis_id}`;
   expect((await a.request.get(path+'/image')).status()).toBe(200);
   expect((await b.request.get(path)).status()).toBe(404);expect((await b.request.get(path+'/image')).status()).toBe(404);
   expect((await b.request.delete(path,{headers:{'X-CSRF-Token':csrfB}})).status()).toBe(404);
   expect((await a.request.delete(path,{headers:{'X-CSRF-Token':csrfA}})).status()).toBe(200);
   expect((await a.request.get(path+'/image')).status()).toBe(404);
  }finally{await a.close();await b.close()}
 });
 test('E2E-01/02/11: upload, save to a crop season, reopen history, then process a batch',async({page,context})=>{
  const imagePath=process.env.TEST_IMAGE;
  test.skip(!imagePath,'A test image is required.');
  test.slow();
  const csrf=await account(context);
  const headers={'X-CSRF-Token':csrf};
  const plot=await context.request.post('/api/v1/plots',{headers,data:{name:'RUỘNG LỊCH SỬ',area_m2:1800}});
  expect(plot.status()).toBe(201);
  const season=await context.request.post(`/api/v1/plots/${(await plot.json()).id}/seasons`,{
   headers,data:{rice_variety:'GIỐNG KIỂM THỬ',sowing_date:'2026-01-01',growing_stage:'Đẻ nhánh'}});
  expect(season.status()).toBe(201);
  const seasonId=(await season.json()).id;
  await page.setViewportSize({width:390,height:900});
  await page.goto('/nhan-dien');
  await page.getByLabel('Chọn ảnh',{exact:true}).setInputFiles(imagePath!);
  await expect(page.getByAltText('Ảnh lá đã chọn')).toBeVisible();
  await page.getByLabel('Lưu kết quả vào lịch sử của tôi').check();
  await page.getByLabel('Ruộng và mùa vụ').selectOption(seasonId);
  await page.getByLabel('Lưu cả ảnh để xem lại').check();
  await page.getByRole('button',{name:'Phân tích ảnh',exact:true}).click();
  const saved=page.getByRole('link',{name:'Đã lưu · Xem lịch sử'});
  await expect(saved).toBeVisible({timeout:30_000});
  const path=await saved.getAttribute('href');
  const history=await context.request.get(`/api/v1/diagnoses?season_id=${seasonId}`);
  expect(history.ok()).toBeTruthy();
  const rows=await history.json();
  expect(rows).toHaveLength(1);
  expect(path).toBe(`/ket-qua/${rows[0].id}`);
  expect((await context.request.get(`/api/v1/diagnoses/${rows[0].id}/image`)).ok()).toBeTruthy();
  await page.goto('/lich-su');
  await page.reload();
  await expect(page.getByRole('link',{name:'Xem chi tiết'})).toHaveAttribute('href',path!);

  await page.goto('/nhan-dien/nhieu-anh');
  const ext=extname(imagePath!).toLowerCase();
  const mimeType=ext==='.png'?'image/png':ext==='.webp'?'image/webp':'image/jpeg';
  const buffer=readFileSync(imagePath!);
  await page.getByLabel('Chọn tối đa 5 ảnh lá lúa').setInputFiles([
   {name:`first${ext}`,mimeType,buffer},{name:`second${ext}`,mimeType,buffer},
  ]);
  await page.getByRole('button',{name:'Phân tích / thử lại ảnh lỗi'}).click();
  await expect(page.getByText('Đã xử lý 2/2 ảnh.',{exact:true})).toBeVisible({timeout:30_000});
  const afterBatch=await context.request.get('/api/v1/diagnoses');
  expect(afterBatch.ok()).toBeTruthy();
  expect((await afterBatch.json()).map((row:{id:string})=>row.id)).toEqual([rows[0].id]);
 });
});
