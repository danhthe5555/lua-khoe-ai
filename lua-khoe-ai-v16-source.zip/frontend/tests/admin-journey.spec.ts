import {test,expect} from '@playwright/test';
import {randomUUID} from 'node:crypto';

test('E2E-05/15/23: isolated admin review workflow and responsive pages',async({page,context,browser})=>{
 test.slow();
 test.skip(process.env.TEST_ALLOW_WRITES!=='true'||!process.env.TEST_ADMIN_EMAIL||!process.env.TEST_ADMIN_PASSWORD,'Requires isolated acceptance admin, never a production account.');
 const login=await context.request.post('/api/v1/auth/login',{data:{email:process.env.TEST_ADMIN_EMAIL,password:process.env.TEST_ADMIN_PASSWORD}});
 expect(login.status()).toBe(200);const headers={'X-CSRF-Token':(await login.json()).csrf};
 const labels=await context.request.get('/api/v1/model/labels');expect(labels.ok()).toBeTruthy();const code=(await labels.json())[0].code;
 const created=await context.request.post('/api/v1/admin/knowledge',{headers,data:{code,title:'ACCEPTANCE FIXTURE — NOT AGRONOMIC ADVICE',content:{symptoms:'TEST ONLY',field_check:'TEST ONLY',prevention:'TEST ONLY'},sources:[{title:'TEST FIXTURE ONLY',url:'https://example.com/acceptance-fixture',publisher:'TEST ONLY',checked_at:'2026-11-01',reuse_permission:'Isolated test fixture; not real advice'}]}});
 expect(created.status()).toBe(201);const revision=(await created.json()).id;
 const guest=await browser.newContext({baseURL:process.env.TEST_BASE_URL||'http://localhost:8080'});
 try{
  expect((await guest.request.get(`/api/v1/diseases/${code}`)).status()).toBe(404);
  await page.goto('/quan-tri/noi-dung');const item=page.locator('.item').filter({has:page.getByRole('heading',{name:'ACCEPTANCE FIXTURE — NOT AGRONOMIC ADVICE',exact:true})});
  await item.getByRole('button',{name:'Xác nhận đã duyệt',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Xác nhận',exact:true}).click();
  await item.getByRole('button',{name:'Xuất bản',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Xác nhận',exact:true}).click();
  await expect.poll(async()=>{const response=await guest.request.get(`/api/v1/diseases/${code}`);return response.status()}).toBe(200);
  const published=await guest.request.get(`/api/v1/diseases/${code}`);expect((await published.json()).id).toBe(revision);
  const reader=await guest.newPage();
  await reader.goto('/cam-nang');
  const preview=reader.locator('figure.knowledge-photo img');
  await expect(preview).toHaveCount(1);
  await preview.scrollIntoViewIfNeeded();
  await expect.poll(()=>preview.evaluate(img=>(img as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
  await reader.getByRole('link',{name:'Đọc hướng dẫn',exact:true}).click();
  const detail=reader.locator('figure.knowledge-photo-detail img');
  await expect.poll(()=>detail.evaluate(img=>(img as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
  await expect(reader.getByRole('link',{name:'Mở ảnh lớn'})).toBeVisible();
  await expect(reader.locator('figure.knowledge-photo-detail figcaption')).not.toContainText('CC BY');
  await reader.getByRole('link',{name:'Ghi công ảnh cẩm nang',exact:true}).click();
  await expect(reader.getByRole('heading',{name:'Ghi công ảnh cẩm nang'})).toBeVisible();
  await expect(reader.getByRole('link',{name:'CC BY 4.0',exact:true})).toBeVisible();
  await reader.close();
  await item.getByRole('button',{name:'Ẩn nội dung',exact:true}).click();
  await page.getByRole('dialog').getByRole('button',{name:'Xác nhận',exact:true}).click();
  await expect.poll(async()=>(await guest.request.get(`/api/v1/diseases/${code}`)).status()).toBe(404);
  await item.getByRole('button',{name:'Phục hồi phiên bản',exact:true}).click();
  await page.getByRole('dialog').getByRole('button',{name:'Xác nhận',exact:true}).click();
  await expect.poll(async()=>{
   const response=await guest.request.get(`/api/v1/diseases/${code}`);
   return response.ok()?(await response.json()).id:null;
  }).toBe(revision);
  expect((await context.request.get('/api/v1/plots')).status()).toBe(403);
  const farmerEmail=`farmer-${randomUUID()}@example.com`;const password='Acceptance-fixture-pass-123';
  expect((await guest.request.post('/api/v1/auth/register',{data:{email:farmerEmail,password,name:'FARMER TEST'}})).status()).toBe(201);
  expect((await guest.request.post('/api/v1/auth/login',{data:{email:farmerEmail,password}})).status()).toBe(200);
  expect((await guest.request.get('/api/v1/admin/knowledge')).status()).toBe(403);
  await page.getByRole('button',{name:'Thêm bản nháp tham khảo',exact:true}).click();
  await expect(page.getByText('Đã thêm 5 bản nháp. Bỏ qua 1 nhãn đã có nội dung.')).toBeVisible();
  await page.getByRole('button',{name:'Thêm bản nháp tham khảo',exact:true}).click();
  await expect(page.getByText('Đã thêm 0 bản nháp. Bỏ qua 6 nhãn đã có nội dung.')).toBeVisible();
  const publicArticles=await guest.request.get('/api/v1/diseases');
  expect((await publicArticles.json()).map((article:{id:string})=>article.id)).toEqual([revision]);
  await page.goto('/quan-tri/nhan-thuoc');
  await expect(page.getByRole('alert')).toHaveText('Không tìm thấy trang quản trị.');
  await expect(page.getByRole('link',{name:'Nhãn & nguồn',exact:true})).toHaveCount(0);
  for(const width of [320,390,1024,1440]){
   await page.setViewportSize({width,height:900});
   for(const path of ['/quan-tri','/quan-tri/noi-dung','/quan-tri/tai-khoan','/quan-tri/nhat-ky','/quan-tri/phan-hoi']){
    await page.goto(path);await expect(page.getByRole('heading',{level:1})).toBeVisible();
    await expect(page.getByRole('link',{name:'Nhận diện bệnh',exact:true})).toHaveCount(0);
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
    if([390,1440].includes(width))await page.screenshot({path:`${process.env.TEST_SCREENSHOT_DIR||'../docs/ui/screenshots'}/admin-${path.replaceAll('/','-')}-${width}.png`,fullPage:true});
   }
  }
 }finally{
  await context.request.post(`/api/v1/admin/knowledge/${revision}/archive`,{headers,data:{confirmed:true}});await guest.close();
 }
});
