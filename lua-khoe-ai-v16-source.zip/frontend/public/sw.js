// Only public static resources. Never intercept personal APIs, images, or navigations.
const CACHE='lua-khoe-public-v1';
const SAFE=['/offline.html','/icon.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SAFE))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('lua-khoe-public-')&&k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(url.origin!==self.location.origin||event.request.method!=='GET')return;if(SAFE.includes(url.pathname))event.respondWith(caches.match(event.request).then(r=>r||fetch(event.request)));else if(event.request.mode==='navigate')event.respondWith(fetch(event.request).catch(()=>caches.match('/offline.html')))});

self.addEventListener('push',event=>event.waitUntil((async()=>{
 try{
  const payload=event.data?.json();const id=payload?.subscription_id;
  if(typeof id!=='string'||! /^[0-9a-f-]{36}$/i.test(id)||Notification.permission!=='granted')return;
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),10000);
  let allowed=false;
  try{const response=await fetch(`/api/v1/push/verify/${id}`,{credentials:'include',cache:'no-store',signal:controller.signal});allowed=response.ok&&(await response.json()).show===true}finally{clearTimeout(timer)}
  if(allowed)await self.registration.showNotification('Lúa Khỏe AI',{body:'Có nhắc việc đến hạn. Mở ứng dụng để xem.',icon:'/icon.svg',tag:'lua-khoe-due',data:{url:'/cong-viec'}});
 }catch{/* No notification if the session cannot be verified. */}
})()));
self.addEventListener('notificationclick',event=>{
 event.notification.close();event.waitUntil(clients.openWindow('/cong-viec'));
});
