type ReferencePhoto = {
  file: string;
  alt: string;
  caption: string;
  original: string;
  width?: number;
  height?: number;
};

const dataset = 'https://doi.org/10.17632/86s4jzj2m4.3';
const usdaPhoto = 'https://commons.wikimedia.org/wiki/File:RiceSheathArk.jpg';
const photos = new Map<string, ReferencePhoto>([
  ['Blast', {
    file: 'blast', original: 'blast_628.jpg',
    alt: 'Vết màu xám nhạt kéo dài trên phiến lá lúa',
    caption: 'Quan sát vết kéo dài, tâm xám nhạt và viền nâu trên phiến lá.',
  }],
  ['Brown_Spot', {
    file: 'brown-spot', original: 'brown spot_568.jpg',
    alt: 'Nhiều đốm nâu nhỏ, gần tròn trên phiến lá lúa',
    caption: 'Quan sát các đốm nâu gần tròn, rải rác trên phiến lá.',
  }],
  ['Leaf_Smut', {
    file: 'leaf-smut', original: 'Leaf smut_563.jpg',
    alt: 'Vết sẫm màu nhỏ nằm riêng trên phiến lá xanh',
    caption: 'Quan sát vết sẫm nhỏ nằm riêng trên phiến lá xanh. Đối chiếu thêm các lá khác khi gặp vết tương tự.',
  }],
  ['Rice_Tungro', {
    file: 'rice-tungro', original: 'Rice Tungro_2197.jpg',
    alt: 'Lá lúa chuyển vàng cam, phần giữa lá vẫn còn màu xanh',
    caption: 'Ảnh mẫu cho thấy lá vàng cam. Khi kiểm tra ngoài ruộng, cần quan sát thêm chiều cao và số nhánh của cả khóm.',
  }],
  ['Healthy', {
    file: 'healthy', original: 'Healthy_503.jpg',
    alt: 'Phiến lá lúa xanh với gân lá rõ',
    caption: 'Mặt lá trong khung hình xanh tương đối đều. Dùng mẫu này để đối chiếu màu và bề mặt lá.',
  }],
  ['Sheath_Blight', {
    file: 'sheath-blight', original: 'RiceSheathArk.jpg', width: 427, height: 640,
    alt: 'Vết khô vằn màu nhạt với viền sẫm trên lá lúa',
    caption: 'Quan sát các vết màu nhạt có rìa nâu. Ngoài ruộng, kiểm tra thêm bẹ phía thấp để xem vết bắt đầu ở đâu.',
  }],
]);

export function KnowledgePhoto({code, detail = false}: {code: string; detail?: boolean}) {
  const photo = photos.get(code);
  if (!photo) return null;

  const src = `/knowledge-photos/${photo.file}.webp`;
  const isUSDA = code === 'Sheath_Blight';
  return <figure className={detail ? 'knowledge-photo knowledge-photo-detail' : 'knowledge-photo'}>
    <img src={src} alt={photo.alt} width={photo.width ?? 850} height={photo.height ?? 850} loading={detail ? 'eager' : 'lazy'} decoding="async" />
    {detail && <figcaption>
      <p>{photo.caption}</p>
      <p className="muted">
        Ảnh đối chiếu · <a href={isUSDA ? usdaPhoto : dataset} target="_blank" rel="noreferrer">
          {isUSDA ? 'Peggy Greb, USDA ARS' : 'Mohammad Mehedi Hasan Munna và cộng sự, RiceLeafDiseaseBD v3'}
        </a> · {isUSDA ? 'Phạm vi công cộng' : <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0</a>}
        {' · '}{photo.original} · Chuyển sang WebP{isUSDA ? '' : ', giảm kích thước'}.
      </p>
      <a href={src} target="_blank" rel="noreferrer">Mở ảnh lớn</a>
    </figcaption>}
  </figure>;
}
