import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link, useParams} from 'react-router-dom';
import {ImageOff, Printer} from 'lucide-react';
import {api} from './api';
import {Alert, Button, Card, Heading} from './ui';

const answerLabels:Record<string,string>={yes:'Có',no:'Không',unknown:'Không rõ'};
export function RecordImage({id,available,thumbnail=false}:{id:string;available:boolean;thumbnail?:boolean}){
  const [failed,setFailed]=useState(false);
  return available&&!failed?
    <img className={thumbnail?'record-thumb':'record-original'} src={'/api/v1/diagnoses/'+encodeURIComponent(id)+(thumbnail?'/thumbnail':'/image')}
      alt="Ảnh lá của bản ghi" loading={thumbnail?'lazy':'eager'} onError={()=>setFailed(true)}/>:
    <div className={thumbnail?'record-thumb image-empty':'image-empty record-original'}>
      <ImageOff size={thumbnail?18:30}/>{!thumbnail&&<span>Ảnh của bản ghi này hiện không có.</span>}
    </div>;
}

export function ResultReport(){
  const {id=''}=useParams();
  const path='/diagnoses/'+id;
  const entry=useQuery({queryKey:[path],queryFn:()=>api(path)});
  const assessment=useQuery({queryKey:[path+'/assessment'],queryFn:()=>api(path+'/assessment')});
  const [shareNotice,setShareNotice]=useState('');
  if(entry.isPending||assessment.isPending)return <p role="status">Đang tải phiếu…</p>;
  if(entry.isError||assessment.isError)return <Alert error>{(entry.error||assessment.error)?.message}</Alert>;
  const row=entry.data;
  const result=row.result;
  const data=assessment.data;
  const checkedAt=new Date(row.created_at).toLocaleString('vi-VN');
  const score=(result.raw_score*100).toFixed(1)+'%';
  const reviewNote='Cần đối chiếu triệu chứng ngoài ruộng để xác nhận.';
  const context=[data.stages[data.stage], data.spread==='unknown'?null:data.spread_options[data.spread]].filter(Boolean);
  const answers=data.questions.flatMap((question:string,index:number)=>{
    const answer=answerLabels[data.answers[index]];
    return answer?[question+' - '+answer]:[];
  }) as string[];
  const completed=data.tasks.filter((_:string,index:number)=>data.completed[index]) as string[];
  async function copySummary(){
    const summary=[
      'Lúa Khỏe AI · Phiếu tham khảo', checkedAt,
      'AI dự đoán: '+result.display_label_vi+' · Điểm dự đoán '+score,
      reviewNote, ...context, ...answers, ...completed,
    ].join('\n');
    try{await navigator.clipboard.writeText(summary);setShareNotice('Đã sao chép nội dung văn bản.')}
    catch{setShareNotice('Thiết bị chưa cho phép sao chép. Bạn có thể in hoặc lưu PDF.')}
  }
  return <div className="result-report">
    <Heading title="Phiếu tham khảo gửi chuyên gia">Lúa Khỏe AI · Thời điểm nhận diện {checkedAt}</Heading>
    <div className="row report-actions"><Button onClick={()=>window.print()}><Printer size={18}/>In / Lưu PDF</Button>
      <Button className="secondary" onClick={()=>void copySummary()}>Sao chép tóm tắt</Button>
      <Link to={'/results/'+id}>Quay lại kết quả</Link></div>
    {shareNotice&&<p className="report-actions" role="status">{shareNotice}</p>}
    <Card><div className="report-summary">
      <div>
        <span className="muted">AI dự đoán</span>
        <h2>{result.display_label_vi}</h2>
        <p>Điểm dự đoán <strong>{score}</strong></p>
        <p>{reviewNote}</p>
      </div>
      <RecordImage key={id} id={id} available={Boolean(row.image_key)}/>
    </div>
      {(context.length>0||answers.length>0)&&<><h3>Bối cảnh và câu trả lời</h3>
        {context.length>0&&<p>{context.join(' · ')}</p>}
        {answers.map(answer=><p key={answer}>{answer}</p>)}
      </>}
      {completed.length>0&&<><h3>Các bước đã thực hiện</h3>
        <ul>{completed.map(task=><li key={task}>{task}</li>)}</ul>
      </>}
    </Card>
  </div>;
}
