import {useState} from 'react';
import {useQuery, useQueryClient} from '@tanstack/react-query';
import {Link, useParams} from 'react-router-dom';
import {BookOpen, FileText, ImageOff, Printer} from 'lucide-react';
import {api, type Row} from './api';
import {Alert, Badge, Button, Card, Heading} from './ui';

const answerLabels:Record<string,string>={yes:'Có',no:'Không',unknown:'Không rõ'};
const alignments:Record<string,string>={
  consistent:'Các dấu hiệu đã trả lời tương đồng.',
  partial:'Một số dấu hiệu tương đồng, cần kiểm tra thêm.',
  conflicting:'Các dấu hiệu đã trả lời đang khác mô tả.',
  insufficient:'Chưa đủ cơ sở đối chiếu.',
};

export function RecordImage({id,available,thumbnail=false}:{id:string;available:boolean;thumbnail?:boolean}){
  const [failed,setFailed]=useState(false);
  return available&&!failed?
    <img className={thumbnail?'record-thumb':'record-original'} src={'/api/v1/diagnoses/'+encodeURIComponent(id)+(thumbnail?'/thumbnail':'/image')}
      alt="Ảnh lá của bản ghi" loading={thumbnail?'lazy':'eager'} onError={()=>setFailed(true)}/>:
    <div className={thumbnail?'record-thumb image-empty':'image-empty record-original'}>
      <ImageOff size={thumbnail?18:30}/>{!thumbnail&&<span>Ảnh của bản ghi này hiện không có.</span>}
    </div>;
}

export function ResultAssessment({id}:{id:string}){
  const path='/diagnoses/'+id+'/assessment';
  const client=useQueryClient();
  const q=useQuery({queryKey:[path],queryFn:()=>api(path)});
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');
  const data=q.data;

  async function save(change:Row){
    setBusy(true);setError('');setNotice('');
    try{
      const updated=await api(path,'PATCH',{version:data.version,...change});
      client.setQueryData([path],updated);
      setNotice('Đã lưu vào bản ghi.');
    }catch(error){setError((error as Error).message)}
    finally{setBusy(false)}
  }

  if(q.isPending)return <p role="status">Đang tải phần đối chiếu…</p>;
  if(q.isError)return <Alert error>{q.error.message} <Button className="secondary" onClick={()=>q.refetch()}>Tải lại</Button></Alert>;
  const attention=data.spread==='widespread'||data.alignment==='conflicting';
  const guidance=data.stage==='unknown'?data.general_text:data.stage_text[data.stage];

  return <div className="assessment-grid">
    <section className="assessment-section">
      <h3>Đối chiếu triệu chứng</h3>
      {data.questions.length?<>
        {data.questions.map((question:string,index:number)=><fieldset className="answer-group" key={question}>
          <legend>{question}</legend>
          <div className="row">{Object.entries(answerLabels).map(([key,label])=>
            <Button key={key} disabled={busy} aria-pressed={data.answers[index]===key}
              className={data.answers[index]===key?'':'secondary'} onClick={()=>void save({question:index,answer:key})}>{label}</Button>)}</div>
        </fieldset>)}
        <p>{Object.keys(data.answers).length}/{data.questions.length} câu đã trả lời. {alignments[data.alignment]}</p>
        <p className="muted">Kết quả hỗ trợ đối chiếu. Nhãn dự đoán của AI được giữ nguyên.</p>
      </>:<p>Chưa có bộ câu hỏi được duyệt cho bệnh này.</p>}
    </section>
    <section className="assessment-section">
      <h3>Hướng dẫn theo tình trạng</h3>
      <div className="grid two">
        <label className="field">Giai đoạn cây<select aria-label="Giai đoạn cây" value={data.stage} disabled={busy} onChange={e=>void save({stage:e.target.value})}>
          <option value="unknown">Chưa rõ</option>{Object.entries(data.stages).map(([key,value])=><option key={key} value={key}>{String(value)}</option>)}
        </select></label>
        <label className="field">Phạm vi dấu hiệu<select aria-label="Phạm vi dấu hiệu" value={data.spread} disabled={busy} onChange={e=>void save({spread:e.target.value})}>
          {Object.entries(data.spread_options).map(([key,value])=><option key={key} value={key}>{String(value)}</option>)}
        </select></label>
      </div>
      {attention&&<Alert>Ưu tiên liên hệ cán bộ bảo vệ thực vật địa phương để kiểm tra tình trạng ngoài ruộng.</Alert>}
      {guidance?<p>{guidance}</p>:<p>Chưa có hướng dẫn đã duyệt cho lựa chọn này.</p>}
      {data.spread_text?.[data.spread]&&<p>{data.spread_text[data.spread]}</p>}
      {data.guide&&<><p className="muted">Duyệt ngày {new Date(data.guide.reviewed_at).toLocaleDateString('vi-VN')} · Phiên bản {data.guide.id.slice(0,8)}</p>
        <Link to={'/cam-nang/'+data.guide.code}><BookOpen size={16}/> Xem cẩm nang và nguồn</Link></>}
    </section>
    <section className="assessment-section">
      <h3>Bệnh dễ nhầm</h3>
      {data.alternatives.length?<ul>{data.alternatives.map((item:Row)=><li key={item.code}>
        <Link to={'/cam-nang/'+item.code}>{item.title}</Link><p>{item.detail}</p>
      </li>)}</ul>:<p>Chưa có danh mục bệnh dễ nhầm được duyệt.</p>}
    </section>
    <section className="assessment-section">
      <h3>Các bước đối chiếu</h3>
      {data.tasks.map((task:string,index:number)=><label className="check task-check" key={task}>
        <input type="checkbox" checked={Boolean(data.completed[index])} disabled={busy} onChange={e=>void save({task:index,done:e.target.checked})}/>{task}
      </label>)}
    </section>
    {error&&<Alert error>{error} <Button className="secondary" onClick={()=>q.refetch()}>Tải lại</Button></Alert>}
    {notice&&<p role="status" className="muted">{notice}</p>}
    <div><Link className="link-button secondary" to={'/results/'+id+'/report'}><FileText size={18}/>Xuất phiếu gửi chuyên gia</Link></div>
  </div>;
}

export function ResultReport(){
  const {id=''}=useParams();
  const path='/diagnoses/'+id;
  const entry=useQuery({queryKey:[path],queryFn:()=>api(path)});
  const assessment=useQuery({queryKey:[path+'/assessment'],queryFn:()=>api(path+'/assessment')});
  const [shareNotice,setShareNotice]=useState('');
  if(entry.isPending||assessment.isPending)return <p role="status">Đang tải phiếu…</p>;
  if(entry.isError||assessment.isError)return <Alert error>{(entry.error||assessment.error)?.message}</Alert>;
  const row=entry.data;
  const result=row.result;
  const data=assessment.data;
  async function copySummary(){
    const summary=[
      'Lúa Khỏe AI · Phiếu tham khảo',new Date(row.created_at).toLocaleString('vi-VN'),
      result.display_label_vi+' · Điểm mô hình '+(result.raw_score*100).toFixed(1)+'%',
      result.review_message, data.stages[data.stage]||'Chưa rõ giai đoạn',data.spread_options[data.spread],
      ...data.questions.map((question:string,index:number)=>question+' — '+(answerLabels[data.answers[index]]||'Chưa trả lời')),
    ].join('\n');
    try{await navigator.clipboard.writeText(summary);setShareNotice('Đã sao chép nội dung văn bản.')}
    catch{setShareNotice('Thiết bị chưa cho phép sao chép. Bạn có thể in hoặc lưu PDF.')}
  }
  return <div className="result-report">
    <Heading title="Phiếu tham khảo gửi chuyên gia">Lúa Khỏe AI · {new Date(row.created_at).toLocaleString('vi-VN')}</Heading>
    <div className="row report-actions"><Button onClick={()=>window.print()}><Printer size={18}/>In / Lưu PDF</Button>
      <Button className="secondary" onClick={()=>void copySummary()}>Sao chép tóm tắt</Button>
      <Link to={'/results/'+id}>Quay lại kết quả</Link></div>
    {shareNotice&&<p className="report-actions" role="status">{shareNotice}</p>}
    <Card><div className="grid two">
      <RecordImage key={id} id={id} available={Boolean(row.image_key)}/>
      <div><Badge>Cần đối chiếu</Badge><h2>{result.display_label_vi}</h2>
        <p>Điểm mô hình {(result.raw_score*100).toFixed(1)}%</p><p>{result.review_message}</p>
        <p className="record-id">Bản ghi {row.id}<br/>Phiên bản mô hình {result.model_version}</p>
      </div></div>
      <h3>Bối cảnh và câu trả lời</h3>
      <p>{data.stages[data.stage]||'Chưa rõ giai đoạn'} · {data.spread_options[data.spread]}</p>
      {data.questions.map((question:string,index:number)=><p key={question}>{question} — {answerLabels[data.answers[index]]||'Chưa trả lời'}</p>)}
      <h3>Các bước đối chiếu</h3>
      <ul>{data.tasks.map((task:string,index:number)=><li key={task}>{data.completed[index]?'Đã thực hiện':'Chưa thực hiện'} · {task}</li>)}</ul>
      {data.guide&&<><h3>Cẩm nang được sử dụng</h3>
        <p>{data.guide.title} · {data.guide.id} · Duyệt {new Date(data.guide.reviewed_at).toLocaleDateString('vi-VN')}</p>
        {data.guide.sources.map((source:Row)=><p key={source.url}><a href={source.url}>{source.title}</a></p>)}
      </>}
    </Card>
  </div>;
}
