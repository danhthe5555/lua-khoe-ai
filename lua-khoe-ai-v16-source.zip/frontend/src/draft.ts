// In-memory only: no localStorage, sessionStorage or shared service-worker cache.
import type {Row} from './api';
type SaveOptions={season:string;image:boolean};
export const predictionDraft:{
  file:File|null;result:Row|null;owner:string|null;key:string;season:string;followup:string;saveOptions:SaveOptions|null;
}={file:null,result:null,owner:null,key:'',season:'',followup:'',saveOptions:null};
export function clearPredictionDraft(){
  Object.assign(predictionDraft,{file:null,result:null,owner:null,key:'',season:'',followup:'',saveOptions:null});
}
