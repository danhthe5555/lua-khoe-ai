// In-memory only: no localStorage, sessionStorage or shared service-worker cache.
import type {Row} from './api';
export const predictionDraft:{
  file:File|null;result:Row|null;owner:string|null;key:string;followup:string;
}={file:null,result:null,owner:null,key:'',followup:''};
export function clearPredictionDraft(){
  Object.assign(predictionDraft,{file:null,result:null,owner:null,key:'',followup:''});
}
