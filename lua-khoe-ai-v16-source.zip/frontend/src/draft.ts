// In-memory only: no localStorage, sessionStorage or shared service-worker cache.
import type {Row} from './api';
export const predictionDraft:{file:File|null,result:Row|null,owner:string|null}={file:null,result:null,owner:null};
export function clearPredictionDraft(){predictionDraft.file=null;predictionDraft.result=null;predictionDraft.owner=null}
