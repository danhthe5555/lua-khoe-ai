import {useEffect,useId,useRef,useState,type ReactNode,type ButtonHTMLAttributes,type InputHTMLAttributes} from 'react';
import {Sprout,Info} from 'lucide-react';
import {Link} from 'react-router-dom';
export function Brand(){return <Link className="brand" to="/"><span><Sprout size={26}/></span><div>Lúa Khỏe <b>AI</b><small>Chăm sóc từ chiếc lá</small></div></Link>}
export function Button({children,className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>){return <button className={`button ${className}`} {...props}>{children}</button>}
export function Card({children,className=''}:{children:ReactNode,className?:string}){return <section className={`card ${className}`}>{children}</section>}
export function Field({label,...props}:InputHTMLAttributes<HTMLInputElement>&{label:string}){const id=useId();return <label className="field" htmlFor={id}>{label}<input id={id} {...props}/></label>}
export function Alert({children,error=false}:{children:ReactNode,error?:boolean}){return <div className={`alert ${error?'error':''}`} role={error?'alert':'status'}><Info size={20}/><span>{children}</span></div>}
export function Empty({title,children}:{title:string,children?:ReactNode}){return <div className="empty"><Sprout size={32}/><h3>{title}</h3>{children}</div>}
export function Heading({eyebrow,title,children}:{eyebrow?:string,title:string,children?:ReactNode}){return <header className="page-heading">{eyebrow&&<span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1>{children&&<p>{children}</p>}</header>}
export function Badge({children}:{children:ReactNode}){return <span className="badge">{children}</span>}

type Confirmation={message:string,resolve:(answer:boolean)=>void};
let confirmationListener:((request:Confirmation)=>void)|null=null;
export function confirmAction(message:string):Promise<boolean>{
 return new Promise(resolve=>{if(confirmationListener)confirmationListener({message,resolve});else resolve(false)});
}
export function ConfirmDialog(){
 const[pending,setPending]=useState<Confirmation|null>(null);const current=useRef<Confirmation|null>(null);const element=useRef<HTMLDialogElement>(null);const titleId=useId();const descriptionId=useId();
 function finish(answer:boolean){const request=current.current;current.current=null;setPending(null);element.current?.close();request?.resolve(answer)}
 useEffect(()=>{
  const listener=(request:Confirmation)=>{current.current?.resolve(false);current.current=request;setPending(request)};
  confirmationListener=listener;
  return()=>{if(confirmationListener===listener)confirmationListener=null;current.current?.resolve(false);current.current=null};
 },[]);
 useEffect(()=>{if(pending&&!element.current?.open)element.current?.showModal()},[pending]);
 return <dialog className="confirmation" ref={element} aria-labelledby={titleId} aria-describedby={descriptionId} onCancel={e=>{e.preventDefault();finish(false)}} onClose={()=>{if(current.current)finish(false)}}>
 <h2 id={titleId}>Xác nhận thao tác</h2><p id={descriptionId}>{pending?.message}</p><div className="row"><Button className="secondary" autoFocus onClick={()=>finish(false)}>Hủy</Button><Button onClick={()=>finish(true)}>Xác nhận</Button></div></dialog>;
}
export function Toast({children,onDismiss}:{children:ReactNode,onDismiss:()=>void}){
 return <div className="toast"><span role="status">{children}</span><Button type="button" className="secondary" onClick={onDismiss} aria-label="Đóng thông báo">Đóng</Button></div>;
}
