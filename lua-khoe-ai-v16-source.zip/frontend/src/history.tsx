import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {Alert,Badge,Button,Card,Empty,Field,Heading,confirmAction} from './ui';
import {SeasonSelect,DiseaseSelect} from './management';
import {clearPredictionDraft} from './draft';
import {RecordImage} from './result-assessment';

export function HistoryPage(){
 const[filters,setFilters]=useState('');const[page,setPage]=useState(0);
 const[error,setError]=useState('');const[deleting,setDeleting]=useState<string|null>(null);
 const path=`/diagnoses?${filters}&offset=${page*20}&limit=20`;
 const q=useQuery({queryKey:[path],queryFn:()=>api(path)});
 async function remove(row:Row){
  if(deleting||!await confirmAction('Xóa kết quả và ảnh đã lưu?'))return;
  setDeleting(row.id);setError('');
  try{await api('/diagnoses/'+row.id,'DELETE');await q.refetch()}
  catch(error){setError((error as Error).message)}
  finally{setDeleting(null)}
 }
 return <><Heading title="Lịch sử nhận diện">Lọc các lần kiểm tra đã lưu theo mùa vụ, nhãn dự đoán và ngày.</Heading>
 <div className="row"><Link className="link-button" to="/nhan-dien" onClick={clearPredictionDraft}>Kiểm tra ảnh mới</Link><Link to="/cong-viec">Việc cần làm</Link></div>
 <details className="check-details"><summary>Lọc theo vụ, bệnh và ngày</summary><Card><form onSubmit={e=>{e.preventDefault();const params=new URLSearchParams();for(const[k,v]of new FormData(e.currentTarget))if(v)params.set(k,String(v));setFilters(params.toString());setPage(0)}}>
 <div className="grid two"><SeasonSelect name="season_id" includeArchived/><DiseaseSelect/><Field label="Từ ngày (UTC)" type="date" name="from_date"/><Field label="Đến ngày (UTC)" type="date" name="to_date"/></div><Button>Áp dụng bộ lọc</Button></form></Card></details>
 {error&&<Alert error>{error}</Alert>}{q.isPending?<p role="status">Đang tải lịch sử…</p>:q.isError?<Alert error>{q.error.message}<Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:<>
 {q.data.length?<div className="card history-list">
  <div className="history-desktop"><table className="history-table">
   <thead><tr><th>Ảnh</th><th>Kết quả</th><th>Ngày kiểm tra</th><th>Đợt theo dõi</th><th>Thao tác</th></tr></thead>
   <tbody>{q.data.map((row:Row)=><tr key={row.id}>
    <td><RecordImage id={row.id} available={Boolean(row.image_key)} thumbnail/></td>
    <td><strong>{row.result.display_label_vi}</strong><br/><Badge>Cần đối chiếu</Badge></td>
    <td>{new Date(row.created_at).toLocaleString('vi-VN')}</td>
    <td className="record-id">{(row.tracking_id||row.id).slice(0,8)}</td>
    <td><div className="row"><Link to={'/results/'+row.id}>Xem chi tiết</Link><Button className="secondary" disabled={deleting!==null} onClick={()=>void remove(row)}>Xóa</Button></div></td>
   </tr>)}</tbody>
  </table></div>
  <div className="history-mobile">{q.data.map((row:Row)=><article key={row.id}>
   <Link to={'/results/'+row.id} aria-label="Xem chi tiết">
    <RecordImage id={row.id} available={Boolean(row.image_key)} thumbnail/>
    <span><strong>{row.result.display_label_vi}</strong><p>{new Date(row.created_at).toLocaleString('vi-VN')}</p></span>
   </Link><Button className="secondary" disabled={deleting!==null} onClick={()=>void remove(row)}>Xóa</Button>
  </article>)}</div>
 </div>:<Card><Empty title="Không có kết quả trong bộ lọc"><Link to="/nhan-dien">Chụp ảnh nhận diện</Link></Empty></Card>}
 <div className="row"><Button className="secondary" disabled={page===0} onClick={()=>setPage(page-1)}>Trang trước</Button><span>Trang {page+1}</span><Button className="secondary" disabled={q.data.length<20} onClick={()=>setPage(page+1)}>Trang sau</Button></div></>}
 </>;
}
