import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {Alert,Badge,Button,Card,Empty,Field,Heading,confirmAction} from './ui';
import {SeasonSelect,DiseaseSelect} from './management';
import {clearPredictionDraft} from './draft';

export function HistoryPage(){
 const[filters,setFilters]=useState('');const[page,setPage]=useState(0);
 const[error,setError]=useState('');const[deleting,setDeleting]=useState<string|null>(null);
 const path=`/diagnoses?${filters}&offset=${page*20}&limit=20`;
 const q=useQuery({queryKey:[path],queryFn:()=>api(path)});
 return <><Heading title="Lịch sử nhận diện">Lọc các lần kiểm tra đã lưu theo mùa vụ, nhãn dự đoán và ngày.</Heading>
 <div className="row"><Link className="link-button" to="/nhan-dien" onClick={clearPredictionDraft}>Kiểm tra ảnh mới</Link><Link to="/cong-viec">Việc cần làm</Link></div>
 <details className="check-details"><summary>Lọc theo vụ, bệnh và ngày</summary><Card><form onSubmit={e=>{e.preventDefault();const params=new URLSearchParams();for(const[k,v]of new FormData(e.currentTarget))if(v)params.set(k,String(v));setFilters(params.toString());setPage(0)}}>
 <div className="grid two"><SeasonSelect name="season_id" includeArchived/><DiseaseSelect/><Field label="Từ ngày (UTC)" type="date" name="from_date"/><Field label="Đến ngày (UTC)" type="date" name="to_date"/></div><Button>Áp dụng bộ lọc</Button></form></Card></details>
 {error&&<Alert error>{error}</Alert>}{q.isPending?<p role="status">Đang tải lịch sử…</p>:q.isError?<Alert error>{q.error.message}<Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:<>
 {q.data.length?<div className="grid">{q.data.map((r:Row)=><Card key={r.id}><Badge>AI dự đoán</Badge><h2>{r.result.display_label_vi}</h2><p>{new Date(r.created_at).toLocaleString('vi-VN')}</p><div className="row"><Link to={`/ket-qua/${r.id}`}>Xem chi tiết</Link><Button className="secondary" disabled={deleting!==null} onClick={async()=>{if(!await confirmAction('Xóa kết quả và ảnh đã lưu?'))return;setDeleting(r.id);setError('');try{await api(`/diagnoses/${r.id}`,'DELETE');await q.refetch()}catch(e){setError((e as Error).message)}finally{setDeleting(null)}}}>{deleting===r.id?'Đang xóa…':'Xóa'}</Button></div></Card>)}</div>:<Card><Empty title="Không có kết quả trong bộ lọc"><Link to="/nhan-dien">Chụp ảnh nhận diện</Link></Empty></Card>}
 <div className="row"><Button className="secondary" disabled={page===0} onClick={()=>setPage(page-1)}>Trang trước</Button><span>Trang {page+1}</span><Button className="secondary" disabled={q.data.length<20} onClick={()=>setPage(page+1)}>Trang sau</Button></div></>}
 </>;
}
