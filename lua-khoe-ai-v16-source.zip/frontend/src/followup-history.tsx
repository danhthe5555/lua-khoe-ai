import {useInfiniteQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api} from './api';
import {RecordImage} from './result-assessment';
import {Alert,Button,Card} from './ui';

type Check={id:string;created_at:string;label:string;has_image:boolean;raw_score?:number|null};
type HistoryPage={checks:Check[];checks_total:number};

export function FollowupHistory({id,currentId}:{id:string;currentId?:string}){
  const path='/diagnoses/'+encodeURIComponent(id)+'/tracking';
  const query=useInfiniteQuery({
    queryKey:[path,'followup-history'],
    queryFn:({pageParam}):Promise<HistoryPage>=>api(path+'?checks_offset='+pageParam),
    initialPageParam:0,
    getNextPageParam:(lastPage,pages)=>{
      const loaded=pages.reduce((sum,page)=>sum+page.checks.length,0);
      return lastPage.checks.length&&loaded<lastPage.checks_total?loaded:undefined;
    },
  });
  const pages=query.data?.pages;
  const checks=pages?.flatMap(page=>page.checks)??[];
  const total=pages?.[0]?.checks_total??checks.length;
  const previous=checks.map((check,index)=>({check,number:total-index}))
    .filter(({check})=>check.id!==currentId).reverse();

  return <section aria-label="Các lần kiểm tra trước" className="followup-history">
    <Card>
      <h2>Các lần kiểm tra trước</h2>
      {query.isPending&&<p role="status">Đang tải các lần kiểm tra trong đợt theo dõi…</p>}
      {query.isError&&!query.isFetchNextPageError&&<Alert error>
        Chưa tải được lịch sử của đợt theo dõi. <Button className="secondary" onClick={()=>void query.refetch()}>Tải lại</Button>
      </Alert>}
      {query.isSuccess&&!previous.length&&<p>Chưa có lần kiểm tra trước để hiển thị.</p>}
      {previous.length>0&&<div className="followup-checks">
        {previous.map(({check,number})=><article key={check.id} className="followup-check">
          <h3>Lần kiểm tra {number}</h3>
          <Link to={'/results/'+check.id} aria-label={'Mở ảnh và kết quả lần kiểm tra '+number}>
            <RecordImage id={check.id} available={check.has_image} thumbnail/>
            {!check.has_image&&<span className="muted">Lần này chưa lưu ảnh.</span>}
          </Link>
          <strong>{check.label}</strong>
          {typeof check.raw_score==='number'&&<span className="muted">Điểm mô hình · {(check.raw_score*100).toFixed(1)}%</span>}
          <time className="muted" dateTime={check.created_at}>{new Date(check.created_at).toLocaleString('vi-VN')}</time>
        </article>)}
      </div>}
      {query.isFetchNextPageError&&<Alert error>Chưa tải được các lần kiểm tra cũ hơn.</Alert>}
      {query.hasNextPage&&<Button className="secondary" disabled={query.isFetchingNextPage} onClick={()=>void query.fetchNextPage()}>
        {query.isFetchingNextPage?'Đang tải…':'Xem các lần cũ hơn'}
      </Button>}
    </Card>
  </section>;
}
