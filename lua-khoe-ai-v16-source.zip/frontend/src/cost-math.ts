export type CostInput={area:number,rate:number,basis:number,price:number,unit:string,source:string};
export function estimateCost(input:CostInput){
 const{area,rate,basis,price}=input;
 if(![area,rate,basis,price].every(Number.isFinite)||area<=0||rate<=0||basis<=0||price<0)throw new Error('Diện tích và định mức phải lớn hơn 0; đơn giá không được âm.');
 if(!input.unit.trim()||!input.source.trim())throw new Error('Cần đơn vị và nguồn định mức đã xác minh.');
 const quantity=area/basis*rate,total=quantity*price;
 if(!Number.isFinite(quantity)||!Number.isFinite(total)||total>Number.MAX_SAFE_INTEGER)throw new Error('Giá trị vượt phạm vi tính toán. Kiểm tra lại số liệu.');
 return {...input,unit:input.unit.trim(),source:input.source.trim(),quantity,total};
}
