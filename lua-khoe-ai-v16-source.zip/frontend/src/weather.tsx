import {useState} from 'react';
import {api,type Row} from './api';
import {Alert,Button,Card,Field,Heading} from './ui';

export function WeatherPage(){
 const[result,setResult]=useState<Row|null>(null);const[busy,setBusy]=useState(false);const[error,setError]=useState('');
 return <><Heading title="Thời tiết tại vị trí bạn chọn">Cần Internet để lấy dữ liệu mới. Không tự lấy vị trí thiết bị và không lưu tọa độ vào hồ sơ.</Heading>
 <Card><form onChange={()=>{setResult(null);setError('')}} onSubmit={async e=>{e.preventDefault();if(busy)return;const data=new FormData(e.currentTarget);setBusy(true);setResult(null);setError('');try{setResult(await api('/weather/current','POST',{latitude:Number(data.get('latitude')),longitude:Number(data.get('longitude')),consent_to_share_location:data.get('consent')==='on'}))}catch(e){setError((e as Error).message)}finally{setBusy(false)}}}>
 <Field label="Vĩ độ" name="latitude" type="number" min={-90} max={90} step="any" required disabled={busy}/><Field label="Kinh độ" name="longitude" type="number" min={-180} max={180} step="any" required disabled={busy}/>
 <label className="check"><input type="checkbox" name="consent" required disabled={busy}/>Tôi đồng ý gửi tọa độ đã nhập tới Open-Meteo để lấy thời tiết.</label><Button disabled={busy}>{busy?'Đang lấy thời tiết…':'Lấy thời tiết mới'}</Button></form></Card>
 {error&&<Alert error>{error}</Alert>}{result&&<Card><h2>Thời tiết theo mô hình</h2><p>Đây là dữ liệu tại lần lấy gần nhất, không tự cập nhật. Bấm Lấy thời tiết mới để làm mới.</p><p>Vị trí yêu cầu: {result.requested_location.latitude}, {result.requested_location.longitude}</p><p>Ô lưới mô hình: {result.model_grid.latitude}, {result.model_grid.longitude}</p><p>Thời điểm dữ liệu: {new Date(result.valid_at).toLocaleString('vi-VN')}<br/>Lấy lúc: {new Date(result.retrieved_at).toLocaleString('vi-VN')}</p>
 <p>Nhiệt độ: {result.current.temperature_2m} °C</p><p>Độ ẩm tương đối: {result.current.relative_humidity_2m}%</p><p>Lượng giáng thủy trong khoảng {result.interval_seconds/60} phút: {result.current.precipitation} mm</p><p>Tốc độ gió: {result.current.wind_speed_10m} km/h</p>
 <p>Nguồn: <a href="https://open-meteo.com/" target="_blank" rel="noreferrer">Open-Meteo</a></p><Alert>{result.notice}</Alert></Card>}
 </>;
}
