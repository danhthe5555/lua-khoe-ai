import {useState} from 'react';
import {useQuery,useQueryClient} from '@tanstack/react-query';
import {api,type Row} from './api';
import {Alert,Button,Card,confirmAction} from './ui';

export function SessionSettings(){
 const[page,setPage]=useState(0);const[busy,setBusy]=useState(false);const[message,setMessage]=useState('');
 const client=useQueryClient();
 const list=useQuery({queryKey:['account-sessions',page],queryFn:()=>api(`/auth/sessions?offset=${page*20}&limit=20`)});
 async function revoke(row:Row){
  if(busy)return;
  if(!await confirmAction('Đăng xuất phiên này? Phiên đó sẽ không thể truy cập dữ liệu hoặc nhận thông báo mới.'))return;
  setBusy(true);setMessage('');
  try{await api(`/auth/sessions/${row.id}`,'DELETE');
   await client.invalidateQueries({queryKey:['account-sessions']});
   await client.invalidateQueries({queryKey:['push-subscriptions']});
   setMessage('Đã thu hồi phiên. Thông báo đã giao trước đó có thể vẫn còn trên thiết bị.');
  }catch(e){setMessage((e as Error).message)}finally{setBusy(false)}
 }
 return <Card><h2>Phiên đăng nhập</h2><p>Danh sách các phiên còn hiệu lực. Dùng thời điểm đăng nhập để đối chiếu; ứng dụng không thu thập tên thiết bị hoặc vị trí.</p>
 {list.isPending?<p>Đang tải phiên đăng nhập…</p>:list.isError?<Alert error>{list.error.message}<Button onClick={()=>list.refetch()}>Thử lại</Button></Alert>:<>
 {list.data.map((row:Row)=><div className="item" key={row.id}><h3>{row.current?'Phiên hiện tại':'Phiên khác'}</h3><p>Đăng nhập: {new Date(row.created_at).toLocaleString('vi-VN')}<br/>Hết hạn: {new Date(row.expires_at).toLocaleString('vi-VN')}</p>{!row.current&&<Button className="secondary" disabled={busy} onClick={()=>revoke(row)}>Đăng xuất phiên này</Button>}</div>)}
 {!list.data.length&&<p>Không có phiên ở trang này.</p>}
 <div className="row"><Button className="secondary" disabled={!page||busy} onClick={()=>setPage(page-1)}>Trang trước</Button><span>Trang {page+1}</span><Button className="secondary" disabled={list.data.length<20||busy} onClick={()=>setPage(page+1)}>Trang sau</Button></div></>}
 {message&&<Alert>{message}</Alert>}</Card>;
}
