import {useState} from 'react';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {Alert,Button,Card,Heading} from './ui';

export function DocumentAssistant(){
 const[question,setQuestion]=useState('');const[result,setResult]=useState<Row|null>(null);const[error,setError]=useState('');const[busy,setBusy]=useState(false);
 return <><Heading title="Hỏi đáp từ tài liệu">Mô hình trên máy chọn đoạn phù hợp từ các bài đã duyệt. Mỗi kết quả giữ nguyên văn và kèm nguồn để bạn kiểm tra.</Heading>
 <Card><form onSubmit={async e=>{e.preventDefault();if(busy)return;setBusy(true);setError('');setResult(null);try{setResult(await api('/assistant/ask','POST',{question:question.trim()}))}catch(e){setError((e as Error).message)}finally{setBusy(false)}}}>
 <label className="field">Câu hỏi về bệnh hoặc triệu chứng<textarea value={question} minLength={3} maxLength={1000} rows={4} required disabled={busy} onChange={e=>{setQuestion(e.target.value);setResult(null);setError('')}}/></label>
 <Button disabled={busy||question.trim().length<3}>{busy?'Đang tìm câu trả lời có nguồn…':'Hỏi trợ lý'}</Button></form>
 <p>Không gửi thông tin cá nhân vào câu hỏi. Hội thoại không được lưu trong tài khoản.</p><Link to="/tra-cuu">Tra cứu từ khóa không cần mô hình ngôn ngữ</Link></Card>
 {error&&<Alert error>{error}</Alert>}{result&&<><Alert>{result.message}</Alert>{result.citations.map((row:Row)=><Card key={row.reference}><h2>{row.title}</h2><blockquote style={{whiteSpace:'pre-wrap'}}>{row.text}</blockquote><p>Phiên bản tài liệu: {row.id} · Ngày duyệt: {new Date(row.reviewed_at).toLocaleDateString('vi-VN')}</p>{row.sources.map((source:Row,index:number)=><p key={index}>Nguồn: {source.title} — {source.publisher}<br/>{source.url}</p>)}<Link to={`/cam-nang/${encodeURIComponent(row.code)}`}>Đọc bài và các giới hạn đầy đủ</Link></Card>)}</>}
 </>;
}
