import {useState,type FormEvent,type ReactNode} from 'react';
import {useQuery,useQueryClient} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,ApiError,type Row} from './api';
import {clearPredictionDraft} from './draft';
import {Alert,Badge,Button,Card,Field} from './ui';

function RecheckReminder({id,season}:{id:string;season:string}) {
  const client=useQueryClient();
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [scheduled,setScheduled]=useState('');

  async function schedule(event:FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if(busy||scheduled)return;
    const due=new Date(String(new FormData(event.currentTarget).get('due')));
    if(!Number.isFinite(due.getTime())||due.getTime()<=Date.now()){
      setError('Chọn ngày giờ kiểm tra trong tương lai.');
      return;
    }
    setBusy(true);
    setError('');
    try{
      await api('/activities','POST',{
        kind:'reminder',title:'Kiểm tra lại lá lúa',season_id:season||null,
        diagnosis_id:id,due_at:due.toISOString(),
      });
      setScheduled(due.toLocaleString('vi-VN'));
      void client.invalidateQueries({queryKey:['due-reminders']});
    }catch(error){setError((error as Error).message)}
    finally{setBusy(false)}
  }

  return <details className="check-details"><summary>Đặt lịch kiểm tra lại</summary>
    {scheduled?<p role="status">Đã đặt lịch lúc {scheduled}. <Link to="/cong-viec">Xem việc cần làm</Link></p>:
      <form onSubmit={schedule}>
        <Field label="Ngày giờ kiểm tra lại" name="due" type="datetime-local" required/>
        {error&&<Alert error>{error}</Alert>}
        <Button disabled={busy}>{busy?'Đang lưu lịch…':'Lưu lịch kiểm tra'}</Button>
      </form>}
  </details>;
}

export function CheckResult({data,season='',fromHistory=false,saveAction}:{
  data:Row;season?:string;fromHistory?:boolean;saveAction?:ReactNode;
}) {
  const code=encodeURIComponent(data.predicted_class);
  const path='/diseases/'+code;
  const guide=useQuery({queryKey:[path],queryFn:()=>api(path)});
  const content=guide.data?.content;
  const missingGuide=guide.error instanceof ApiError&&guide.error.status===404;
  const recheck=season?'/nhan-dien?'+new URLSearchParams({vu:season}):'/nhan-dien';

  return <Card>
    <div className="row"><Badge>AI dự đoán</Badge>{data.diagnosis_id&&<Badge>Đã lưu vào lịch sử</Badge>}</div>
    <h2 className="check-label">{data.display_label_vi}</h2>
    <p>Điểm dự đoán của mô hình <strong>{(data.raw_score*100).toFixed(1)}%</strong>. Hãy đối chiếu triệu chứng ngoài ruộng trước khi quyết định xử lý.</p>
    <section aria-labelledby="next-check">
      <h3 id="next-check">Nên làm gì tiếp?</h3>
      {guide.isPending&&<p role="status">Đang tải hướng dẫn…</p>}
      {guide.isError&&(missingGuide?<p>Chưa có hướng dẫn đã duyệt cho kết quả này.</p>:
        <p>Chưa tải được hướng dẫn. <Button className="secondary" onClick={()=>guide.refetch()}>Tải lại hướng dẫn</Button></p>)}
      {content?.symptoms&&<p><strong>Dấu hiệu đối chiếu.</strong> {content.symptoms}</p>}
      {content?.field_check&&<p>{content.field_check}</p>}
      {content?.prevention&&<><h3>Phòng ngừa và theo dõi</h3><p>{content.prevention}</p></>}
      {guide.data?<Link to={'/cam-nang/'+code}>Đối chiếu ảnh mẫu và đọc cẩm nang</Link>:
        !guide.isPending&&<p>Chụp rõ vết trên lá và toàn bộ lá. Nếu dấu hiệu vẫn chưa rõ, hỏi cán bộ kỹ thuật địa phương trước khi xử lý.</p>}
    </section>
    {data.diagnosis_id?<div className="check-followup">
      <RecheckReminder key={data.diagnosis_id} id={data.diagnosis_id} season={season}/>
      <div className="row">
        {fromHistory?<Link className="link-button" to={recheck} onClick={clearPredictionDraft}>Kiểm tra lá lần nữa</Link>:
          <Link to={'/ket-qua/'+data.diagnosis_id}>Đã lưu · Xem lịch sử</Link>}
        {fromHistory&&<Link to="/lich-su">Tất cả kết quả</Link>}
      </div>
    </div>:saveAction}
    <details className="check-details"><summary>Chi tiết dự đoán AI</summary>
      <p>{data.review_message}</p>
      {data.top_k?.map((row:Row)=><div className="item row between" key={row.class_id}>
        <span>{row.label_vi}</span><span>{(row.score*100).toFixed(1)}%</span>
      </div>)}
    </details>
  </Card>;
}
