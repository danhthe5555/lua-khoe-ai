import {useState,type FormEvent} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,ApiError,type Row} from './api';
import {clearPredictionDraft} from './draft';
import {Alert,Badge,Button,Card} from './ui';
import {KnowledgePhoto} from './knowledge-photo';
import {FileText} from 'lucide-react';

function TrackingPanel({id,fromHistory}:{id:string;fromHistory:boolean}) {
  const path='/diagnoses/'+id+'/tracking';
  const tracking=useQuery({queryKey:[path],queryFn:()=>api(path)});
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');
  const data=tracking.data;
  const closed=Boolean(data?.closed_at);
  const latest=data?.checks[0];
  const journal=data?.journal.filter((entry:Row)=>entry.kind!=='reminder')??[];
  const secondCheck=Boolean(data&&data.checks.length>1);
  const recheck='/nhan-dien?'+new URLSearchParams({'theo-doi':id});

  async function change(action:()=>Promise<void>,success:string){
    setBusy(true);
    setError('');
    setNotice('');
    try{
      await action();
      setNotice(success);
      await tracking.refetch();
    }catch(error){setError((error as Error).message)}
    finally{setBusy(false)}
  }

  function record(event:FormEvent<HTMLFormElement>,kind:'intervention'|'observation'){
    event.preventDefault();
    const form=event.currentTarget;
    const fields=new FormData(form);
    const notes=String(fields.get('notes')||'').trim();
    if(kind==='intervention'&&!notes){setError('Nhập biện pháp đã thực hiện.');return}
    void change(async()=>{
      await api('/activities','POST',{
        kind,diagnosis_id:id,due_at:new Date().toISOString(),notes,
        title:kind==='intervention'?'Biện pháp đã thực hiện':String(fields.get('status')),
      });
      form.reset();
    },kind==='intervention'?'Đã lưu biện pháp.':'Đã lưu tình trạng.');
  }

  return <section className="check-followup" aria-label="Theo dõi đợt này">
    <div className="row between"><h3>Đợt theo dõi</h3>{data&&<Badge>{closed?'Đã kết thúc':'Đang theo dõi'}</Badge>}</div>
    {tracking.isPending&&<p role="status">Đang tải đợt theo dõi…</p>}
    {tracking.isError&&<Alert error>Chưa tải được đợt theo dõi. <Button className="secondary" onClick={()=>tracking.refetch()}>Tải lại</Button></Alert>}
    {data&&<>
      {!closed&&<>
        <details className="check-details"><summary>Ghi biện pháp đã thực hiện</summary>
          <form onSubmit={event=>record(event,'intervention')}>
            <label className="field">Biện pháp đã thực hiện<textarea name="notes" maxLength={4000} required/></label>
            <Button disabled={busy}>Lưu biện pháp</Button>
          </form>
        </details>
        {secondCheck&&latest?.id===id&&<details className="check-details" open>
          <summary>Ghi tình trạng sau khi kiểm tra lại</summary>
          <form onSubmit={event=>record(event,'observation')}>
            <label className="field">Tình trạng quan sát<select name="status" defaultValue="" required>
              <option value="" disabled>Chọn tình trạng</option><option>Đỡ hơn</option><option>Không đổi</option>
              <option>Nặng hơn</option><option>Chưa rõ</option>
            </select></label>
            <label className="field">Ghi chú quan sát<textarea name="notes" maxLength={4000}/></label>
            <Button disabled={busy}>Lưu tình trạng</Button>
          </form>
        </details>}
      </>}
      {secondCheck&&<details className="check-details" open><summary>Các lần kiểm tra trong đợt</summary>
        {data.checks.map((check:Row)=><div className="item" key={check.id}><Link to={'/results/'+check.id}>{check.label} · {new Date(check.created_at).toLocaleString('vi-VN')}</Link></div>)}
      </details>}
      {Boolean(journal.length)&&<details className="check-details"><summary>Nhật ký đợt theo dõi</summary>
        {journal.map((entry:Row)=><div className="item" key={entry.id}><strong>{entry.title}</strong>
          <p>{new Date(entry.due_at).toLocaleString('vi-VN')}{entry.notes&&<><br/>{entry.notes}</>}</p>
        </div>)}
      </details>}
      {error&&<Alert error>{error}</Alert>}
      {notice&&<p role="status">{notice}</p>}
      <div className="row">
        {!closed&&<Link className="link-button secondary" to={recheck} onClick={clearPredictionDraft}>Kiểm tra lá lần nữa</Link>}
        {!closed&&secondCheck&&!data.latest_observed&&latest.id!==id&&<Link to={'/results/'+latest.id}>Ghi tình trạng lần gần nhất</Link>}
        {(closed||secondCheck&&data.latest_observed)&&<Button className="secondary" disabled={busy}
          onClick={()=>void change(async()=>{await api(path,'PATCH',{closed:!closed})},closed?'Đã mở lại đợt theo dõi.':'Đã kết thúc đợt theo dõi.')}>
          {closed?'Mở lại đợt theo dõi':'Kết thúc đợt theo dõi'}
        </Button>}
      </div>
    </>}
    <div className="row">{fromHistory?<Link to="/lich-su">Tất cả kết quả</Link>:<Link to={'/results/'+id}>Đã lưu · Xem lịch sử</Link>}</div>
  </section>;
}

export function CheckResult({data,fromHistory=false}:{
  data:Row;fromHistory?:boolean;
}) {
  const code=encodeURIComponent(data.predicted_class);
  const path='/diseases/'+code;
  const guide=useQuery({queryKey:[path],queryFn:()=>api(path)});
  const content=guide.data?.content;
  const missingGuide=guide.error instanceof ApiError&&guide.error.status===404;

  return <Card>
    <div className="row"><Badge>AI dự đoán</Badge>{data.diagnosis_id&&<Badge>Đã lưu vào lịch sử</Badge>}</div>
    <h2 className="check-label">{data.display_label_vi}</h2>
    <p>Điểm dự đoán của mô hình <strong>{(data.raw_score*100).toFixed(1)}%</strong>. Hãy đối chiếu triệu chứng ngoài ruộng trước khi quyết định xử lý.</p>
    {data.quality_status==='uncertain'&&<Alert><strong>Cần xác minh kết quả.</strong> Nếu ảnh chưa thấy rõ lá lúa hoặc vùng có triệu chứng, hãy chụp lại trước khi dùng hướng dẫn bên dưới.</Alert>}
    {data.photo_notice&&<Alert>{data.photo_notice}</Alert>}
    {data.duplicate_photo&&<p className="muted">Ảnh này giống hệt tệp đã lưu trong lịch sử. Hãy chọn ảnh mới nếu đang kiểm tra lại.</p>}
    <section aria-labelledby="next-check">
      <h3 id="next-check">Nên làm gì tiếp?</h3>
      {guide.isPending&&<p role="status">Đang tải hướng dẫn…</p>}
      {guide.isError&&(missingGuide?<p>Chưa có hướng dẫn đã duyệt cho kết quả này.</p>:
        <p>Chưa tải được hướng dẫn. <Button className="secondary" onClick={()=>guide.refetch()}>Tải lại hướng dẫn</Button></p>)}
      {guide.data&&<Link className="link-button secondary" to={'/cam-nang/'+code}>Mở hướng dẫn đã kiểm duyệt</Link>}
      {content?.symptoms&&<p><strong>Dấu hiệu đối chiếu.</strong> {content.symptoms}</p>}
      {content?.field_check&&<p>{content.field_check}</p>}
      {content?.treatment&&<><h3>Biện pháp xử lý</h3><p>{content.treatment}</p></>}
      {content?.medicine&&<><h3>Thuốc bảo vệ thực vật</h3><p>{content.medicine}</p></>}
      {content?.cautions&&<Alert><strong>Lưu ý quan trọng.</strong> {content.cautions}</Alert>}
      {content?.prevention&&<><h3>Phòng ngừa và theo dõi</h3><p>{content.prevention}</p></>}
      {guide.data&&<><h3>Ảnh triệu chứng để đối chiếu</h3><KnowledgePhoto code={data.predicted_class}/></>}
      <p><strong>Khi nào nên nhờ chuyên gia?</strong> Hỏi cán bộ bảo vệ thực vật địa phương nếu dấu hiệu chưa rõ, khác với cẩm nang hoặc xuất hiện ở nhiều chỗ trong ruộng.</p>
    </section>
    {data.diagnosis_id&&<>
      <div className="row">
        <Link className="link-button secondary" to={'/results/'+encodeURIComponent(data.diagnosis_id)+'/report'}>
          <FileText size={18}/>Xuất phiếu gửi chuyên gia
        </Link>
      </div>
      <TrackingPanel key={data.diagnosis_id} id={data.diagnosis_id} fromHistory={fromHistory}/>
    </>}
    <details className="check-details"><summary>Các dự đoán khác của AI</summary>
      <p>{data.review_message}</p>
      {data.top_k?.slice(1).map((row:Row)=><div className="item row between" key={row.class_id}>
        <span>{row.label_vi}</span><span>{(row.score*100).toFixed(1)}%</span>
      </div>)}
    </details>
  </Card>;
}
