import {useEffect,useRef,useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {api} from './api';
import {Link} from 'react-router-dom';
import {Alert,Button,Card,Heading} from './ui';

export function OCRLabel(){
 const input=useRef<HTMLInputElement>(null);
 const[file,setFile]=useState<File|null>(null);const[preview,setPreview]=useState('');
 const[text,setText]=useState('');const[busy,setBusy]=useState(false);const[error,setError]=useState('');const[confirmed,setConfirmed]=useState(false);
 const state=useQuery({queryKey:['ocr-status'],queryFn:()=>api('/ocr/status')});
 useEffect(()=>{if(!file){setPreview('');return}const url=URL.createObjectURL(file);setPreview(url);return()=>URL.revokeObjectURL(url)},[file]);
 async function read(){if(!file||busy)return;setBusy(true);setText('');setConfirmed(false);setError('');try{const form=new FormData();form.set('image',file);const result=await api('/ocr/label','POST',form);setText(result.text);if(!result.text)setError('Chưa tìm thấy chữ. Hãy chụp rõ từng phần nhãn.')}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
 return <><Heading title="Đọc chữ trên nhãn thuốc">Đọc ảnh trên máy chủ cục bộ, sau đó đối chiếu và sửa lại văn bản. Ảnh và văn bản không được lưu vào lịch sử.</Heading>
 <Alert>Đây chưa phải công cụ xác minh thuốc được phép sử dụng. Không dùng kết quả OCR để quyết định thuốc, liều lượng hoặc thời gian cách ly.</Alert>
 <Card>{state.isPending?<p role="status">Đang kiểm tra bộ đọc chữ.</p>:state.isError?<Alert error>{state.error.message}</Alert>:<p role="status">{state.data.message}</p>}<Button className="secondary" disabled={state.isFetching||busy} onClick={()=>state.refetch()}>Kiểm tra lại bộ đọc chữ</Button>
 <label className="field">Ảnh nhãn JPEG, PNG hoặc WebP, tối đa 10 MB<input ref={input} type="file" accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={e=>{const next=e.target.files?.[0]||null;setText('');setConfirmed(false);setError('');if(next&&(next.size>10*1024*1024||next.size===0||!['image/jpeg','image/png','image/webp'].includes(next.type))){setFile(null);e.target.value='';setError('Chọn ảnh JPEG, PNG hoặc WebP hợp lệ, tối đa 10 MB.');return}setFile(next)}}/></label>
 {preview&&<img src={preview} alt="Ảnh nhãn gốc để đối chiếu chữ" style={{maxWidth:'100%',maxHeight:480,objectFit:'contain'}}/>}
 <div className="row"><Button disabled={busy||!file||!state.data?.ready} onClick={read}>{busy?'Đang đọc chữ…':'Đọc chữ từ ảnh'}</Button><Button className="secondary" disabled={busy||!file} onClick={()=>{if(input.current)input.current.value='';setFile(null);setText('');setConfirmed(false);setError('')}}>Bỏ ảnh và văn bản</Button></div>{error&&<Alert error>{error}</Alert>}</Card>
 {text&&<Card><h2>Kiểm tra văn bản đọc được</h2><label className="field">Đối chiếu tên, số và đơn vị với ảnh gốc<textarea value={text} maxLength={12000} rows={12} onChange={e=>{setText(e.target.value);setConfirmed(false)}}/></label><label className="check"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>Tôi đã đối chiếu văn bản với ảnh gốc.</label>{confirmed&&<Alert>Đã ghi nhận bạn đối chiếu văn bản trong lượt này. Bạn có thể tra cứu bản nhãn có nguồn; xác nhận này không chứng minh thuốc được phép dùng.<br/><Link to="/tra-cuu-nhan">Tra cứu tên hoặc số đăng ký đã đối chiếu</Link></Alert>}</Card>}
 </>;
}
