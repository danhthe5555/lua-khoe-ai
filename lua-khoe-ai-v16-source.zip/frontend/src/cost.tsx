import {useState} from 'react';
import {estimateCost} from './cost-math';
import {Alert,Button,Card,Field} from './ui';

export function CostCalculator(){
 const[result,setResult]=useState<ReturnType<typeof estimateCost>|null>(null);const[error,setError]=useState('');
 return <Card><h2>Dự tính chi phí</h2><p>Nhập định mức đã được xác minh và nguồn đối chiếu. Công cụ chỉ thực hiện phép tính, không chọn thuốc hoặc quyết định liều dùng.</p>
 <form onChange={()=>{setResult(null);setError('')}} onSubmit={e=>{e.preventDefault();const data=new FormData(e.currentTarget);try{setResult(estimateCost({area:Number(data.get('area')),rate:Number(data.get('rate')),basis:Number(data.get('basis')),price:Number(data.get('price')),unit:String(data.get('unit')),source:String(data.get('source'))}));setError('')}catch(e){setError((e as Error).message)}}}>
 <div className="grid two"><Field label="Diện tích cần tính (m²)" name="area" type="number" min="0.01" step="any" required/><Field label="Định mức đã xác minh" name="rate" type="number" min="0.000001" step="any" required/><Field label="Định mức áp dụng cho diện tích (m²)" name="basis" type="number" min="0.01" step="any" required/><Field label="Đơn vị số lượng (ví dụ kg hoặc lít)" name="unit" maxLength={40} required/><Field label="Đơn giá (đồng / đơn vị đã nhập)" name="price" type="number" min="0" step="any" required/></div>
 <Field label="Nguồn định mức, ngày và người xác minh" name="source" maxLength={1000} required/><Button>Tính chi phí</Button>
 {error&&<Alert error>{error}</Alert>}{result&&<Alert><b>Tổng dự tính: {result.total.toLocaleString('vi-VN',{maximumFractionDigits:0})} đồng</b><p>Số lượng = {result.area.toLocaleString('vi-VN')} ÷ {result.basis.toLocaleString('vi-VN')} × {result.rate.toLocaleString('vi-VN')} = {result.quantity.toLocaleString('vi-VN',{maximumFractionDigits:6})} {result.unit}.</p><p>Chi phí = số lượng × {result.price.toLocaleString('vi-VN')} đồng/{result.unit}.</p><p>Nguồn do bạn nhập: {result.source}. Chưa bao gồm công lao động, vận chuyển hoặc quy cách đóng gói.</p></Alert>}
 </form></Card>;
}
