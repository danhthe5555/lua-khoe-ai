import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {Alert,Button,Card,Heading} from './ui';

export function StageGuidance(){
 const[selection,setSelection]=useState<{code:string,stage:string}|null>(null);
 const stages=useQuery({queryKey:['growth-stages'],queryFn:()=>api('/growth-stages')});
 const diseases=useQuery({queryKey:['guidance-diseases'],queryFn:()=>api('/diseases')});
 const result=useQuery({queryKey:['stage-guidance',selection],enabled:selection!==null,queryFn:()=>api(`/diseases/${encodeURIComponent(selection!.code)}/guidance?stage=${encodeURIComponent(selection!.stage)}`)});
 return <><Heading title="Hướng dẫn theo giai đoạn">Chọn bệnh và giai đoạn đã kiểm tra thực tế. Không tự suy ra giai đoạn từ ngày gieo hoặc kết quả AI.</Heading>
 <Card>{stages.isPending||diseases.isPending?<p role="status">Đang tải lựa chọn.</p>:stages.isError||diseases.isError?<Alert error>Không tải được dữ liệu.<Button onClick={()=>{void stages.refetch();void diseases.refetch()}}>Thử lại</Button></Alert>:!diseases.data.length?<Alert>Chưa có bài bệnh được xuất bản. Quản trị viên cần bổ sung nội dung và duyệt nguồn trước.</Alert>:<form onSubmit={e=>{e.preventDefault();const data=new FormData(e.currentTarget);setSelection({code:String(data.get('code')),stage:String(data.get('stage'))})}} onChange={()=>setSelection(null)}>
 <label className="field">Bệnh cần đối chiếu<select name="code" required defaultValue=""><option value="" disabled>Chọn bệnh</option>{diseases.data.map((row:Row)=><option key={row.code} value={row.code}>{row.title}</option>)}</select></label>
 <label className="field">Giai đoạn sinh trưởng<select name="stage" required defaultValue=""><option value="" disabled>Chọn giai đoạn thực tế</option>{stages.data.map((row:Row)=><option key={row.code} value={row.code}>{row.name}</option>)}</select></label><Button>Xem hướng dẫn phù hợp</Button></form>}</Card>
 {selection&&(result.isPending?<p role="status">Đang tải hướng dẫn.</p>:result.isError?<Alert error>{result.error.message}<Button onClick={()=>result.refetch()}>Thử lại</Button></Alert>:<Card><h2>{result.data.stage_name}</h2><Alert>{result.data.reason}</Alert>{result.data.text&&<><p style={{whiteSpace:'pre-wrap'}}>{result.data.text}</p><p>Ngày duyệt: {new Date(result.data.reviewed_at).toLocaleDateString('vi-VN')}</p>{result.data.sources.map((source:Row,index:number)=><p key={index}>Nguồn: {source.title} — {source.publisher}<br/>{source.url}</p>)}</>}<Link to={`/cam-nang/${encodeURIComponent(selection.code)}`}>Đọc toàn bộ hướng dẫn và giới hạn</Link></Card>)}
 </>;
}
