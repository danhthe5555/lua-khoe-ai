import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Camera, ChevronRight} from 'lucide-react';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {clearPredictionDraft} from './draft';
import {Alert,Badge,Button,Card,Empty,Heading} from './ui';

export function TrackingPage(){
  const [page,setPage]=useState(0);
  const path='/tracking?limit=21&offset='+page*20;
  const q=useQuery({queryKey:[path],queryFn:()=>api(path)});
  return <><Heading title="Theo dõi ruộng lúa">Mở lại từng đợt để xem lịch kiểm tra và ghi nhận của bạn.</Heading>
    <div className="row section-actions">
      <Link className="link-button" to="/nhan-dien" onClick={clearPredictionDraft}><Camera size={18}/>Bắt đầu đợt mới</Link>
      <Link className="link-button secondary" to="/ruong-lua">Quản lý ruộng</Link>
      <Link className="link-button secondary" to="/cong-viec">Việc cần làm</Link>
    </div>
    {q.isPending?<p role="status">Đang tải các đợt theo dõi…</p>:q.isError?<Alert error>{q.error.message} <Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:
      <>{q.data.length?<div className="grid two">{q.data.slice(0,20).map((row:Row)=><Card key={row.id}>
        <div className="row between"><Badge>{row.closed_at?'Đã kết thúc':'Đang theo dõi'}</Badge><span className="muted">{row.check_count} lần kiểm tra</span></div>
        <h2 className="check-label">{row.label}</h2>
        <p>Lần gần nhất · {new Date(row.checked_at).toLocaleString('vi-VN')}</p>
        <div className="row">
          <Link to={'/results/'+row.id}>Mở đợt theo dõi <ChevronRight size={16}/></Link>
          {!row.closed_at&&<Link className="link-button secondary" onClick={clearPredictionDraft}
            to={'/nhan-dien?'+new URLSearchParams({vu:row.season_id||'','theo-doi':row.id})}>Kiểm tra lại</Link>}
        </div>
      </Card>)}</div>:<Card><Empty title="Chưa có đợt theo dõi">Chụp hoặc tải ảnh để bắt đầu.</Empty></Card>}
      {(page>0||q.data.length>20)&&<div className="row section-actions"><Button className="secondary" disabled={page===0} onClick={()=>setPage(page-1)}>Trang trước</Button>
        <Button className="secondary" disabled={q.data.length<=20} onClick={()=>setPage(page+1)}>Trang sau</Button></div>}</>}
  </>;
}
