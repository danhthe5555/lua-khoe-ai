import React,{createContext,useContext,useEffect,useState,type FormEvent,type ReactNode} from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter,Routes,Route,Link,NavLink,Navigate,useNavigate,useParams,useLocation} from 'react-router-dom';
import {QueryClient,QueryClientProvider,useQuery} from '@tanstack/react-query';
import {Camera,House,BookOpen,UserRound,ClipboardList,Menu,LogOut,TrendingUp,ScanLine,ChevronRight,ShieldCheck} from 'lucide-react';
import '@fontsource/be-vietnam-pro/400.css';import '@fontsource/be-vietnam-pro/600.css';import '@fontsource/be-vietnam-pro/700.css';
import './styles/tokens.css';
import './styles/handoff.css';
import {api,setCsrf,type Row} from './api';
import {predictionDraft,clearPredictionDraft} from './draft';
import {BatchPredict} from './batch';
import {LocalLookup} from './local-lookup';
import {StageGuidance} from './stage-guidance';
import {OCRLabel} from './ocr-label';
import {DocumentAssistant} from './assistant';
import {WeatherPage} from './weather';
import {LabelCatalogue,AdminLabels} from './label-catalogue';
import {PushSettings,clearBrowserPush} from './push-settings';
import {SessionSettings} from './session-settings';
import {HistoryPage} from './history';
import {CostCalculator} from './cost';
import {FeedbackPrivacy,AdminFeedback} from './feedback';
import {AdminAccounts,AdminAuditLog} from './admin-lists';
import {KnowledgePhoto} from './knowledge-photo';
import {Prediction} from './prediction';
import {CheckResult} from './check-result';
import {RecordImage,ResultReport} from './result-assessment';
import {TrackingPage} from './tracking-page';
import {ImportReferenceDrafts,KnowledgeRevisionEditor} from './knowledge-editor';
import {Brand,Button,Card,Field,Alert,Empty,Heading,Badge,ConfirmDialog,confirmAction} from './ui';
import {PlotsPage,PlotPage,ActivitiesPage,StatsPage,DeleteDataControl} from './management';
const client=new QueryClient({defaultOptions:{queries:{retry:false,refetchOnWindowFocus:false,gcTime:0}}});
const Auth=createContext<{user:Row|null,loading:boolean,refresh:()=>Promise<void>,logout:()=>Promise<void>}>({user:null,loading:true,refresh:async()=>{},logout:async()=>{}});
function AuthProvider({children}:{children:ReactNode}){const[user,setUser]=useState<Row|null>(null);const[loading,setLoading]=useState(true);
  async function refresh(){try{const r=await api('/auth/me');setCsrf(r.csrf);if(predictionDraft.owner&&predictionDraft.owner!==r.user.id)clearPredictionDraft();setUser(r.user)}catch{if(predictionDraft.owner)clearPredictionDraft();client.clear();setCsrf('');setUser(null)}finally{setLoading(false)}}
  async function logout(){await api('/auth/logout','POST');await clearBrowserPush().catch(()=>{});clearPredictionDraft();setCsrf('');setUser(null);client.clear();window.location.assign('/')}
  useEffect(()=>{void refresh();const clear=()=>{if(predictionDraft.owner)clearPredictionDraft();setUser(null);setCsrf('');client.clear()};window.addEventListener('session-expired',clear);return()=>window.removeEventListener('session-expired',clear)},[]);
  return <Auth.Provider value={{user,loading,refresh,logout}}>{children}</Auth.Provider>}
const nav=[['/','Tổng quan','Tổng quan',House],['/nhan-dien','Nhận diện bệnh','Nhận diện',ScanLine],['/lich-su','Lịch sử','Lịch sử',ClipboardList],['/theo-doi','Theo dõi','Theo dõi',TrendingUp],['/cam-nang','Cẩm nang bệnh','Cẩm nang',BookOpen]] as const;
function Shell(){
  const {user,loading}=useContext(Auth);
  const location=useLocation();
  const path=location.pathname;
  const section=path.startsWith('/quan-tri')?'Quản trị viên':
    path.startsWith('/results/')||path.startsWith('/ket-qua/')?'Chi tiết lần nhận diện':
    path.startsWith('/cong-viec')||path.startsWith('/ruong-lua')?'Theo dõi':
    nav.find(([url])=>url==='/'?path==='/':path===url||path.startsWith(url+'/'))?.[1]||'Tài khoản';
  useEffect(()=>{window.scrollTo(0,0)},[path,location.search]);
  return <><ConfirmDialog key={user?.id||'guest'}/><a className="skip" href="#main">Đến nội dung</a>
    <div className="app-shell">
      <aside className="app-sidebar"><Brand/><p className="app-nav-label">Không gian làm việc</p>
        <nav aria-label="Điều hướng chính">{nav.map(([url,name,,Icon])=><NavLink end={url==='/'} key={url} to={url}><Icon size={18}/>{name}</NavLink>)}</nav>
        <p className="app-nav-label">Hệ thống</p><nav aria-label="Hệ thống">
          <NavLink to="/tai-khoan"><UserRound size={18}/>Tài khoản</NavLink>
          {user?.role==='admin'&&<NavLink to="/quan-tri"><ShieldCheck size={18}/>Quản trị viên</NavLink>}
        </nav>
        <div className="sidebar-note"><strong>Chăm sóc cây lúa</strong><p>Kiểm tra lá lúa bằng ảnh và xem lại từng đợt theo dõi.</p></div>
      </aside>
      <div className="workspace">
        <header className="topbar"><Brand/><div className="breadcrumb">Không gian làm việc / <strong>{section}</strong></div>
          <Link className="account-link" to={user?'/tai-khoan':'/dang-nhap'}><UserRound size={17}/>{user?.name||'Đăng nhập'}</Link>
        </header>
        <main id="main"><Routes key={user?.id||"guest"}><Route path="/" element={<Home/>}/><Route path="/nhan-dien" element={<Prediction key={location.search} user={user} loading={loading}/>}/><Route path="/nhan-dien/nhieu-anh" element={<BatchPredict/>}/><Route path="/dang-nhap" element={<AuthForm/>}/><Route path="/dang-ky" element={<AuthForm register/>}/><Route path="/quen-mat-khau" element={<ResetForm/>}/><Route path="/dat-lai-mat-khau" element={<ResetForm reset/>}/><Route path="/huong-dan-giai-doan" element={<StageGuidance/>}/><Route path="/tra-cuu-nhan" element={<LabelCatalogue/>}/><Route path="/thoi-tiet" element={<Guard><WeatherPage/></Guard>}/><Route path="/tro-ly" element={<Guard><DocumentAssistant/></Guard>}/><Route path="/doc-nhan" element={<Guard><OCRLabel/></Guard>}/><Route path="/tra-cuu" element={<LocalLookup/>}/><Route path="/cam-nang" element={<Knowledge/>}/><Route path="/cam-nang/:code" element={<Knowledge/>}/><Route path="/ruong-lua" element={<Guard><Plots/></Guard>}/><Route path="/ruong-lua/:id" element={<Guard><PlotDetail/></Guard>}/><Route path="/lich-su" element={<Guard><HistoryPage/></Guard>}/><Route path="/theo-doi" element={<Guard><TrackingPage/></Guard>}/><Route path="/results/:id/report" element={<Guard><ResultReport/></Guard>}/><Route path="/results/:id" element={<Guard><History/></Guard>}/><Route path="/ket-qua/:id" element={<Guard><History/></Guard>}/><Route path="/cong-viec" element={<Guard><Activities/></Guard>}/><Route path="/thong-ke" element={<Guard><Stats/></Guard>}/><Route path="/tai-khoan" element={<Guard anyRole><Account/></Guard>}/><Route path="/quan-tri/*" element={<Guard role="admin"><Admin/></Guard>}/><Route path="*" element={<><Heading title="Không tìm thấy trang"/><Link className="link-button" to="/">Về trang chủ</Link></>}/></Routes></main>
        <footer className="footer">Lúa Khỏe AI · Nhận diện và theo dõi lá lúa</footer>
      </div>
      <nav className="bottom-nav" aria-label="Điều hướng điện thoại">{nav.map(([url,,label,Icon])=>
        <NavLink end={url==='/'} key={url} to={url}><Icon/><span>{label}</span></NavLink>)}</nav>
    </div>
  </>;
}
function Guard({children,role='farmer',anyRole=false}:{children:ReactNode,role?:string,anyRole?:boolean}){const{user,loading}=useContext(Auth);if(loading)return <Loading/>;if(!user)return <Navigate to="/dang-nhap" replace/>;if(!anyRole&&user.role!==role)return <Alert error>Bạn không có quyền truy cập trang này. <Link to="/">Về trang chủ</Link></Alert>;return children}
function Loading(){return <div className="busy" role="status">Đang tải dữ liệu…</div>}
function QueryState({query,children}:{query:any,children:(data:any)=>ReactNode}){if(query.isPending)return <Loading/>;if(query.isError)return <Alert error>{query.error.message} <Button className="secondary" onClick={()=>query.refetch()}>Thử lại</Button></Alert>;return children(query.data)}
function useData(path:string,enabled=true){return useQuery({queryKey:[path],queryFn:()=>api(path),enabled})}
function Home(){
  const {user}=useContext(Auth);
  const farmer=user?.role==='farmer';
  const recent=useData('/diagnoses?limit=3',farmer);
  const totals=useData('/stats/overview',farmer);
  const tracking=useData('/tracking?limit=3',farmer);
  const guides=useData('/diseases');
  return <>
    <Heading title="Chào mừng đến với Lúa Khỏe AI">Kiểm tra lá lúa, đối chiếu dấu hiệu và theo dõi kết quả từ điện thoại hoặc máy tính.</Heading>
    <section className="hero">
      <div><span className="eyebrow">Nhận diện từ ảnh</span>
        <h2>Phát hiện sớm bệnh lá lúa.<br/><em>Chăm sóc đúng hướng.</em></h2>
        <p>Chụp hoặc tải ảnh để xem bệnh nghi ngờ, hướng dẫn đã duyệt và các bước kiểm tra tiếp theo.</p>
        <div className="row">
          <Link className="link-button hero-primary" to="/nhan-dien" onClick={clearPredictionDraft}><Camera size={18}/>Bắt đầu kiểm tra</Link>
          <Link className="link-button hero-secondary" to="/cam-nang"><BookOpen size={18}/>Xem cẩm nang</Link>
        </div>
      </div>
      <div className="hero-art" aria-hidden="true"><i className="rice-stem"/><i className="rice-leaf"/><i className="rice-leaf"/><i className="rice-leaf"/>
        <span className="hero-stamp"><ShieldCheck/>Nhận diện và theo dõi</span>
      </div>
    </section>
    <div className="grid home-metrics">
      <Link className="card home-metric" to="/lich-su"><div>Lượt nhận diện đã lưu<strong>{farmer?(totals.data?.total??'—'):'—'}</strong></div><span className="metric-icon"><ScanLine size={19}/></span></Link>
      <Link className="card home-metric" to="/theo-doi"><div>Đợt theo dõi gần đây<strong>{farmer?(tracking.data?.length??'—'):'—'}</strong></div><span className="metric-icon gold"><TrendingUp size={19}/></span></Link>
      <Link className="card home-metric" to="/cam-nang"><div>Mục trong cẩm nang<strong>{guides.data?.length??'—'}</strong></div><span className="metric-icon blue"><BookOpen size={19}/></span></Link>
    </div>
    <div className="section-title"><h2>Kiểm tra lá lúa trong 3 bước</h2></div>
    <div className="grid home-process">
      {[[Camera,'Chụp ảnh lá lúa','Chọn ảnh rõ nét, đủ sáng, thấy vùng triệu chứng.'],[ScanLine,'Xem kết quả AI','Đối chiếu dấu hiệu với cẩm nang.'],[TrendingUp,'Xử lý và theo dõi','Ghi việc đã làm và đặt lịch kiểm tra lại.']].map(([Icon,title,description])=>{
        const Glyph=Icon as typeof Camera;
        return <Card key={String(title)}><span className="metric-icon"><Glyph size={19}/></span><h3>{String(title)}</h3><p>{String(description)}</p></Card>;
      })}
    </div>
    <div className="home-dual">
      <section><div className="section-title"><h2>Nhận diện gần đây</h2><Link to="/lich-su">Xem tất cả</Link></div><Card>
        {!farmer?<Link to="/dang-nhap">Đăng nhập để xem lịch sử của bạn</Link>:<QueryState query={recent}>{rows=>rows.length?rows.map((row:Row)=><Link className="recent-record" key={row.id} to={'/results/'+row.id}>
          <RecordImage id={row.id} available={Boolean(row.image_key)} thumbnail/><span><strong>{row.result.display_label_vi}</strong><br/>{new Date(row.created_at).toLocaleDateString('vi-VN')}</span><ChevronRight size={18}/>
        </Link>):<Empty title="Chưa có lần kiểm tra nào"><Link to="/nhan-dien">Bắt đầu nhận diện</Link></Empty>}</QueryState>}
      </Card></section>
      <section><div className="section-title"><h2>Góc hỗ trợ</h2><Link to="/cam-nang">Tra cứu</Link></div><Card>
        <h3>Khi cần xác minh kết quả</h3><p>Xem ảnh triệu chứng đã duyệt hoặc in phiếu kết quả để trao đổi với cán bộ kỹ thuật.</p>
        <Link to="/cam-nang">Mở cẩm nang bệnh</Link>
      </Card></section>
    </div>
  </>;
}
function AuthForm({register=false}:{register?:boolean}){const{refresh}=useContext(Auth);const navigate=useNavigate();const location=useLocation();const returnToPrediction=location.state?.returnToPrediction===true;const[error,setError]=useState('');const[busy,setBusy]=useState(false);const[show,setShow]=useState(false);async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();const f=new FormData(e.currentTarget);setBusy(true);setError('');try{if(register){if(f.get('password')!==f.get('confirm'))throw new Error('Hai mật khẩu chưa khớp.');await api('/auth/register','POST',{name:f.get('name'),email:f.get('email'),password:f.get('password')})}const r=await api('/auth/login','POST',{email:f.get('email'),password:f.get('password')});setCsrf(r.csrf);await refresh();navigate(r.user.role==='admin'?'/quan-tri':returnToPrediction?{pathname:'/nhan-dien',search:new URLSearchParams(location.state?.predictionQuery||'').toString()}:'/ruong-lua')}catch(e){setError((e as Error).message)}finally{setBusy(false)}}return <div className="auth"><Heading eyebrow="Lúa Khỏe AI" title={register?'Tạo tài khoản':'Chào mừng trở lại'}>Lưu và quản lý ruộng lúa của riêng bạn.</Heading><Card><form onSubmit={submit}>{register&&<Field label="Tên hiển thị" name="name" required/>}<Field label="Email" name="email" type="email" autoComplete="email" required/><Field label="Mật khẩu" name="password" type={show?'text':'password'} minLength={register?12:1} maxLength={128} autoComplete={register?'new-password':'current-password'} required/>{register&&<Field label="Nhập lại mật khẩu" name="confirm" type={show?'text':'password'} required/>}<label className="check"><input type="checkbox" checked={show} onChange={e=>setShow(e.target.checked)}/>Hiện mật khẩu</label>{register&&<p className="muted">Mật khẩu tối thiểu 12 ký tự. Tài khoản đăng ký có vai trò nông dân.</p>}{error&&<Alert error>{error}</Alert>}<Button disabled={busy} type="submit">{busy?'Đang xử lý…':register?'Tạo tài khoản':'Đăng nhập'}</Button></form><div className="row" style={{marginTop:24}}><Link to={register?'/dang-nhap':'/dang-ky'} state={location.state}>{register?'Đã có tài khoản? Đăng nhập':'Chưa có tài khoản? Đăng ký'}</Link><Link to="/quen-mat-khau">Quên mật khẩu</Link></div></Card></div>}
function ResetForm({reset=false}:{reset?:boolean}){const[message,setMessage]=useState('');const[busy,setBusy]=useState(false);return <div className="auth"><Heading title={reset?'Đặt lại mật khẩu':'Khôi phục tài khoản'}/><Card><form onSubmit={async e=>{e.preventDefault();setBusy(true);const f=new FormData(e.currentTarget);try{const token=new URLSearchParams(location.hash.slice(1)).get('token');const r=await api(reset?'/auth/reset-password':'/auth/forgot-password','POST',reset?{token,password:f.get('password')}:{email:f.get('email')});setMessage(r.message);if(reset)history.replaceState(null,'',location.pathname)}catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}}>{reset?<Field label="Mật khẩu mới (tối thiểu 12 ký tự)" name="password" type="password" minLength={12} required/>:<Field label="Email đăng ký" type="email" name="email" required/>}<Button disabled={busy}>{busy?'Đang gửi…':reset?'Đổi mật khẩu':'Gửi liên kết khôi phục'}</Button>{message&&<Alert>{message}</Alert>}</form><Link to="/dang-nhap">Về đăng nhập</Link></Card></div>}
function Knowledge(){const{code}=useParams();const q=useData(code?`/diseases/${code}`:'/diseases');const[search,setSearch]=useState('');return <><Heading eyebrow="Kiến thức đã kiểm duyệt" title={code?'Cẩm nang chi tiết':'Hiểu bệnh, chăm lúa đúng cách'}>Chỉ công bố nội dung có nguồn và đã được người có thẩm quyền duyệt.</Heading>{!code&&<Field label="Tìm trong cẩm nang" value={search} onChange={e=>setSearch(e.target.value)}/>}<QueryState query={q}>{data=>code?<Card><Badge>Đã kiểm duyệt</Badge><h2>{data.title}</h2><KnowledgePhoto code={data.code} detail/>{Object.entries(data.content).filter(([key])=>!['verification_questions','reviewed_tasks','similar_diseases'].includes(key)&&!key.startsWith('spread_')).map(([k,v])=><section key={k}><h3>{({symptoms:'Triệu chứng',field_check:'Cần kiểm tra thêm',prevention:'Phòng ngừa',stage_seedling:'Giai đoạn mạ',stage_tillering:'Giai đoạn đẻ nhánh',stage_heading:'Giai đoạn trổ bông',stage_grain_filling:'Giai đoạn chắc hạt'} as Row)[k]||k}</h3><p style={{whiteSpace:'pre-line'}}>{String(v)}</p></section>)}<h3>Nguồn tham khảo</h3>{data.sources.map((s:Row)=><p key={s.url}><a href={s.url} target="_blank" rel="noreferrer">{s.title}</a> · {s.publisher} · {s.checked_at}</p>)}<p>Ngày duyệt: {new Date(data.reviewed_at).toLocaleDateString('vi-VN')}</p></Card>:data.length?<div className="grid">{data.filter((r:Row)=>r.title.toLowerCase().includes(search.toLowerCase())).map((r:Row)=><Card key={r.id}><Badge>Đã kiểm duyệt</Badge><h2>{r.title}</h2><KnowledgePhoto code={r.code}/><Link to={`/cam-nang/${r.code}`}>Đọc hướng dẫn</Link></Card>)}</div>:<Card><Empty title="Chưa có bài được xuất bản"><p>Nội dung đang chờ rà soát chuyên môn. Không sử dụng nội dung chưa duyệt để quyết định xử lý.</p></Empty></Card>}</QueryState><p style={{marginTop:24}}><a href="/knowledge-photos/credits.html">Ghi công ảnh cẩm nang</a></p></>}
function Plots(){return <PlotsPage/>}
function PlotDetail(){return <PlotPage/>}
function History(){
  const {id}=useParams();
  const q=useData('/diagnoses/'+id);
  const [message,setMessage]=useState('');
  return <><Heading title="Lần kiểm tra đã lưu"/>
    <QueryState query={q}>{data=><div className="stack">
      <Card><div className="row between"><h2>Chi tiết lần nhận diện</h2><Link to="/lich-su">Quay lại lịch sử</Link></div>
        <div className="history-grid">
          <RecordImage key={data.id} id={data.id} available={Boolean(data.image_key)}/>
          <div><h2>{data.result.display_label_vi}</h2><Badge>Cần đối chiếu</Badge>
            <dl className="history-data">
              <div><dt>Thời điểm</dt><dd>{new Date(data.created_at).toLocaleString('vi-VN')}</dd></div>
              <div><dt>Điểm mô hình</dt><dd>{(data.result.raw_score*100).toFixed(1)}%</dd></div>
              <div><dt>Mã bản ghi</dt><dd className="record-id">{data.id}</dd></div>
              <div><dt>Mã đợt</dt><dd className="record-id">{data.tracking_id||data.id}</dd></div>
              <div><dt>Phiên bản mô hình</dt><dd className="record-id">{data.result.model_version}</dd></div>
            </dl></div>
        </div>
      </Card>
      <CheckResult data={{...data.result,diagnosis_id:data.id}} season={data.season_id||''} fromHistory/>
      <Card><details><summary>Báo kết quả chưa phù hợp</summary><form onSubmit={async event=>{
        event.preventDefault();
        const form=new FormData(event.currentTarget);
        try{setMessage((await api(`/diagnoses/${id}/feedback`,'POST',{notes:form.get('notes'),consented_to_review:form.get('consent')==='on'})).message)}
        catch(error){setMessage((error as Error).message)}
      }}>
        <Field label="Ý kiến của bạn (chưa được xác minh)" name="notes" required/>
        <label className="check"><input type="checkbox" name="consent"/>Tôi đồng ý cho người phụ trách xem xét phản hồi này</label>
        <Button>Gửi phản hồi</Button>{message&&<Alert>{message}</Alert>}
      </form></details></Card>
    </div>}</QueryState>
  </>;
}
function Activities(){return <ActivitiesPage/>}
function Stats(){return <><StatsPage/><Cost/></>}
function Cost(){return <CostCalculator/>}
function Account(){const{user,logout,refresh}=useContext(Auth);const[message,setMessage]=useState('');return <><Heading title="Tài khoản của tôi"/><Card><p>{user?.email} · {user?.role==='admin'?'Quản trị viên':'Nông dân'}</p><form onSubmit={async e=>{e.preventDefault();try{await api('/auth/me','PATCH',{name:new FormData(e.currentTarget).get('name')});await refresh();setMessage('Đã cập nhật hồ sơ.')}catch(e){setMessage((e as Error).message)}}}><Field label="Tên hiển thị" name="name" defaultValue={user?.name} required/><Button>Lưu hồ sơ</Button></form>{message&&<Alert>{message}</Alert>}<div className="row" style={{marginTop:24}}><Button className="secondary" onClick={logout}><LogOut size={18}/>Đăng xuất</Button>{user?.role==='admin'&&<Link className="link-button secondary" to="/quan-tri"><ShieldCheck size={18}/>Quản trị viên</Link>}{user?.role==='farmer'&&<><Link to="/lich-su">Lịch sử</Link><Link to="/thong-ke">Thống kê</Link><Button className="secondary" onClick={async()=>{const data=await api('/me/data');const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='du-lieu-cua-toi.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}}>Xuất dữ liệu</Button></>}</div></Card><SessionSettings/>{user?.role==='farmer'&&<><Card><details><summary>Công cụ bổ sung</summary><div className="row check-followup">
      <Link to="/thoi-tiet">Thời tiết</Link><Link to="/huong-dan-giai-doan">Hướng dẫn theo giai đoạn</Link>
      <Link to="/tra-cuu-nhan">Đối chiếu nhãn</Link><Link to="/doc-nhan">Đọc chữ trên nhãn</Link>
      <Link to="/tra-cuu">Tra cứu tài liệu</Link><Link to="/tro-ly">Hỏi đáp tài liệu</Link>
    </div></details></Card><PushSettings/><FeedbackPrivacy/><DeleteDataControl/></>}</>}
const adminNav=[['/quan-tri/nhan-thuoc','Nhãn & nguồn',BookOpen],['/quan-tri','Tổng quan',House],['/quan-tri/noi-dung','Nội dung & nguồn',BookOpen],['/quan-tri/tai-khoan','Tài khoản',UserRound],['/quan-tri/phan-hoi','Phản hồi',ClipboardList],['/quan-tri/nhat-ky','Nhật ký quản trị',ClipboardList]] as const;
function Admin(){const[open,setOpen]=useState(false);return <div className="admin-layout"><aside><Button className="secondary admin-menu" aria-expanded={open} onClick={()=>setOpen(!open)}><Menu/>Danh mục quản trị</Button><nav className={`sidebar ${open?'open':''}`}>{adminNav.map(([url,title,Icon])=><NavLink end key={url} to={url} onClick={()=>setOpen(false)}><Icon size={18}/>{title}</NavLink>)}</nav></aside><div><Badge>Quản trị · Lúa Khỏe AI</Badge><Routes><Route index element={<AdminOverview/>}/><Route path="nhan-thuoc" element={<AdminLabels/>}/><Route path="noi-dung" element={<AdminKnowledge/>}/><Route path="tai-khoan" element={<AdminUsers/>}/><Route path="nhat-ky" element={<AdminAudit/>}/><Route path="phan-hoi" element={<AdminFeedback/>}/><Route path="*" element={<Alert error>Không tìm thấy trang quản trị.</Alert>}/></Routes></div></div>}
function AdminOverview(){const q=useData('/admin/overview');return <><Heading title="Tổng quan quản trị">Quản lý tri thức có nguồn, bảo vệ dữ liệu nông dân.</Heading><QueryState query={q}>{r=><div className="grid two"><Card><h2>Nội dung</h2>{Object.entries(r.knowledge).map(([k,v])=><p key={k}>{k}: {String(v)}</p>)}{Object.keys(r.knowledge).length===0&&<Empty title="Chưa có bản nội dung"/>}<Link to="/quan-tri/noi-dung">Soạn bản nháp</Link></Card><Card><h2>Dữ liệu tổng hợp</h2><p>{r.predictions.saved} lượt ảnh được người dùng chọn lưu; {r.predictions.requires_review} kết quả cần xác minh.</p><p>{r.feedback.received} phản hồi chưa xác minh, trong đó {r.feedback.consented} phản hồi có đồng ý xem xét.</p><p className="muted">Không bao gồm ảnh thử của khách; không phản ánh độ chính xác hoặc tỷ lệ bệnh ngoài đồng. Trang này không hiển thị dữ liệu cá nhân.</p></Card><Card><h2>Trạng thái mô hình</h2><Badge>{r.model.ready?'Đã nạp mô hình':'Chưa sẵn sàng'}</Badge><p>{r.model.message||'Trạng thái nạp không thay thế đánh giá hiệu quả ngoài đồng.'}</p></Card></div>}</QueryState></>}
function AdminKnowledge(){const[page,setPage]=useState(0);const[editing,setEditing]=useState<Row|null>(null);const[status,setStatus]=useState('all');const[message,setMessage]=useState('');const[search,setSearch]=useState('');const[busy,setBusy]=useState(false);const q=useData(`/admin/knowledge?search=${encodeURIComponent(search)}&status=${status}&offset=${page*20}&limit=20`);return <><Heading title="Nội dung & nguồn">Mỗi lần sửa tạo phiên bản mới. Chỉ duyệt khi bạn có thẩm quyền và đã kiểm tra nguồn.</Heading><ImportReferenceDrafts onImported={()=>{setPage(0);setSearch('');setStatus('draft');void q.refetch()}}/><>{editing&&<KnowledgeRevisionEditor key={editing.id} record={editing} onCancel={()=>setEditing(null)} onSaved={()=>{setEditing(null);q.refetch();setMessage("Đã lưu phiên bản nháp mới.")}}/>}</><Card><h2>Soạn phiên bản nháp</h2><form onSubmit={async e=>{e.preventDefault();setBusy(true);const f=new FormData(e.currentTarget);try{await api('/admin/knowledge','POST',{code:f.get('code'),title:f.get('title'),content:{symptoms:f.get('symptoms'),field_check:f.get('field_check'),prevention:f.get('prevention')},sources:f.get('url')?[{title:f.get('source_title'),url:f.get('url'),publisher:f.get('publisher'),checked_at:f.get('date'),reuse_permission:f.get('permission')}]:[]});q.refetch();setMessage('Đã lưu bản nháp, chưa xuất bản.')}catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}}><div className="grid two"><Field label="Mã nhãn chính thức của mô hình" name="code" required/><Field label="Tiêu đề" name="title" required/></div>{[['symptoms','Triệu chứng'],['field_check','Bước đối chiếu ngoài ruộng'],['prevention','Phòng ngừa']].map(([name,title])=><label className="field" key={name}>{title}<textarea name={name} required/></label>)}<h3>Nguồn tham khảo</h3><Field label="Tên tài liệu" name="source_title"/><Field label="Đường dẫn nguồn" name="url" type="url"/><Field label="Đơn vị xuất bản" name="publisher"/><Field label="Ngày kiểm tra nguồn" name="date" type="date"/><Field label="Quyền tái sử dụng" name="permission"/><Button disabled={busy}>Lưu phiên bản nháp</Button></form>{message&&<Alert>{message}</Alert>}</Card><Field label="Tìm nội dung theo tiêu đề hoặc mã bệnh" maxLength={120} value={search} onChange={e=>{setSearch(e.target.value);setPage(0)}}/><label className="field">Trạng thái nội dung<select value={status} onChange={e=>{setStatus(e.target.value);setPage(0)}}><option value="all">Tất cả</option><option value="draft">Bản nháp</option><option value="reviewed">Đã duyệt</option><option value="published">Đang công khai</option><option value="archived">Đã ẩn</option></select></label><QueryState query={q}>{rows=><Card>{rows.length?rows.map((r:Row)=><div className="item" key={r.id}><Badge>{r.status}</Badge><h3>{r.title}</h3><details><summary>Xem trước nội dung và nguồn</summary>{Object.values(r.content).map((v,i)=><p key={i}>{String(v)}</p>)}{r.sources.map((s:Row)=><p key={s.url}>{s.title} · {s.url}</p>)}</details><div className="row"><Button className="secondary" onClick={()=>setEditing(r)}>Sửa thành phiên bản mới</Button>{(r.status==='draft'?['review']:r.status==='reviewed'?['publish']:r.status==='published'?['archive']:r.reviewed_by?['rollback']:[]).map(action=><Button className="secondary" key={action} onClick={async()=>{if(!await confirmAction('Xác nhận thao tác với nội dung? Chỉ duyệt khi đã kiểm tra chuyên môn và quyền sử dụng.'))return;try{await api(`/admin/knowledge/${r.id}/${action}`,'POST',{confirmed:true});q.refetch();setMessage('Đã cập nhật trạng thái và lưu nhật ký.')}catch(e){setMessage((e as Error).message)}}}>{({review:'Xác nhận đã duyệt',publish:'Xuất bản',archive:'Ẩn nội dung',rollback:'Phục hồi phiên bản'} as Row)[action]}</Button>)}</div></div>):<Empty title="Không có nội dung phù hợp"/>}<div className="row"><Button className="secondary" disabled={!page} onClick={()=>setPage(page-1)}>Trang trước</Button><span>Trang {page+1}</span><Button className="secondary" disabled={rows.length<20} onClick={()=>setPage(page+1)}>Trang sau</Button></div></Card>}</QueryState></>}
function AdminUsers(){return <AdminAccounts/>}
function AdminAudit(){return <AdminAuditLog/>}
// A restored document can still hold the previous account and query cache.
window.addEventListener('pageshow', event => {
  if (event.persisted) window.location.reload();
});
createRoot(document.getElementById('root')!).render(<React.StrictMode><QueryClientProvider client={client}><BrowserRouter><AuthProvider><Shell/></AuthProvider></BrowserRouter></QueryClientProvider></React.StrictMode>);
if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
