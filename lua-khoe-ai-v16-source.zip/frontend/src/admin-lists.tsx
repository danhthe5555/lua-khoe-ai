import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {api,type Row} from './api';
import {Alert,Badge,Button,Card,Empty,Field,Heading,confirmAction} from './ui';

function Pager({page,count,onChange}:{page:number,count:number,onChange:(page:number)=>void}){
 return <div className="row"><Button className="secondary" disabled={!page} onClick={()=>onChange(page-1)}>Trang trước</Button><span>Trang {page+1}</span><Button className="secondary" disabled={count<20} onClick={()=>onChange(page+1)}>Trang sau</Button></div>;
}
export function AdminAccounts(){
 const[filters,setFilters]=useState('');const[page,setPage]=useState(0);const[busy,setBusy]=useState<string|null>(null);const[error,setError]=useState('');
 const path=`/admin/users?${filters}&offset=${page*20}&limit=20`;const q=useQuery({queryKey:[path],queryFn:()=>api(path)});
 return <><Heading title="Quản lý tài khoản">Chỉ quản lý thông tin tối thiểu và trạng thái; không truy cập ruộng hay ảnh riêng tư.</Heading>
 <Card><form onSubmit={e=>{e.preventDefault();const data=new FormData(e.currentTarget);const params=new URLSearchParams();for(const[key,value]of data)if(value)params.set(key,String(value));setFilters(params.toString());setPage(0)}}><Field label="Tìm theo tên hoặc email" name="search" maxLength={120}/><label className="field">Trạng thái tài khoản<select name="status"><option value="all">Tất cả</option><option value="active">Đang hoạt động</option><option value="inactive">Đã khóa</option></select></label><Button>Áp dụng bộ lọc</Button></form></Card>
 {error&&<Alert error>{error}</Alert>}{q.isPending?<p role="status">Đang tải tài khoản…</p>:q.isError?<Alert error>{q.error.message}<Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:<Card>
 {q.data.length?q.data.map((r:Row)=><article className="item" key={r.id}><h2>{r.name}</h2><p>{r.email} · {r.role==='admin'?'Quản trị viên':'Nông dân'}</p><Badge>{r.active?'Đang hoạt động':'Đã khóa'}</Badge>{r.role==='farmer'&&<Button className="secondary" disabled={busy!==null} onClick={async()=>{if(!await confirmAction(`Xác nhận ${r.active?'khóa':'mở'} tài khoản ${r.name}? Các phiên hiện tại sẽ bị thu hồi.`))return;setBusy(r.id);setError('');try{await api(`/admin/users/${r.id}/status`,'PATCH',{active:!r.active,confirmed:true});await q.refetch()}catch(e){setError((e as Error).message)}finally{setBusy(null)}}}>{busy===r.id?'Đang cập nhật…':r.active?'Khóa tài khoản':'Mở tài khoản'}</Button>}</article>):<Empty title="Không có tài khoản phù hợp"/>}
 <Pager page={page} count={q.data.length} onChange={setPage}/></Card>}</>;
}

const actions:Record<string,string>={label_draft:'Tạo nháp nhãn',label_publish:'Xuất bản nhãn',label_archive:'Lưu trữ nhãn',create_draft:'Tạo bản nháp',review:'Duyệt nội dung',publish:'Xuất bản',archive:'Ẩn nội dung',rollback:'Phục hồi phiên bản',activate:'Mở tài khoản',deactivate:'Khóa tài khoản'};
export function AdminAuditLog(){
 const[action,setAction]=useState('');const[page,setPage]=useState(0);const path=`/admin/audit?action=${encodeURIComponent(action)}&offset=${page*20}&limit=20`;
 const q=useQuery({queryKey:[path],queryFn:()=>api(path)});
 return <><Heading title="Nhật ký quản trị">Các thao tác thay đổi nội dung và trạng thái tài khoản.</Heading><label className="field">Lọc thao tác<select value={action} onChange={e=>{setAction(e.target.value);setPage(0)}}><option value="">Tất cả</option>{Object.entries(actions).map(([code,label])=><option key={code} value={code}>{label}</option>)}</select></label>
 {q.isPending?<p role="status">Đang tải nhật ký…</p>:q.isError?<Alert error>{q.error.message}<Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:<Card>{q.data.length?q.data.map((r:Row)=><article className="item" key={r.id}><Badge>{actions[r.action]||r.action}</Badge><p>{new Date(r.created_at).toLocaleString('vi-VN')}</p><p>Mã đối tượng: {r.target_id}</p><p>Mã quản trị viên: {r.admin_id}</p></article>):<Empty title="Không có thao tác phù hợp"/>}<Pager page={page} count={q.data.length} onChange={setPage}/></Card>}</>;
}
