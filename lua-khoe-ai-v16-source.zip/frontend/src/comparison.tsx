import {useState} from 'react';
import type {Row} from './api';
import {Alert,Card} from './ui';
export function Comparison({rows}:{rows:Row[]}){
 const[first,setFirst]=useState('');const[second,setSecond]=useState('');
 const records=rows.filter(r=>r.event_kind==='ai_prediction');
 if(records.length<2)return <p>Cần ít nhất hai lần kiểm tra đã lưu trong ruộng để đối chiếu.</p>;
 const selected=[first,second].map(id=>records.find(r=>r.id===id));
 return <Card><h2>Đối chiếu hai lần kiểm tra</h2><div className="grid two">{[first,second].map((value,index)=><label className="field" key={index}>Lần kiểm tra {index+1}<select value={value} onChange={e=>(index===0?setFirst:setSecond)(e.target.value)}><option value="">Chọn lần kiểm tra</option>{records.map(r=><option key={r.id} value={r.id}>{new Date(r.created_at).toLocaleString('vi-VN')} · {r.result.display_label_vi}</option>)}</select></label>)}</div>
 {first&&first===second?<Alert error>Chọn hai lần kiểm tra khác nhau.</Alert>:selected.every(Boolean)&&<div className="grid two">{selected.map(r=><section key={r!.id}><h3>{new Date(r!.created_at).toLocaleString('vi-VN')}</h3>{r!.image_key&&<img className="preview" alt="Ảnh lá của lần kiểm tra đã chọn" src={`/api/v1/diagnoses/${r!.id}/image`}/>}<p>AI dự đoán: {r!.result.display_label_vi}</p><p>Điểm mô hình: {(r!.result.raw_score*100).toFixed(1)}%</p>{r!.season_id!==selected[0]!.season_id&&<p>Hai kết quả thuộc các mùa vụ khác nhau.</p>}</section>)}</div>}
 <Alert>Điểm dự đoán không đo mức độ tổn thương. Chênh lệch giữa hai ảnh không chứng minh bệnh giảm, tăng hoặc hiệu quả của biện pháp xử lý.</Alert></Card>;
}
