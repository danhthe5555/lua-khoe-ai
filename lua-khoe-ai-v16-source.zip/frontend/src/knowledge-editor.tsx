import {useState,type FormEvent} from 'react';
import {api,type Row} from './api';
import {Alert,Button,Card,Field} from './ui';

const labels:Record<string,string>={symptoms:'Triệu chứng',field_check:'Đối chiếu ngoài ruộng',prevention:'Phòng ngừa',causes:'Nguyên nhân',conditions:'Điều kiện thuận lợi',treatment:'Biện pháp xử lý'};
Object.assign(labels,{stage_seedling:'Hướng dẫn giai đoạn mạ / cây con',stage_tillering:'Hướng dẫn giai đoạn đẻ nhánh',stage_booting:'Hướng dẫn giai đoạn làm đòng',stage_heading:'Hướng dẫn giai đoạn trổ bông',stage_grain_filling:'Hướng dẫn giai đoạn chắc hạt',stage_ripening:'Hướng dẫn giai đoạn chín'});
const emptySource={title:'',url:'',publisher:'',checked_at:'',reuse_permission:''};

export function ImportReferenceDrafts({onImported}:{onImported:()=>void}){
 const [busy,setBusy]=useState(false);
 const [message,setMessage]=useState('');
 const [error,setError]=useState('');
 async function importDrafts(){
  setBusy(true);setMessage('');setError('');
  try{
   const result=await api('/admin/knowledge/import-reference-drafts','POST',{confirmed:true});
   const unavailable=result.unsupported.length?` Mô hình hiện không hỗ trợ ${result.unsupported.length} nhãn trong bộ tham khảo.`:'';
   setMessage(`Đã thêm ${result.created.length} bản nháp. Bỏ qua ${result.skipped.length} nhãn đã có nội dung.${unavailable}`);
   onImported();
  }catch(e){setError((e as Error).message)}finally{setBusy(false)}
 }
 return <Card><h2>Bản nháp tham khảo</h2><p>Thêm bài có nguồn cho các nhãn chưa có nội dung. Quản trị viên kiểm tra và duyệt từng bài trước khi xuất bản.</p>
  <Button type="button" disabled={busy} onClick={importDrafts}>{busy?'Đang thêm bản nháp…':'Thêm bản nháp tham khảo'}</Button>
  {message&&<Alert>{message}</Alert>}{error&&<Alert error>{error}</Alert>}
 </Card>;
}

export function KnowledgeRevisionEditor({record,onSaved,onCancel}:{record:Row,onSaved:()=>void,onCancel:()=>void}){
 const[title,setTitle]=useState(record.title);const[content,setContent]=useState<Record<string,string>>({...record.content});
 const[sources,setSources]=useState<Row[]>(record.sources.length?record.sources.map((s:Row)=>({...s})):[{...emptySource}]);
 const[busy,setBusy]=useState(false);const[error,setError]=useState('');
 async function submit(e:FormEvent){e.preventDefault();setBusy(true);setError('');try{await api('/admin/knowledge','POST',{code:record.code,title,content,sources});onSaved()}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
 return <Card><h2>Sửa thành phiên bản mới</h2><p>Bản hiện tại vẫn được giữ. Phiên bản mới cần duyệt trước khi xuất bản.</p><form onSubmit={submit}>
 <Field label="Mã nhãn" value={record.code} readOnly/><Field label="Tiêu đề" value={title} onChange={e=>setTitle(e.target.value)} required maxLength={200}/>
 {Array.from(new Set([...Object.keys(labels),...Object.keys(content)])).map(key=><label className="field" key={key}>{labels[key]||key}<textarea value={content[key]||''} maxLength={15000} onChange={e=>setContent({...content,[key]:e.target.value})} required={['symptoms','field_check','prevention'].includes(key)}/></label>)}
 <h3>Nguồn tham khảo</h3>{sources.map((s,index)=><fieldset key={index}><legend>Nguồn {index+1}</legend>{Object.entries({title:'Tên tài liệu',url:'Đường dẫn nguồn',publisher:'Đơn vị xuất bản',checked_at:'Ngày kiểm tra',reuse_permission:'Quyền tái sử dụng'}).map(([key,label])=><Field key={key} label={label} type={key==='url'?'url':key==='checked_at'?'date':'text'} value={s[key]||''} required onChange={e=>setSources(sources.map((old,i)=>i===index?{...old,[key]:e.target.value}:old))}/>)}<Button type="button" className="secondary" onClick={()=>setSources(sources.filter((_,i)=>i!==index))}>Bỏ nguồn này</Button></fieldset>)}
 <Button type="button" className="secondary" disabled={sources.length>=30} onClick={()=>setSources([...sources,{...emptySource}])}>Thêm nguồn</Button>
 {error&&<Alert error>{error}</Alert>}<div className="row"><Button disabled={busy}>{busy?'Đang lưu…':'Lưu phiên bản nháp mới'}</Button><Button type="button" className="secondary" disabled={busy} onClick={onCancel}>Hủy sửa</Button></div></form></Card>;
}
