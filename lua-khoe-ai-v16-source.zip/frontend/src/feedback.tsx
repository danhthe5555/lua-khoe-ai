import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {Alert,Badge,Button,Card,Empty,Heading,confirmAction} from './ui';

export function FeedbackPrivacy(){
 const q=useQuery({queryKey:['/me/feedback'],queryFn:()=>api('/me/feedback')});const[busy,setBusy]=useState<string|null>(null);const[message,setMessage]=useState('');
 async function change(item:Row,remove=false){
  if(!await confirmAction(remove?'Xóa phản hồi này?':item.consented_to_review?'Rút lại sự đồng ý để người phụ trách không còn tải lại phản hồi này? Nội dung đã đọc trước đó không thể thu hồi.':'Cho phép người phụ trách xem nội dung phản hồi này?'))return;
  setBusy(item.id);setMessage('');
  try{await api(`/feedback/${item.id}`,remove?'DELETE':'PATCH',remove?undefined:{notes:item.notes,consented_to_review:!item.consented_to_review});await q.refetch();setMessage(remove?'Đã xóa phản hồi.':'Đã cập nhật quyền xem phản hồi.')}catch(e){setMessage((e as Error).message)}finally{setBusy(null)}
 }
 return <Card><h2>Phản hồi và quyền xem</h2><p>Chỉ nội dung bạn đồng ý mới được người phụ trách xem. Việc này không cấp quyền xem ảnh hoặc ruộng của bạn, không tự thay đổi nhãn AI hoặc dùng làm nhãn huấn luyện.</p>{message&&<Alert>{message}</Alert>}
 {q.isPending?<p role="status">Đang tải phản hồi…</p>:q.isError?<Alert error>{q.error.message}<Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:q.data.length?q.data.map((item:Row)=><article className="item" key={item.id}><Badge>{item.consented_to_review?'Đã đồng ý cho xem':'Chưa đồng ý cho xem'}</Badge><p style={{whiteSpace:'pre-wrap'}}>{item.notes}</p><p>{new Date(item.created_at).toLocaleString('vi-VN')}</p><Link to={`/ket-qua/${item.diagnosis_id}`}>Xem lần nhận diện liên quan</Link><div className="row"><Button className="secondary" disabled={busy!==null} onClick={()=>change(item)}>{item.consented_to_review?'Rút lại sự đồng ý':'Đồng ý cho xem'}</Button><Button className="secondary" disabled={busy!==null} onClick={()=>change(item,true)}>Xóa phản hồi</Button></div></article>):<Empty title="Bạn chưa gửi phản hồi"/>}
 </Card>;
}

export function AdminFeedback(){
 const[page,setPage]=useState(0);const path=`/admin/feedback?offset=${page*20}&limit=20`;const q=useQuery({queryKey:[path],queryFn:()=>api(path),refetchInterval:15000,refetchOnWindowFocus:true});
 return <><Heading title="Phản hồi được đồng ý xem">Đây là ý kiến chưa được xác minh, không phải nhãn chuyên gia hoặc dữ liệu huấn luyện.</Heading><Card>
 {q.isPending?<p role="status">Đang tải phản hồi…</p>:q.isError?<Alert error>{q.error.message}<Button onClick={()=>q.refetch()}>Thử lại</Button></Alert>:<>{q.data.length?q.data.map((item:Row)=><article className="item" key={item.id}><Badge>Ý kiến chưa xác minh</Badge><p style={{whiteSpace:'pre-wrap'}}>{item.notes}</p><p>{new Date(item.created_at).toLocaleString('vi-VN')}</p></article>):<Empty title="Chưa có phản hồi được đồng ý xem"/>}<div className="row"><Button className="secondary" disabled={!page} onClick={()=>setPage(page-1)}>Trang trước</Button><span>Trang {page+1}</span><Button className="secondary" disabled={q.data.length<20} onClick={()=>setPage(page+1)}>Trang sau</Button><Button className="secondary" onClick={()=>q.refetch()}>Tải lại</Button></div></>}
 </Card></>;
}
