import {useQuery} from '@tanstack/react-query';
import {api,type Row} from './api';
import {Alert,Button,Card} from './ui';

export function DueReminders({onShowAll}:{onShowAll:()=>void}){
 const path='/activities?due_only=true&limit=5';
 const query=useQuery({queryKey:['due-reminders'],queryFn:()=>api(path),refetchInterval:60000,refetchOnWindowFocus:true});
 return <Card><h2>Nhắc việc đã đến hạn</h2><p>Cập nhật mỗi phút khi mở trang. Không gửi thông báo khi bạn đóng ứng dụng.</p>
 {query.isPending?<p role="status">Đang kiểm tra lịch.</p>:query.isError?<Alert error>Chưa kiểm tra được lịch nhắc.<Button onClick={()=>query.refetch()}>Thử lại</Button></Alert>:<>
 {query.data.length?<><ul>{query.data.map((item:Row)=><li key={item.id}>{item.title} — {new Date(item.due_at).toLocaleString('vi-VN')}</li>)}</ul><Button onClick={onShowAll}>Xem và xử lý tất cả việc đến hạn</Button></>:<p>Không có nhắc việc chưa hoàn thành đã đến hạn.</p>}
 <p className="muted">Cập nhật lúc {new Date(query.dataUpdatedAt).toLocaleTimeString('vi-VN')}. Hiển thị tối đa 5 việc có hạn sớm nhất.</p></>}
 </Card>;
}
