import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {api,type Row} from './api';
import {Alert,Button,Card} from './ui';

export async function clearBrowserPush(){
 if(!('serviceWorker' in navigator))return;
 const registration=await navigator.serviceWorker.getRegistration();
 if(!registration)return;
 try{if('pushManager' in registration){const old=await registration.pushManager.getSubscription();if(old)await old.unsubscribe()}}
 finally{for(const notification of await registration.getNotifications())notification.close()}
}

function serverKey(value:string){
 const raw=atob(value.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-value.length%4)%4));
 return Uint8Array.from(raw,c=>c.charCodeAt(0));
}

export function PushSettings(){
 const[busy,setBusy]=useState(false);const[message,setMessage]=useState('');
 const supported=window.isSecureContext&&'serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window;
 const config=useQuery({queryKey:['push-config'],queryFn:()=>api('/push/config')});
 const list=useQuery({queryKey:['push-subscriptions'],queryFn:()=>api('/push/subscriptions')});
 async function enable(){
  if(busy)return;setBusy(true);setMessage('');let subscription:PushSubscription|null=null;
  try{
   if(await Notification.requestPermission()!=='granted')throw new Error('Chưa được cấp quyền thông báo. Bạn có thể tiếp tục dùng lịch trong ứng dụng.');
   const registration=await navigator.serviceWorker.getRegistration();
   if(!registration?.active)throw new Error('Bộ nhận thông báo chưa sẵn sàng. Hãy tải lại trang.');
   await clearBrowserPush();
   for(const row of list.data||[])if(row.current_session)await api(`/push/subscriptions/${row.id}`,'DELETE');
   subscription=await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:serverKey(config.data.public_key)});
   const value=subscription.toJSON();await api('/push/subscriptions','POST',{endpoint:value.endpoint,keys:value.keys});
   await list.refetch();setMessage('Đã bật đăng ký thông báo cho phiên này. Máy chủ cần chạy tiến trình gửi và có Internet.');
  }catch(e){if(subscription)await subscription.unsubscribe().catch(()=>false);setMessage((e as Error).message)}finally{setBusy(false)}
 }
 async function revoke(row:Row){setBusy(true);setMessage('');try{await api(`/push/subscriptions/${row.id}`,'DELETE');if(row.current_session)await clearBrowserPush();await list.refetch();setMessage('Đã thu hồi đăng ký. Thông báo đã giao trước đó có thể vẫn còn trên thiết bị khác.')}catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}
 return <Card><h2>Thông báo nhắc việc trên thiết bị</h2><p>Chỉ bật khi bạn đồng ý. Thông báo không chứa tên ruộng hoặc ghi chú. Đăng xuất, hết phiên hoặc khóa tài khoản sẽ ngừng đăng ký; lần đăng nhập sau cần bật lại.</p>
 {!supported?<Alert>Trình duyệt hoặc kết nối hiện tại chưa hỗ trợ Web Push.</Alert>:config.isPending?<p>Đang kiểm tra cấu hình.</p>:config.isError?<Alert error>{config.error.message}</Alert>:!config.data.enabled?<Alert>Máy chủ chưa bật Web Push. Bạn vẫn dùng được lịch nhắc trong ứng dụng và file .ics.</Alert>:<Button disabled={busy||list.isPending||list.isError} onClick={enable}>Bật thông báo trên thiết bị này</Button>}
 {list.isError?<Alert error>{list.error.message}<Button onClick={()=>list.refetch()}>Thử lại</Button></Alert>:list.data?.map((row:Row)=><div className="item" key={row.id}><p>{row.current_session?'Phiên hiện tại':'Phiên trên thiết bị khác'} · Đăng ký {new Date(row.created_at).toLocaleString('vi-VN')}</p><Button className="secondary" disabled={busy} onClick={()=>revoke(row)}>Thu hồi đăng ký</Button></div>)}
 {message&&<Alert>{message}</Alert>}</Card>;
}
