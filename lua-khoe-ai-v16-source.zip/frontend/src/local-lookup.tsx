import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {Link} from 'react-router-dom';
import {api,type Row} from './api';
import {Alert,Button,Card,Empty,Field,Heading} from './ui';

export function LocalLookup(){
 const[question,setQuestion]=useState('');const[query,setQuery]=useState('');
 const result=useQuery({queryKey:['local-lookup',query],queryFn:()=>api(`/knowledge/search?q=${encodeURIComponent(query)}`),enabled:query.length>=2});
 return <><Heading title="Tra cứu tài liệu trên máy">Tìm nội dung trong cẩm nang đã xuất bản. Dùng được khi máy chủ cục bộ đang chạy, không cần dịch vụ AI bên ngoài.</Heading>
 <Card><form onSubmit={e=>{e.preventDefault();setQuery(question.trim())}}><Field label="Bạn muốn tìm nội dung gì?" value={question} onChange={e=>setQuestion(e.target.value)} minLength={2} maxLength={300} required/><Button disabled={question.trim().length<2}>Tra cứu</Button></form></Card>
 <Alert>Kết quả là đoạn trích theo từ khóa, không phải câu trả lời do AI suy luận. Hãy đọc đầy đủ tài liệu và điều kiện áp dụng; chưa có tài liệu phù hợp thì hệ thống không tự tạo hướng dẫn.</Alert>
 {query&&(result.isPending?<p role="status">Đang tra cứu.</p>:result.isError?<Alert error>{result.error.message}<Button onClick={()=>result.refetch()}>Thử lại</Button></Alert>:<>{result.data.results.length===0?<Empty title="Chưa tìm thấy nội dung phù hợp">Thử từ khóa tên bệnh hoặc triệu chứng. Cẩm nang cần được quản trị viên duyệt và xuất bản trước.</Empty>:result.data.results.map((r:Row)=><Card key={r.id}><h2>{r.title}</h2>{r.extracts.map((part:Row)=><blockquote key={part.section} style={{whiteSpace:'pre-wrap'}}>{part.text}</blockquote>)}<p>Ngày duyệt: {r.reviewed_at?new Date(r.reviewed_at).toLocaleDateString('vi-VN'):'Chưa có ngày'}</p>{r.sources.map((source:Row,index:number)=><p key={index}>Nguồn: {source.title} — {source.publisher}<br/>{source.url} (kiểm tra: {source.checked_at||'chưa ghi'})</p>)}<Link to={`/cam-nang/${encodeURIComponent(r.code)}`}>Đọc toàn bộ hướng dẫn</Link></Card>)}</>)}
 </>;
}
