import {useEffect,useRef,useState,type ChangeEvent} from 'react';
import {Link,useSearchParams} from 'react-router-dom';
import {Camera,Focus,ScanLine,Sun,Upload} from 'lucide-react';
import {api,type Row} from './api';
import {clearPredictionDraft,predictionDraft} from './draft';
import {CheckResult} from './check-result';
import {SeasonSelect} from './management';
import {Alert,Button,Card,Heading} from './ui';

const formats='image/jpeg,image/png,image/webp';

function checkPhoto(photo:HTMLImageElement){
  const {naturalWidth:width,naturalHeight:height}=photo;
  if(Math.min(width,height)<64)return {error:'Ảnh quá nhỏ. Hãy chụp lại rõ vùng triệu chứng.'};
  if(width*height>20_000_000)return {error:'Ảnh vượt quá 20 triệu điểm ảnh. Hãy giảm kích thước hoặc chụp lại.'};
  const canvas=document.createElement('canvas');
  canvas.width=48;canvas.height=48;
  const context=canvas.getContext('2d');
  if(!context)return {};
  context.drawImage(photo,0,0,48,48);
  const rgba=context.getImageData(0,0,48,48).data;
  const gray=new Float32Array(48*48);
  let sum=0,edge=0;
  for(let i=0;i<gray.length;i++){
    gray[i]=.2126*rgba[i*4]+.7152*rgba[i*4+1]+.0722*rgba[i*4+2];
    sum+=gray[i];
    if(i%48>0)edge+=Math.abs(gray[i]-gray[i-1]);
    if(i>=48)edge+=Math.abs(gray[i]-gray[i-48]);
  }
  const light=sum/gray.length;
  if(light<32||light>239)return {error:'Ảnh quá tối hoặc quá sáng. Chụp lại ở nơi đủ sáng, tránh chói.'};
  if(edge/(2*48*47)<2)return {warning:'Ảnh có ít chi tiết hoặc hơi mờ. Chụp lại nếu chưa thấy rõ vết trên lá.'};
  return {};
}

export function Prediction({user,loading}:{user:Row|null;loading:boolean}) {
  const [search]=useSearchParams();
  const followup=search.get('theo-doi')||'';
  const matchingDraft=predictionDraft.followup===followup;
  const savedOptions=matchingDraft?predictionDraft.saveOptions:null;
  const initialSeason=savedOptions?.season??(search.get('vu')||(matchingDraft?predictionDraft.season:''));
  const returnAfterLogin={returnToPrediction:true,predictionQuery:search.toString()};
  const farmer=user?.role==='farmer';
  const [file,setFile]=useState(matchingDraft?predictionDraft.file:null);
  const [preview,setPreview]=useState('');
  const [result,setResult]=useState(matchingDraft?predictionDraft.result:null);
  const [season,setSeason]=useState(initialSeason);
  const [save,setSave]=useState(true);
  const [optionsOpen,setOptionsOpen]=useState(Boolean(initialSeason||followup));
  const [saveImage,setSaveImage]=useState(savedOptions?.image??true);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [quality,setQuality]=useState<{error?:string;warning?:string}|null>(null);
  const [drag,setDrag]=useState(false);
  const request=useRef('');
  const resultRef=useRef<HTMLDivElement>(null);

  useEffect(()=>{
    if(!file){setPreview('');return}
    const url=URL.createObjectURL(file);
    setPreview(url);
    return ()=>URL.revokeObjectURL(url);
  },[file]);

  function resetPhoto(){
    clearPredictionDraft();
    setFile(null);
    setResult(null);
    setError('');
    setQuality(null);
  }

  function choose(event:ChangeEvent<HTMLInputElement>){
    const selected=event.currentTarget.files?.[0];
    event.currentTarget.value='';
    receive(selected);
  }

  function receive(selected:File|undefined){
    if(!selected||busy)return;
    resetPhoto();
    if(!selected.size||selected.size>10*1024*1024){setError('Ảnh phải có dung lượng từ 1 byte đến 10 MB.');return}
    if(!formats.split(',').includes(selected.type)){setError('Chọn tệp JPEG, PNG hoặc WebP.');return}
    Object.assign(predictionDraft,{file:selected,owner:user?.id||null,season,followup});
    setFile(selected);
  }

  async function run(shouldSave:boolean){
    if(!file||!quality||quality.error||loading||request.current||(followup&&!farmer))return;
    const key=predictionDraft.key||crypto.randomUUID();
    predictionDraft.key=key;
    request.current=key;
    setBusy(true);
    setError('');
    const options=shouldSave?(predictionDraft.saveOptions??{season,image:saveImage}):null;
    if(shouldSave)predictionDraft.saveOptions=options;
    try{
      const form=new FormData();
      form.set('image',file);
      form.set('save',String(shouldSave));
      form.set('save_image',String(options?.image??false));
      if(options?.season)form.set('season_id',options.season);
      if(followup)form.set('followup_id',followup);
      const output=await api('/diagnoses/predict','POST',form,{'Idempotency-Key':key});
      if(predictionDraft.key===key&&predictionDraft.file===file){
        Object.assign(predictionDraft,{result:output,owner:user?.id||null,season:options?.season??''});
        setResult(output);
        requestAnimationFrame(()=>resultRef.current?.focus());
      }
    }catch(error){setError((error as Error).message)}
    finally{request.current='';setBusy(false)}
  }

  const savingOptionsLocked=busy||Boolean(savedOptions);
  return <>
    <Heading title={followup?'Chụp ảnh kiểm tra lại':'Nhận diện bệnh lá lúa'}>
      {followup?'Chụp ở cùng ruộng và khu vực đã quan sát. Kết quả mới sẽ được lưu vào cùng đợt theo dõi.':
        'Chụp rõ một lá có dấu hiệu bất thường, đủ sáng và thấy rõ vết trên lá.'}
    </Heading>
    <div className="scan-grid">
      <Card>
        <div className="row between"><h2>Chọn ảnh lá lúa</h2><span className="muted">Tối đa 10 MB</span></div>
        <div className={'upload'+(drag?' drag-active':'')}
          onDragOver={event=>{event.preventDefault();if(!busy)setDrag(true)}}
          onDragLeave={()=>setDrag(false)}
          onDrop={event=>{event.preventDefault();setDrag(false);receive(event.dataTransfer.files[0])}}>
          {preview?<img key={preview} className="preview" src={preview} alt="Ảnh lá đã chọn"
            onLoad={event=>setQuality(checkPhoto(event.currentTarget))}
            onError={()=>setQuality({error:'Không đọc được ảnh. Hãy chọn ảnh khác.'})}/>:
            <><span className="upload-icon"><Upload size={28}/></span><h3>Kéo và thả ảnh vào đây</h3><p>JPEG, PNG hoặc WebP</p></>}
          <div className="row check-actions">
            <label className="link-button secondary"><Camera size={18}/>Chụp ảnh<input aria-label="Chụp ảnh" className="sr-only" type="file" disabled={busy} accept={formats} capture="environment" onChange={choose}/></label>
            <label className="link-button secondary"><Upload size={18}/>Chọn ảnh<input aria-label="Chọn ảnh" className="sr-only" type="file" disabled={busy} accept={formats} onChange={choose}/></label>
          </div>
        </div>
        {farmer&&!result?.diagnosis_id&&<details className="check-details" open={optionsOpen} onToggle={event=>setOptionsOpen(event.currentTarget.open)}>
          <summary>{save?'Tự lưu kết quả vào lịch sử':'Đang tắt lưu lịch sử'}</summary>
          <label className="check"><input type="checkbox" checked={save} disabled={savingOptionsLocked||Boolean(followup)} onChange={e=>setSave(e.target.checked)}/>Lưu kết quả vào lịch sử của tôi</label>
          {(save||result)&&<>
            <SeasonSelect disabled={savingOptionsLocked||Boolean(followup)} includeArchived={Boolean(followup)} value={season} onChange={setSeason}/>
            <label className="check"><input type="checkbox" checked={saveImage} disabled={savingOptionsLocked} onChange={e=>setSaveImage(e.target.checked)}/>Lưu cả ảnh để xem lại</label>
          </>}
        </details>}
        {!farmer&&!loading&&<p className="muted check-note"><Link to="/dang-nhap" state={returnAfterLogin}>Đăng nhập</Link> {followup?'để tiếp tục đợt theo dõi.':'để lưu lịch sử.'}</p>}
        {error&&<Alert error>{error}</Alert>}
        {file&&!quality&&<p role="status">Đang kiểm tra ảnh…</p>}
        {quality?.error&&<Alert error>{quality.error}</Alert>}
        {quality?.warning&&<Alert>{quality.warning}</Alert>}
        {quality&&!quality.error&&!quality.warning&&<p className="muted check-note">Ảnh đã qua kiểm tra sơ bộ. Hãy xác nhận vùng triệu chứng nhìn thấy rõ.</p>}
        {busy&&<p role="status">Đang phân tích ảnh…</p>}
        {result?<Button className="secondary" disabled={busy} onClick={resetPhoto}>Kiểm tra ảnh khác</Button>:
          <Button disabled={!file||!quality||Boolean(quality.error)||busy||loading||Boolean(followup&&!farmer)} onClick={()=>void run(farmer&&(save||Boolean(savedOptions)||Boolean(followup)))}><ScanLine size={17}/>{error&&file?'Thử lại':'Phân tích ảnh'}</Button>}
        {!result&&!followup&&<details className="check-details"><summary>Có nhiều ảnh?</summary><Link to="/nhan-dien/nhieu-anh">Phân tích nhiều ảnh</Link></details>}
      </Card>
      <Card><h2>Mẹo chụp ảnh tốt</h2>
        <div className="scan-guide-row"><span className="metric-icon"><Sun size={18}/></span><div><strong>Đủ sáng, tránh chói</strong><p>Ưu tiên ánh sáng tự nhiên, tránh bóng đổ lên lá.</p></div></div>
        <div className="scan-guide-row"><span className="metric-icon"><Focus size={18}/></span><div><strong>Lấy nét vùng có dấu hiệu</strong><p>Giữ điện thoại ổn định để vết trên lá hiện rõ.</p></div></div>
        <div className="scan-guide-row"><span className="metric-icon"><Camera size={18}/></span><div><strong>Để lá chiếm phần lớn khung hình</strong><p>Hạn chế nền rối hoặc nhiều lá che lên nhau.</p></div></div>
      </Card>
    </div>
      {result&&<div className="scan-result" ref={resultRef} tabIndex={-1}>
        <CheckResult data={result} season={predictionDraft.season} saveAction={<div className="check-followup">
          {farmer?<Button disabled={busy} onClick={()=>void run(true)}>{busy?'Đang lưu…':'Lưu lần kiểm tra vào lịch sử'}</Button>:
            <Link to="/dang-nhap" state={returnAfterLogin}>Đăng nhập để lưu lần kiểm tra</Link>}
        </div>}/>
      </div>}
  </>;
}
