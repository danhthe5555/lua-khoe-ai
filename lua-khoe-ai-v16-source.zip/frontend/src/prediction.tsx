import {useEffect,useRef,useState,type ChangeEvent} from 'react';
import {Link,useSearchParams} from 'react-router-dom';
import {Camera,Upload} from 'lucide-react';
import {api,type Row} from './api';
import {clearPredictionDraft,predictionDraft} from './draft';
import {CheckResult} from './check-result';
import {SeasonSelect} from './management';
import {Alert,Button,Card,Heading} from './ui';

const formats='image/jpeg,image/png,image/webp';
const returnAfterLogin={returnToPrediction:true};

export function Prediction({user,loading}:{user:Row|null;loading:boolean}) {
  const [search]=useSearchParams();
  const initialSeason=predictionDraft.saveOptions?.season??(search.get('vu')||predictionDraft.season);
  const farmer=user?.role==='farmer';
  const [file,setFile]=useState(predictionDraft.file);
  const [preview,setPreview]=useState('');
  const [result,setResult]=useState(predictionDraft.result);
  const [season,setSeason]=useState(initialSeason);
  const [save,setSave]=useState(true);
  const [optionsOpen,setOptionsOpen]=useState(Boolean(initialSeason));
  const [saveImage,setSaveImage]=useState(predictionDraft.saveOptions?.image??false);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const request=useRef('');
  const resultRef=useRef<HTMLDivElement>(null);

  useEffect(()=>{
    if(!file){setPreview('');return}
    const url=URL.createObjectURL(file);
    setPreview(url);
    return ()=>URL.revokeObjectURL(url);
  },[file]);

  function resetPhoto(){
    clearPredictionDraft();
    setFile(null);
    setResult(null);
    setError('');
  }

  function choose(event:ChangeEvent<HTMLInputElement>){
    const selected=event.currentTarget.files?.[0];
    event.currentTarget.value='';
    if(!selected)return;
    resetPhoto();
    if(selected.size>10*1024*1024){setError('Ảnh vượt quá 10 MB. Hãy chọn ảnh nhỏ hơn.');return}
    Object.assign(predictionDraft,{file:selected,owner:user?.id||null,season});
    setFile(selected);
  }

  async function run(shouldSave:boolean){
    if(!file||loading||request.current)return;
    const key=predictionDraft.key||crypto.randomUUID();
    predictionDraft.key=key;
    request.current=key;
    setBusy(true);
    setError('');
    const options=shouldSave?(predictionDraft.saveOptions??{season,image:saveImage}):null;
    if(shouldSave)predictionDraft.saveOptions=options;
    try{
      const form=new FormData();
      form.set('image',file);
      form.set('save',String(shouldSave));
      form.set('save_image',String(options?.image??false));
      if(options?.season)form.set('season_id',options.season);
      const output=await api('/diagnoses/predict','POST',form,{'Idempotency-Key':key});
      if(predictionDraft.key===key&&predictionDraft.file===file){
        Object.assign(predictionDraft,{result:output,owner:user?.id||null,season:options?.season??''});
        setResult(output);
        requestAnimationFrame(()=>resultRef.current?.focus());
      }
    }catch(error){setError((error as Error).message)}
    finally{request.current='';setBusy(false)}
  }

  const savingOptionsLocked=busy||Boolean(predictionDraft.saveOptions);
  return <>
    <Heading title="Nhận diện bệnh lá lúa">Chụp rõ một lá có dấu hiệu bất thường, đủ sáng và thấy rõ vết trên lá.</Heading>
    <div className={result?'grid two':'check-layout'}>
      <Card>
        <div className="upload">
          {preview?<img className="preview" src={preview} alt="Ảnh lá đã chọn"/>:<p>JPEG, PNG hoặc WebP · Tối đa 10 MB</p>}
          <div className="row check-actions">
            <label className="link-button secondary"><Camera size={18}/>Chụp ảnh<input aria-label="Chụp ảnh" className="sr-only" type="file" disabled={busy} accept={formats} capture="environment" onChange={choose}/></label>
            <label className="link-button secondary"><Upload size={18}/>Chọn ảnh<input aria-label="Chọn ảnh" className="sr-only" type="file" disabled={busy} accept={formats} onChange={choose}/></label>
          </div>
        </div>
        {farmer&&!result?.diagnosis_id&&<details className="check-details" open={optionsOpen} onToggle={event=>setOptionsOpen(event.currentTarget.open)}>
          <summary>{save?'Tự lưu kết quả vào lịch sử':'Đang tắt lưu lịch sử'}</summary>
          <label className="check"><input type="checkbox" checked={save} disabled={savingOptionsLocked} onChange={e=>setSave(e.target.checked)}/>Lưu kết quả vào lịch sử của tôi</label>
          {(save||result)&&<>
            <SeasonSelect disabled={savingOptionsLocked} value={season} onChange={setSeason}/>
            <label className="check"><input type="checkbox" checked={saveImage} disabled={savingOptionsLocked} onChange={e=>setSaveImage(e.target.checked)}/>Lưu cả ảnh để xem lại</label>
          </>}
        </details>}
        {!farmer&&!loading&&<p className="muted check-note">Bạn có thể nhận diện ngay. <Link to="/dang-nhap" state={returnAfterLogin}>Đăng nhập</Link> để lưu lịch sử.</p>}
        {error&&<Alert error>{error}</Alert>}
        {busy&&<p role="status">Đang phân tích ảnh…</p>}
        {result?<Button className="secondary" disabled={busy} onClick={resetPhoto}>Kiểm tra ảnh khác</Button>:
          <Button disabled={!file||busy||loading} onClick={()=>void run(farmer&&(save||Boolean(predictionDraft.saveOptions)))}>{error&&file?'Thử lại':'Phân tích ảnh'}</Button>}
        {!result&&<details className="check-details"><summary>Có nhiều ảnh?</summary><Link to="/nhan-dien/nhieu-anh">Phân tích nhiều ảnh</Link></details>}
      </Card>
      {result&&<div ref={resultRef} tabIndex={-1}>
        <CheckResult data={result} season={predictionDraft.season} saveAction={<div className="check-followup">
          {farmer?<Button disabled={busy} onClick={()=>void run(true)}>{busy?'Đang lưu…':'Lưu lần kiểm tra vào lịch sử'}</Button>:
            <Link to="/dang-nhap" state={returnAfterLogin}>Đăng nhập để lưu lần kiểm tra</Link>}
        </div>}/>
      </div>}
    </div>
  </>;
}
