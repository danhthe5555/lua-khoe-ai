import {defineConfig} from '@playwright/test';
export default defineConfig({testDir:'./tests',globalSetup:'./tests/wait-for-server.ts',workers:1,use:{baseURL:process.env.TEST_BASE_URL||'http://localhost:8080',trace:'retain-on-failure'},reporter:[['list'],['html',{open:'never'}],['json',{outputFile:process.env.TEST_JSON_REPORT||'test-results/report.json'}]]});
